package com.fs.starfarer.api.characters;

public interface PersonalityAPI {
	String getId();
	String getDisplayName();
	String getDescription();
}
