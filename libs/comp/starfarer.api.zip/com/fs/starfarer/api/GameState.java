package com.fs.starfarer.api;

public enum GameState {
	TITLE,
	CAMPAIGN,
	COMBAT,
}
