package com.fs.starfarer.api.campaign.econ;

import java.util.List;

import com.fs.starfarer.api.util.TimeoutTracker;




public interface EconomyAPI {
	void addMarket(MarketAPI market);
	void removeMarket(MarketAPI market);
	
	MarketAPI getMarket(String id);
	
	MarketConnectionAPI getConnection(MarketAPI one, MarketAPI two);
	MarketConnectionAPI getConnection(String idOne, String idTwo);
	
	
	void advance(float amount);
	
	List<MarketAPI> getMarketsCopy();
	List<MarketConnectionAPI> getConnectionsCopy();
	
	
	
	boolean isSimMode();
	List<String> getAllCommodityIds();
	CommoditySpecAPI getCommoditySpec(String commodityId);
	
	
	/**
	 * Commodities-on-market temporarily excluded from being updated by the economy.
	 * This includes supply, demand, and trade between different markets.
	 * 
	 * @return
	 */
	TimeoutTracker<CommodityOnMarketAPI> getExcluded();
	MarketAPI getParent(MarketAPI market);
	MarketConnectionAPI getConnection(String key);
	void updateStabilityAndPriceMult(MarketAPI market);
}



