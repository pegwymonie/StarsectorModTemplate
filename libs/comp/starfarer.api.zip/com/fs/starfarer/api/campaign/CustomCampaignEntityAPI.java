package com.fs.starfarer.api.campaign;

public interface CustomCampaignEntityAPI extends SectorEntityToken {
	void setRadius(float radius);

}
