package com.fs.starfarer.api.campaign.econ;

import java.util.List;
import java.util.Random;
import java.util.Set;

import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CommDirectoryAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.combat.MutableStat;
import com.fs.starfarer.api.combat.StatBonus;
import com.fs.starfarer.api.fleet.MutableMarketStatsAPI;
import com.fs.starfarer.api.fleet.ShipFilter;
import com.fs.starfarer.api.fleet.ShipRolePick;

public interface MarketAPI {
	
	public static enum SurveyLevel {
		NONE,
		SEEN,
		PRELIMINARY,
		FULL
	}
	
	SectorEntityToken getPrimaryEntity();
	List<SectorEntityToken> getConnectedEntities();
	
	String getId();
	String getName();
	int getSize();
	
	//Vector2f getLocation();
	
	void setSize(int size);
	
	List<CommodityOnMarketAPI> getAllCommodities();
	CommodityOnMarketAPI getCommodityData(String commodityId);
	List<CommodityOnMarketAPI> getCommoditiesWithTag(String tag);
	List<CommodityOnMarketAPI> getCommoditiesWithTags(String ... tags);
	
	MarketDemandAPI getDemand(String demandClass);
	List<MarketDemandAPI> getDemandWithTag(String tag);

	List<MarketConditionAPI> getConditions();
	/**
	 * Returns token which can be used to remove this specific condition.
	 * @param id
	 * @return
	 */
	String addCondition(String id);
	
	/**
	 * Returns token which can be used to remove this specific condition.
	 * @param id
	 * @param fromEvent
	 * @return
	 */
	String addCondition(String id, boolean fromEvent);
	
	/**
	 * Returns token which can be used to remove this specific condition.
	 * @param id
	 * @param fromEvent
	 * @param param
	 * @return
	 */
	String addCondition(String id, boolean fromEvent, Object param);
	
	/**
	 * Removes all copies of this condition.
	 * @param id
	 */
	void removeCondition(String id);
	
	/**
	 * Removes specific copy of a condition.
	 * @param token return value from addCondition()
	 */
	void removeSpecificCondition(String token);
	
	boolean hasCondition(String id);
	boolean hasSpecificCondition(String token);
	void reapplyConditions();
	void reapplyCondition(String token);
	
	MarketDemandDataAPI getDemandData();
	
//	StabilityTrackerAPI getStabilityTracker();
	
	MutableStat getTariff();
	
	/**
	 * Overall fraction of demand met, in terms of base prices of the commodities in demand.
	 * (So, larger demand/more valuable commodities have a higher impact on the result.)
	 * @return
	 */
	float getDemandMetFraction();
	
	/**
	 * Modifier for the price the market is willing to buy things at.
	 * Only the multiplier part of this works.
	 * @return
	 */
	StatBonus getDemandPriceMod();
	
	/**
	 * Modifier for the price the market is willing to sell things at.
	 * @return
	 */
	StatBonus getSupplyPriceMod();
	
	
	/**
	 * Price for the market selling quantity of given commodity, given the current stockpile/demand/etc.
	 * @param commodityId
	 * @param quantity
	 * @return
	 */
	float getSupplyPrice(String commodityId, double quantity, boolean isPlayerPrice);
	
	
	/**
	 * Price for the market buying quantity of given commodity, given the current stockpile/demand/etc.
	 * @param commodityId
	 * @param quantity
	 * @return
	 */
	float getDemandPrice(String commodityId, double quantity, boolean isPlayerPrice);
	
	
	/**
	 * @param commodityId
	 * @param quantity
	 * @param existingTransactionUtility positive for stuff sold to market, negative for stuff bought from market.
	 * @param isPlayerPrice
	 * @return
	 */
	float getDemandPriceAssumingExistingTransaction(String commodityId, double quantity, double existingTransactionUtility, boolean isPlayerPrice);
	
	/**
	 * @param commodityId
	 * @param quantity
	 * @param existingTransactionUtility positive for stuff sold to market, negative for stuff bought from market.
	 * @param isPlayerPrice
	 * @return
	 */
	float getSupplyPriceAssumingExistingTransaction(String commodityId, double quantity, double existingTransactionUtility, boolean isPlayerPrice);
	
	/**
	 * Checks against FactionAPI.getIllegalCommodities() for the faction owning the market.
	 * @param commodityId
	 * @return
	 */
	boolean isIllegal(String commodityId);
	
	/**
	 * Checks against FactionAPI.getIllegalCommodities() for the faction owning the market.
	 * @param com
	 * @return
	 */
	boolean isIllegal(CommodityOnMarketAPI com);
	
	MutableStat getStability();
	
	/**
	 * Integer value from 0 to 10, inclusive.
	 * @return
	 */
	float getStabilityValue();
	
	FactionAPI getFaction();
	String getFactionId();
	
	float getAverageSoldLastT();
	float getAverageSmuggledLastT();
	float getAverageBoughtLastT();
	
	void resetSmugglingValue();
	
	
	
	void addSubmarket(String specId);
	boolean hasSubmarket(String specId);
	List<SubmarketAPI> getSubmarketsCopy();
	void removeSubmarket(String specId);
	SubmarketAPI getSubmarket(String specId);
	void setFactionId(String factionId);
	
	
	
	/**
	 * Updates the local price multiplier (based on stability).
	 */
	void updatePriceMult();
	MemoryAPI getMemory();
	
	MemoryAPI getMemoryWithoutUpdate();

	/**
	 * May add more than one ship if a fallback specifies to add multiple ships.
	 * (For example, 2 small freighters if a medium freighter isn't available.)
	 * 
	 * See FactionAPI.pickShipAndAddToFleet for return value explanation.
	 * @param role
	 * @param fleet
	 * @return
	 */
	float pickShipAndAddToFleet(String role, CampaignFleetAPI fleet);
	
	float pickShipAndAddToFleet(String role, String factionId, CampaignFleetAPI fleet);
	
	float getShipQualityFactor();
	
	
	StarSystemAPI getStarSystem();
	LocationAPI getContainingLocation();
	
	int getBaseSmugglingStabilityValue();
	void setBaseSmugglingStabilityValue(int baseSmugglingStabilityValue);
	
	
	/**
	 * Approximate value of the total supply and demand this market has, in credits, not adjusted for price changes
	 * due to demand being met.
	 * @return
	 */
	float getTradeVolume();
	Vector2f getLocationInHyperspace();
	void setPrimaryEntity(SectorEntityToken primaryEntity);

	
//	/**
//	 * Will be null unless inited. Repeated invocations will do nothing.
//	 */
//	void initCommDirectory();

	/**
	 * @return
	 */
	CommDirectoryAPI getCommDirectory();

	void addPerson(PersonAPI person);
	void removePerson(PersonAPI person);
	List<PersonAPI> getPeopleCopy();
	MutableMarketStatsAPI getStats();
	
	List<ShipRolePick> pickShipsForRole(String role, float qualityFactor,
			Random random, ShipFilter filter);
	float pickShipAndAddToFleet(String role, float qualityFactor,
			CampaignFleetAPI fleet);
	float pickShipAndAddToFleet(String role, String factionId,
			float qualityFactor, CampaignFleetAPI fleet);
	List<ShipRolePick> pickShipsForRole(String role, String factionId,
			float qualityFactor, Random random, ShipFilter filter);
	
	Set<String> getChildren();
	String getParent();
	boolean isChildOf(MarketAPI other);
	boolean isParentOf(MarketAPI other);
	void setParent(String parent);
	boolean isPlanetConditionMarketOnly();
	void setPlanetConditionMarketOnly(boolean isPlanetConditionMarketOnly);
	void setName(String name);
	MutableStat getHazard();
	float getHazardValue();
	
//	boolean isSurveyed();
//	void setSurveyed(boolean surveyed);
	PlanetAPI getPlanetEntity();
	
	SurveyLevel getSurveyLevel();
	void setSurveyLevel(SurveyLevel surveyLevel);
	
	
	void advance(float amount);
	boolean isForceNoConvertOnSave();
	void setForceNoConvertOnSave(boolean forceNoConvertOnSave);
	void updatePrices();
	
	/**
	 * Get a condition using its unique id.
	 * @param token
	 * @return
	 */
	MarketConditionAPI getSpecificCondition(String token);
	
	
	/**
	 * Get the first condition of a specific type; id is non-unique.
	 * @param id
	 * @return
	 */
	MarketConditionAPI getFirstCondition(String id);
	boolean isInEconomy();
	
	
}





