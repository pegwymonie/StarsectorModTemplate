package com.fs.starfarer.api.campaign;


public interface AsteroidAPI extends SectorEntityToken {

}
