package com.fs.starfarer.api.campaign;


public interface PluginPickerAPI {

	FleetStubConverterPlugin pickFleetStubConverter(CampaignFleetAPI fleet);
	FleetStubConverterPlugin pickFleetStubConverter(FleetStubAPI stub);

}
