package com.fs.starfarer.api.campaign.ai;

public interface FleetStubAI {
	void advance(float amount);
}
