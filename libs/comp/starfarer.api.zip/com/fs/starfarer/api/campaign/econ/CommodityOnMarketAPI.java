package com.fs.starfarer.api.campaign.econ;

import com.fs.starfarer.api.combat.MutableStat;
import com.fs.starfarer.api.combat.StatBonus;

/**
 * 
 * 
 * @author Alex Mosolov
 *
 * Copyright 2014 Fractal Softworks, LLC
 */
public interface CommodityOnMarketAPI {

	String getId();
	
	MutableStat getSupply();
	MutableStat getGreed();
	
	float getSupplyValue();
	float getGreedValue();
	
	CommoditySpecAPI getCommodity();

	
	float getStockpile();
	void setStockpile(float stockpile);
	
	void addToStockpile(float quantity);
	void removeFromStockpile(float quantity);

	MarketAPI getMarket();

	String getDemandClass();
	MarketDemandAPI getDemand();

	float getUtilityOnMarket();

	boolean isPersonnel();
	boolean isFuel();

	StatBonus getPlayerPriceMod();

	boolean isNonEcon();

	float getProjectedIncoming();

	float getAboveDemandStockpile();

	CommodityFlowAPI getFlow();
	
}




