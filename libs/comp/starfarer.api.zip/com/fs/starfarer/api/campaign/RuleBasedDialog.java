package com.fs.starfarer.api.campaign;

import com.fs.starfarer.api.campaign.events.CampaignEventPlugin;


public interface RuleBasedDialog {
	void notifyActivePersonChanged();
	void setActiveMission(CampaignEventPlugin mission);
	
	void updateMemory();
	
	void reinit(boolean withContinueOnRuleFound);
}
