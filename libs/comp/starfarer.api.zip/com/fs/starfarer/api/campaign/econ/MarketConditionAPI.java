package com.fs.starfarer.api.campaign.econ;

import com.fs.starfarer.api.impl.campaign.procgen.ConditionGenDataSpec;

public interface MarketConditionAPI {
	
	
	/**
	 * Id of the condition spec, i.e. "ore_sparse".
	 * @return
	 */
	String getId();
	String getName();
	MarketConditionPlugin getPlugin();
	
	/**
	 * Globally unique id for this specific condition, i.e. "ore_sparse_b44c3".
	 * @return
	 */
	String getIdForPluginModifications();
	boolean isFromEvent();
	boolean isSurveyed();
	void setSurveyed(boolean wasSurveyed);
	boolean requiresSurveying();
	ConditionGenDataSpec getGenSpec();
}
