/**
 * 
 */
package com.fs.starfarer.api.campaign.rules;

public class Option {
	public float order;
	public String id;
	public String text;
}