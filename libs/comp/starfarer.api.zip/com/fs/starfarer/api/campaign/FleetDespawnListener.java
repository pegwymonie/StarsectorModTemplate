package com.fs.starfarer.api.campaign;

import com.fs.starfarer.api.campaign.CampaignEventListener.FleetDespawnReason;

public interface FleetDespawnListener {
	void reportFleetDespawnedToListener(FleetOrStubAPI fleet, FleetDespawnReason reason, Object param);
}
