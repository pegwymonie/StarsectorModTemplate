package com.fs.starfarer.api.campaign;

import java.awt.Color;
import java.util.List;
import java.util.Random;
import java.util.Set;

import org.json.JSONObject;

import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.characters.RelationshipAPI;
import com.fs.starfarer.api.characters.FullName.Gender;
import com.fs.starfarer.api.fleet.ShipRolePick;
import com.fs.starfarer.api.loading.FleetCompositionDoctrineAPI;

/**
 * @author Alex Mosolov
 *
 * Copyright 2012 Fractal Softworks, LLC
 */
public interface FactionAPI {
	void adjustRelationship(String id, float delta);
	boolean adjustRelationship(String id, float delta, RepLevel limit);
	void setRelationship(String id, float newValue);
	void setRelationship(String id, RepLevel level);
	
	boolean ensureAtBest(String id, RepLevel level);
	boolean ensureAtWorst(String id, RepLevel level);

	RepLevel getRelationshipLevel(FactionAPI faction);
	RepLevel getRelationshipLevel(String id);
	boolean isAtWorst(String id, RepLevel level);
	boolean isAtWorst(FactionAPI other, RepLevel level);
	boolean isAtBest(String id, RepLevel level);
	boolean isAtBest(FactionAPI other, RepLevel level);
	boolean isHostileTo(FactionAPI other);
	boolean isHostileTo(String other);
	
//	boolean isNeutralTo(FactionAPI other);
//	boolean isFriendlyTo(FactionAPI other);
//	boolean isNeutralTo(String other);
//	boolean isFriendlyTo(String other);
	
	
	float getRelationship(String id);
	String getId();
	String getDisplayName();
	String getDisplayNameWithArticle();
	
	Color getColor();
	Color getBaseUIColor();
	Color getGridUIColor();
	Color getDarkUIColor();
	Color getSecondaryUIColor();
	
	/**
	 * Brighter/slightly cyan version of getBaseUIColor()
	 * @return
	 */
	Color getBrightUIColor();
		
	boolean isNeutralFaction();
	boolean isPlayerFaction();
	
	
	List<String> getStockFleetIds();

//	boolean isIllegal(String commodityId);
	//boolean isHostile(FactionAPI other);
	
	MemoryAPI getMemory();
	
	
	
	/**
	 * May add more than one ship if a fallback specifies to add multiple ships.
	 * (For example, 2 small freighters if a medium freighter isn't available.)
	 * 
	 * Returns a total weight of ships added to the fleet. Generally will return
	 * 1 when ships were added, 0 when they weren't, and a number >1 when adding, say,
	 * a medium ship instead of a small one because no small ones are available.
	 * @param role
	 * @param qualityFactor
	 * @param fleet
	 * @return
	 */
	float pickShipAndAddToFleet(String role, float qualityFactor, CampaignFleetAPI fleet);
	
	String getFleetTypeName(String type);
	String getDisplayNameLong();
	String getDisplayNameLongWithArticle();
	String getEntityNamePrefix();
	
	
	Color getRelColor(String otherFactionId);
	Set<String> getIllegalCommodities();
	boolean isIllegal(String commodityId);
	boolean isIllegal(CargoStackAPI stack);
	
	List<ShipRolePick> pickShip(String role, float qualityFactor);
	List<ShipRolePick> pickShip(String role, float qualityFactor, Random random);
	
	void makeCommodityIllegal(String commodityId);
	void makeCommodityLegal(String commodityId);
	
	float getTariffFraction();
	float getTollFraction();
	float getFineFraction();
	String getInternalCommsChannel();
	
	PersonAPI createRandomPerson();
	PersonAPI createRandomPerson(Gender gender);
	String getLogo();
	
	JSONObject getCustom();
	MemoryAPI getMemoryWithoutUpdate();
	Color getRelColor(RepLevel level);
	RelationshipAPI getRelToPlayer();
	
	String getRank(String id);
	String getPost(String id);
	String getDisplayNameIsOrAre();
	
	FleetCompositionDoctrineAPI getCompositionDoctrine();
	String pickPersonality();
	boolean getCustomBoolean(String key);
	String getCustomString(String key);
	
	
	boolean isShowInIntelTab();
	void setShowInIntelTab(boolean isShowInIntelTab);
	String getCrest();
	String getPersonNamePrefix();
	String getPersonNamePrefixAOrAn();
	String pickRandomShipName();
	float pickShipAndAddToFleet(String role, float qualityFactor, CampaignFleetAPI fleet, Random random);
	List<String> getHullMods();
	
	Set<String> getVariantsForRole(String roleId);
	PersonAPI createRandomPerson(Gender gender, Random random);
	PersonAPI createRandomPerson(Random random);
	float getCustomFloat(String key);
	int getSecondarySegments();
}



