package com.fs.starfarer.api.campaign;

import java.util.List;

public interface GenericPluginManagerAPI {

	public static interface GenericPlugin {
		int getHandlingPriority(Object params);
	}
	
	boolean hasPlugin(Class c);
	void addPlugin(GenericPlugin plugin);
	void removePlugin(GenericPlugin plugin);
	List<GenericPlugin> getPluginsOfClass(Class c);
	<T>T pickPlugin(Class<T> c, Object params);
}
