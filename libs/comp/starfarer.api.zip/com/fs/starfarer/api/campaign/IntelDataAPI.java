package com.fs.starfarer.api.campaign;

import java.util.List;

import com.fs.starfarer.api.campaign.comm.CommMessageAPI;

public interface IntelDataAPI {
	List<SectorEntityToken> getCommSnifferLocations();

	List<CommMessageAPI> getMessagesCopy();
}
