package com.fs.starfarer.api.campaign.econ;

import com.fs.starfarer.api.combat.MutableStat;

public interface MarketDemandAPI {
	
	MutableStat getDemand();
	
	float getDemandValue();
	
	/**
	 * Amount of demand that will not actually be deducted from local stockpiles.
	 * Useful for things that aren't consumed by demand, such as crew, and for
	 * creating stockpiles.
	 * 
	 * Only flat mods should be applied to this.
	 * The actual value will use the multipliers from getDemand().
	 * @return
	 */
	MutableStat getNonConsumingDemand();
	
	/**
	 * getNonConsumingDemand() multiplied by all the mult values from getDemand().
	 * @return
	 */
	float getNonConsumingDemandValue();
	
	
	/**
	 * Stockpile divided by the demand value.
	 * @return
	 */
	float getFractionMet();
	
	/**
	 * Same as getFractionMet(), but clamped to [0, 1].
	 * @return
	 */
	float getClampedFractionMet();
	
	
	CommoditySpecAPI getBaseCommodity();
	
	float getStockpileUtility();
}



