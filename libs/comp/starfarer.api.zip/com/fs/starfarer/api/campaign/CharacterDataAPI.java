package com.fs.starfarer.api.campaign;

import java.util.Map;
import java.util.Set;

import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.PersonAPI;

public interface CharacterDataAPI {

	PersonAPI getPerson();
	
	Set<String> getCommChannels();
	void addCommChannel(String channel);
	void removeCommChannel(String channel);
	
	String getName();

	
	MemoryAPI getMemory();
	MemoryAPI getMemoryWithoutUpdate();

	Set<String> getAbilities();
	void addAbility(String id);
	void removeAbility(String id);

	Map<String, Object> getCustom();

	Set<String> getHullMods();
	void addHullMod(String id);
	void removeHullMod(String id);

	boolean knowsHullMod(String id);

}
