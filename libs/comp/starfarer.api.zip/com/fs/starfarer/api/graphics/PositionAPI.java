package com.fs.starfarer.api.graphics;

import com.fs.starfarer.api.input.InputEventAPI;

public interface PositionAPI {
	float getX();
	float getY();
	float getWidth();
	float getHeight();
	
	boolean containsEvent(InputEventAPI event);
}
