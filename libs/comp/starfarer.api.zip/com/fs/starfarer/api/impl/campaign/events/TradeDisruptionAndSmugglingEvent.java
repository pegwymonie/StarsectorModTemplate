package com.fs.starfarer.api.impl.campaign.events;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BaseOnMessageDeliveryScript;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.SubmarketPlugin;
import com.fs.starfarer.api.campaign.comm.CommMessageAPI;
import com.fs.starfarer.api.campaign.comm.MessagePriority;
import com.fs.starfarer.api.campaign.econ.CommodityOnMarketAPI;
import com.fs.starfarer.api.campaign.econ.EconomyAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketConnectionAPI;
import com.fs.starfarer.api.campaign.econ.SubmarketAPI;
import com.fs.starfarer.api.campaign.events.CampaignEventTarget;
import com.fs.starfarer.api.campaign.events.CampaignEventPlugin.PriceUpdatePlugin.PriceType;
import com.fs.starfarer.api.impl.campaign.fleets.EconomyFleetManager;
import com.fs.starfarer.api.impl.campaign.fleets.EconomyFleetManager.TradeConnectionCommodity;
import com.fs.starfarer.api.impl.campaign.fleets.EconomyFleetManager.TradeConnectionData;
import com.fs.starfarer.api.impl.campaign.fleets.EconomyFleetManager.TradeSummary;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Events;
import com.fs.starfarer.api.impl.campaign.ids.Strings;
import com.fs.starfarer.api.impl.campaign.shared.MarketConnectionActivityData;
import com.fs.starfarer.api.impl.campaign.shared.PlayerTradeDataForSubmarket;
import com.fs.starfarer.api.impl.campaign.shared.SectorActivityTracker;
import com.fs.starfarer.api.impl.campaign.shared.SharedData;
import com.fs.starfarer.api.impl.campaign.submarkets.BaseSubmarketPlugin.ShipSalesData;
import com.fs.starfarer.api.util.IntervalUtil;

public class TradeDisruptionAndSmugglingEvent extends BaseEventPlugin {

	public static boolean DISABLED = true;
	
	public static class AffectedCommodity {
		public CommodityOnMarketAPI commodity;
//		public float pricePercent;
//		public float priceFlat;
		public float volume;
		public boolean isShortage;
		public float delta;
//		public float disruptionQuantity;
//		public float preDisruptionStockpile;
//		public float targetStockpile;
		public AffectedCommodity(CommodityOnMarketAPI commodity) {
			this.commodity = commodity;
		}
	}
	
	
	public static final float MIN_DAYS_BETWEEN_REPORTS = 60f;
	public static final float MAX_DISRUPTION_TIMEOUT = 5f;
	
	public static Logger log = Global.getLogger(TradeDisruptionAndSmugglingEvent.class);
	
	public static float STOCKPILE_SHORTAGE_MULT = 0.75f;
	public static float STOCKPILE_GLUT_MULT = 1.25f;
	public static float LOSS_THRESHOLD = 0.25f;
	
	private float elapsedDaysSinceLastDisruptionReport = MIN_DAYS_BETWEEN_REPORTS * (float) Math.random();
	private float elapsedDaysSinceLastSmugglingReport = MIN_DAYS_BETWEEN_REPORTS * (float) Math.random();
	private String tradeConditionToken = null;
	private String smugglingConditionToken = null;
	
	private IntervalUtil timer = new IntervalUtil(1.5f, 2.5f);
	private MessagePriority messagePriority = MessagePriority.CLUSTER;
	
	private int smugglingPenalty = 0;
	private int prevSmugglingPenalty = 0;
	
	private float smugglingLossFraction = 0f;
	
	private List<String> highlights = null;
	private List<AffectedCommodity> disruptedCommodities = new ArrayList<AffectedCommodity>();
	//private boolean ensureDisrupted = false;
	private float disruptionTimeout = 0f;
	
	public void init(String type, CampaignEventTarget eventTarget) {
		super.init(type, eventTarget, false);
		
		//messagePriority = getDefaultPriority();
		messagePriority = MessagePriority.SECTOR;
	}
	
	public void startEvent() {
		super.startEvent();
	}
	
	public void advance(float amount) {
		if (!isEventStarted()) return;
		if (isDone()) return;
		if (market == null) return;
		
//		if (market.getId().equals("hesperus")) {
//			System.out.println("sdfkwefhekwj");
//		}
		
		float days = Global.getSector().getClock().convertToDays(amount);
		elapsedDaysSinceLastDisruptionReport += days;
		elapsedDaysSinceLastSmugglingReport += days;
		
		disruptionTimeout -= days;
		if (disruptionTimeout <= 0) disruptionTimeout = 0f;
		
		
		timer.advance(days);
		if (timer.intervalElapsed()) {
			updateSmugglingPenalty();
			updateTradeDisruption();
		}
		
		//ensureDisruptedIfNeeded();
	}
	
	private void updateTradeDisruption() {
		//if (true) return;
		if (market != null && market.getSize() > 6) {
			return;
		}
		
		float totalSent = 0f;
		float totalLost = 0f;
		float totalSmugglingSent = 0f;
		float totalSmugglingLost = 0f;
		SectorActivityTracker activity = SharedData.getData().getActivityTracker();
		for (MarketAPI curr : Global.getSector().getEconomy().getMarketsCopy()) {
			if (curr == market) continue;
			if (!activity.hasConnectionData(market, curr)) continue;
			
			MarketConnectionAPI conn = Global.getSector().getEconomy().getConnection(market, curr);
			if (!conn.isEnabled()) continue;
			
			MarketConnectionActivityData data = activity.getConnectionData(market, curr);
			float sent = data.getTradePointsSent().getAverage();
			float lost = data.getTradePointsLost().getAverage();
			totalSent += sent;
			totalLost += lost;
			
			float smugglingSent = data.getSmugglingPointsSent().getAverage();
			float smugglingLost = data.getSmugglingPointsLost().getAverage();
			totalSmugglingSent += smugglingSent;
			totalSmugglingLost += smugglingLost;

			if (sent < 1) sent = 1;
			float fraction = lost / sent;
			float connMult = 1f + Math.min(1f, fraction);
			if (connMult < 1) connMult = 1;
			
			if (smugglingSent < 1) smugglingSent = 1;
			float smugglingFraction = smugglingLost / smugglingSent;
			float smugglingConnMult = 1f + Math.min(1f, smugglingFraction);
			if (smugglingConnMult < 1) smugglingConnMult = 1;
			

			if (!DISABLED) {
				conn.getPriceMod().modifyMult(getStatModId(), connMult);
				conn.getSmugglingMod().modifyMult(getStatModId(), connMult);
			}
			
			//log.info("Setting connection mult for [" + market.getName() + " <-> " + curr.getName() + "] to " + connMult);
		}
		
		
		if (totalSent < 1) totalSent = 1;
		if (totalSmugglingSent < 1) {
			smugglingLossFraction = 0f;
		} else {
			smugglingLossFraction = totalSmugglingLost / totalSmugglingSent;
			if (smugglingLossFraction > 1) smugglingLossFraction = 1;
			if (smugglingLossFraction < 0) smugglingLossFraction = 0;
		}
		
		
		float probMult = Global.getSettings().getEventSpec(Events.TRADE_DISRUPTION).getProbabilityMult();
		boolean shouldHaveCondition = (totalLost + totalSmugglingLost) * probMult > LOSS_THRESHOLD * (totalSent + totalSmugglingSent);
		boolean hasCondition = market.hasCondition(Conditions.EVENT_TRADE_DISRUPTION);
		
		if (DISABLED) shouldHaveCondition = false;
		
		if (hasCondition) {
			shouldHaveCondition = (elapsedDaysSinceLastDisruptionReport < MIN_DAYS_BETWEEN_REPORTS);
		} else if (disruptionTimeout > 0) {
			shouldHaveCondition = false;
		}
		
		boolean canHaveMore = getCurrentOngoing() < getMaxOngoing();;
		if (!canHaveMore && !hasCondition) {
			shouldHaveCondition = false;
		}
//		if (market.getId().equals("port_tse") && !shouldHaveCondition) {
//			System.out.println("fkh23fjkf32f");
//		}
		if (!hasCondition && shouldHaveCondition) {
//			log.info("Adding trade disruption condition to " + market.getName());
//			tradeConditionToken = market.addCondition(Conditions.EVENT_TRADE_DISRUPTION, true, this);
		} else if (hasCondition && !shouldHaveCondition) {
//			if (market.getId().equals("port_tse")) {
//				System.out.println("fkh23fjkf32f");
//			}
			log.info("Removing trade disruption condition from " + market.getName());
//			if (market.getId().equals("hesperus")) {
//				System.out.println("dsfuwehfjwefjk");
//			}
			for (AffectedCommodity com : getDisruptedCommodities()) {
				if (com.isShortage) {
					com.commodity.setStockpile(com.commodity.getStockpile() + com.delta);
				} else {
					com.commodity.setStockpile(Math.max(0, com.commodity.getStockpile() - com.delta));
				}
			}
			market.removeSpecificCondition(tradeConditionToken);
			disruptionTimeout = MAX_DISRUPTION_TIMEOUT;
			tradeConditionToken = null;
			hasCondition = false;
			shouldHaveCondition = false; // due to disruption timeout 
		}
		
		//if ((hasCondition || shouldHaveCondition) && elapsedDaysSinceLastDisruptionReport >= MIN_DAYS_BETWEEN_REPORTS) {
		if (!hasCondition && shouldHaveCondition) {
//			if (market.getId().equals("port_tse")) {
//				System.out.println("fkh23fjkf32f");
//			}
			market.removeSpecificCondition(tradeConditionToken);
			updateDisruptedCommodities();
			if (disruptedCommodities.isEmpty()) {
				market.removeSpecificCondition(tradeConditionToken);
				disruptionTimeout = MAX_DISRUPTION_TIMEOUT;
				tradeConditionToken = null;
				//ensureDisrupted = false;
			} else {
				//market.reapplyCondition(tradeConditionToken);
				log.info("Adding trade disruption condition to " + market.getName());
				tradeConditionToken = market.addCondition(Conditions.EVENT_TRADE_DISRUPTION, true, this);
				
				for (AffectedCommodity com : getDisruptedCommodities()) {
					if (com.isShortage) {
						float demand = com.commodity.getDemand().getDemandValue();
						if (demand < 100f) demand = 100f;
						float reduction = Math.min(demand, com.commodity.getStockpile()) * (1f - STOCKPILE_SHORTAGE_MULT);
						if (reduction <= 0) reduction = 0;
						com.delta = reduction;
						
						com.commodity.setStockpile(com.commodity.getStockpile() - reduction);
					} else {
						float increase = com.commodity.getStockpile() * (STOCKPILE_GLUT_MULT - 1f);
						com.delta = increase;
						
						com.commodity.setStockpile(com.commodity.getStockpile() + increase);
					}
					//com.commodity.setStockpile(0f);
					//com.targetStockpile = com.commodity.getAverageStockpile();
					Global.getSector().getEconomy().getExcluded().add(com.commodity, 
											MIN_DAYS_BETWEEN_REPORTS, MIN_DAYS_BETWEEN_REPORTS);
				}
				//ensureDisrupted = true;
				
				Global.getSector().reportEventStage(this, "report_td", null, messagePriority, new BaseOnMessageDeliveryScript() {
					public void beforeDelivery(CommMessageAPI message) {
						if (market.getContainingLocation() != Global.getSector().getPlayerFleet().getContainingLocation()) {
							// reducing message spam as there's a LOT of TD reports
							message.setShowInCampaignList(false);
						}
					}
				});
				elapsedDaysSinceLastDisruptionReport = 0f;
			}
		}
	}
	
	protected int getCurrentOngoing() {
		int total = 0;
		for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
			if (market.hasCondition(Conditions.EVENT_TRADE_DISRUPTION)) {
				total++;
			}
		}
		return total;
	}
	
	protected int getMaxOngoing() {
		int max = Global.getSettings().getEventSpec(Events.TRADE_DISRUPTION).getMaxOngoing();
		if (max < 0) return Integer.MAX_VALUE;
		return max;
	}

	private void updateSmugglingPenalty() {
		playerContribToSmuggling = computePlayerSmugglingPenalty();
//		if (market.getId().equals("jangala")) {
//			System.out.println("dsfkwejfwe");
//		}
//		smugglingPenalty = market.getBaseSmugglingStabilityValue() -
//							Math.round(market.getBaseSmugglingStabilityValue() * (1f - smugglingLossFraction)) +
//							(int) playerContribToSmuggling;
		smugglingPenalty = market.getBaseSmugglingStabilityValue();
		
		
		if (smugglingPenalty < 0) smugglingPenalty = 0;

		if (market.hasCondition(Conditions.FREE_PORT)) {
			smugglingPenalty = 0;
		}
		
		if (playerContribToSmuggling > 0 && smugglingPenalty > 0) {
			log.info("Player smuggling reduced stability for " + market.getName() + " by " + playerContribToSmuggling);
		}
		
		boolean hasCondition = market.hasCondition(Conditions.EVENT_SMUGGLING);
		boolean shouldHaveCondition = smugglingPenalty > 0;
		if (!hasCondition && shouldHaveCondition) {
			log.info("Adding smuggling condition to " + market.getName());
			smugglingConditionToken = market.addCondition(Conditions.EVENT_SMUGGLING, true, this);
		} else if (hasCondition && !shouldHaveCondition) {
			log.info("Removing smuggling condition to " + market.getName());
			market.removeSpecificCondition(smugglingConditionToken);
			smugglingConditionToken = null;
		}

		if (prevSmugglingPenalty != smugglingPenalty) {
			market.reapplyCondition(smugglingConditionToken);
			prevSmugglingPenalty = smugglingPenalty;
		}
		
		if (smugglingPenalty > 0 && elapsedDaysSinceLastSmugglingReport >= MIN_DAYS_BETWEEN_REPORTS) {
			if (playerContribToSmuggling > 0 && !market.hasCondition(Conditions.DECIVILIZED)) {
				Global.getSector().reportEventStage(this, "report_smuggling_player", messagePriority);
			} else {
				//Global.getSector().reportEventStage(this, "report_smuggling", messagePriority);
			}
			elapsedDaysSinceLastSmugglingReport = 0f;
		}
	}
	
//	private float getBaseDisruptionAmount(CommodityOnMarketAPI com) {
//		float stockpileMult = getStockpileMult();
//		float amount = com.getAverageStockpile() * (1f - stockpileMult);
//		if (amount < 50) amount = 50;
//		return Misc.getRounded(amount);
//	}
//	
//	private float getStockpileMult() {
//		switch ((int) market.getSize()) {
//		case 0:
//		case 1:
//			return 0f;
//		case 2:
//		case 3:
//			return 0.25f;
//		case 4:
//		case 5:
//			return 0.5f;
//		case 6:
//		case 7:
//		case 8:
//		case 9:
//			return 0.9f;
//		}
//		return 1f;
//	}
	
	
	private float computePlayerSmugglingPenalty() {
//		if (market.getId().equals("jangala")) {
//			System.out.println("32sdfewef");
//		}
		float averagePlayerValueTraded = 0;
		
		for (SubmarketAPI submarket : market.getSubmarketsCopy()) {
			SubmarketPlugin plugin = submarket.getPlugin();
			if (!plugin.isBlackMarket()) continue;
			if (!plugin.isParticipatesInEconomy()) continue;
			
			PlayerTradeDataForSubmarket tradeData =  SharedData.getData().getPlayerActivityTracker().getPlayerTradeData(submarket);
			
			for (CargoStackAPI stack : tradeData.getRecentPlayerSold().getStacksCopy()) {
				float qty = stack.getSize();
				float val = PlayerTradeDataForSubmarket.computeImpactOfHavingAlreadySold(market, 
										stack.getType(), stack.getData(), stack.getBaseValuePerUnit(), qty);
				
				averagePlayerValueTraded += val;
			}
			for (CargoStackAPI stack : tradeData.getRecentPlayerBought().getStacksCopy()) {
				float qty = stack.getSize();
				float val = PlayerTradeDataForSubmarket.computeImpactOfHavingAlreadyBought(market, 
										stack.getType(), stack.getData(), stack.getBaseValuePerUnit(), qty);
				averagePlayerValueTraded += val;
			}
			
//			if (market.getId().equals("jangala")) {
//				System.out.println("32sdfewef");
//			}
			for (ShipSalesData data : tradeData.getRecentlyPlayerBoughtShips()) {
				averagePlayerValueTraded += data.getTotalValue();
			}
			for (ShipSalesData data : tradeData.getRecentlyPlayerSoldShips()) {
				averagePlayerValueTraded += data.getTotalValue();
			}
			
		}
		
//		if (market.getId().equals("jangala")) {
//			System.out.println("32sdfewef");
//		}
		
		float maxPenalty = Global.getSettings().getFloat("economyMaxPlayerSmugglingStabilityPenalty");
		float baseVolume = market.getTradeVolume();
		int penalty = Math.round(averagePlayerValueTraded / baseVolume * maxPenalty);
		if (penalty > maxPenalty) penalty = (int) maxPenalty;
		
		return penalty;
	}

	
	
	public int getSmugglingPenalty() {
		return smugglingPenalty;
	}
	
	public float getPlayerContribToSmuggling() {
		return playerContribToSmuggling;
	}

	private boolean ended = false;

	private float playerContribToSmuggling;
	private void endEvent() {
		if (market != null && tradeConditionToken != null) {
			market.removeSpecificCondition(tradeConditionToken);
			market.removeSpecificCondition(smugglingConditionToken);
		}
		ended = true;
	}

	public boolean isDone() {
		return ended;
	}

	public String getEventName() {
		//return "Trade disruption at " + market.getName();
		//return "Trade disruption - " + market.getName();
		return "Trade disruptions";
		//return "Trade update - " + market.getName();
	}
	
	@Override
	public boolean useEventNameAsId() {
		return true;
	}

	@Override
	public CampaignEventCategory getEventCategory() {
		return CampaignEventCategory.EVENT;
	}
	
	public List<AffectedCommodity> getDisruptedCommodities() {
		return disruptedCommodities;
	}

	private void updateDisruptedCommodities() {
		disruptedCommodities.clear();
		
		EconomyAPI economy = Global.getSector().getEconomy();
		List<MarketConnectionActivityData> sorted = getConnectionsInMostAffectedOrder();
		TradeSummary summary = EconomyFleetManager.computeTradeSummaryForMarket(market);
		
		List<AffectedCommodity> allAffected = new ArrayList<AffectedCommodity>();
		
		for (int i = 0; i < sorted.size() && i < 3; i++) {
			MarketConnectionActivityData activityData = sorted.get(i);
			
			MarketConnectionAPI conn = activityData.getConnection();
			MarketAPI from = economy.getMarket(conn.getMarketIdOne());
			MarketAPI to = economy.getMarket(conn.getMarketIdTwo());
			
			if (to == market) {
				MarketAPI temp = from;
				from = to;
				to = temp;
			}
			TradeConnectionData tradeData = summary.getConnectionData(from, to);
			float smugglingConnMult = getConnWeightMultDueToSmugglingLoss(activityData);
			float tradeConnMult = getConnWeightMultDueToLoss(activityData);
			//float margin = Misc.getProfitMargin();
			for (TradeConnectionCommodity curr : tradeData.bought) {
				if (curr.commodity.isPersonnel()) continue;
				if (curr.commodity.getId().equals(Commodities.FOOD)) continue;
				//if (curr.commodity.getAverageStockpile() > 5000f) continue;
				
				CommodityOnMarketAPI localCom = market.getCommodityData(curr.commodity.getId());
				
				float supply = localCom.getSupplyValue();
				float demand = localCom.getDemand().getDemandValue();
				
				//if (localCom.getDemand().getDemandValue() <= 0) continue;
				if (supply <= 10 && demand <= 10) continue;
				if (supply > 5000 || demand > 5000 || localCom.getStockpile() > 5000) continue;
				
				float stockpileMult = STOCKPILE_SHORTAGE_MULT;
				boolean isShortage = true;
				if (supply > demand) {
					isShortage = false;
					stockpileMult = STOCKPILE_GLUT_MULT;
				}
				
//				boolean smuggling = conn.isAllTradeIsSmuggling() || from.isIllegal(curr.commodity) || to.isIllegal(curr.commodity);
//				float priceMult;
//				if (smuggling) {
//					priceMult = smugglingConnMult;
//				} else {
//					priceMult = tradeConnMult;
//				}
//				if (priceMult <= 1) continue;
//				
//				float priceFlat = (priceMult - 1f) * margin;
				
				PriceUpdate check = new PriceUpdate(localCom);
				check.updatePrices(stockpileMult);
				//if (!check.isSignificant(priceFlat, (priceMult - 1f) * 100f) || check.getType() == PriceType.NORMAL) continue;
				if (!check.isSignificant(0f, 0f) || check.getType() == PriceType.NORMAL) continue;
				
				AffectedCommodity com = new AffectedCommodity(curr.commodity);
				com.isShortage = isShortage;
//				com.volume = curr.volume * priceMult;
//				com.pricePercent = (priceMult - 1f) * 100f;
//				com.priceFlat = priceFlat;
//				com.disruptionQuantity = getBaseDisruptionAmount(curr.commodity);
//				com.preDisruptionStockpile = curr.commodity.getAverageStockpile();
				boolean okToInsert = true;
				for (AffectedCommodity ac : allAffected) {
					if (ac.commodity.getId().equals(com.commodity.getId())) {
						ac.volume += com.volume;
						okToInsert = false;
						break;
					}
				}
				if (okToInsert) {
					allAffected.add(com);
				}
			}
			
			
			for (TradeConnectionCommodity curr : tradeData.sold) {
				if (curr.commodity.isPersonnel()) continue;
				if (curr.commodity.getId().equals(Commodities.FOOD)) continue;
				
				CommodityOnMarketAPI localCom = market.getCommodityData(curr.commodity.getId());
				if (localCom.getSupplyValue() <= 0 && 
						localCom.getStockpile() * localCom.getUtilityOnMarket() <= localCom.getDemand().getDemandValue()) {
					continue;
				}
				
				boolean smuggling = conn.isAllTradeIsSmuggling() || from.isIllegal(curr.commodity) || to.isIllegal(curr.commodity);
				float priceMult;
				if (smuggling) {
					priceMult = 1f / smugglingConnMult;
				} else {
					priceMult = 1f / tradeConnMult;
				}
				if (priceMult >= 1) continue;
				
				
				PriceUpdate check = new PriceUpdate(localCom);
				//float priceFlat = (priceMult - 1f) * Math.min(margin * 0.5f, check.getDemandPrice() * 0.5f);
				float priceFlat = 0f;
				
				if (!check.isSignificant(priceFlat, (priceMult - 1f) * 100f) || check.getType() == PriceType.NORMAL) continue;
				
				AffectedCommodity com = new AffectedCommodity(curr.commodity);
				com.volume = curr.volume / priceMult;
//				com.pricePercent = (priceMult - 1f) * 100f;
//				com.priceFlat = priceFlat;
				
				boolean okToInsert = true;
				for (AffectedCommodity ac : allAffected) {
					if (ac.commodity.getId().equals(com.commodity.getId())) {
						ac.volume += com.volume;
						okToInsert = false;
						break;
					}
				}
				if (okToInsert) {
					allAffected.add(com);
				}
			}
		}
		
		List<AffectedCommodity> legal = new ArrayList<AffectedCommodity>();
		List<AffectedCommodity> illegal = new ArrayList<AffectedCommodity>();
		
		for (AffectedCommodity curr : allAffected) {
			if (market.isIllegal(curr.commodity)) {
				illegal.add(curr);
			} else {
				legal.add(curr);
			}
		}
		
		Collections.sort(illegal, new Comparator<AffectedCommodity>() {
			public int compare(AffectedCommodity o1, AffectedCommodity o2) {
				return (int) (o2.volume - o1.volume);
			}
		});
		Collections.sort(legal, new Comparator<AffectedCommodity>() {
			public int compare(AffectedCommodity o1, AffectedCommodity o2) {
				return (int) (o2.volume - o1.volume);
			}
		});
		
		List<AffectedCommodity> temp = new ArrayList<AffectedCommodity>();
		for (int i = 0; i < legal.size() && i < 3; i++) {
			temp.add(legal.get(i));
		}
		for (int i = 0; i < illegal.size() && i < 1; i++) {
			temp.add(illegal.get(i));
		}
		
		disruptedCommodities.clear();
		disruptedCommodities.addAll(temp);
	}
	
	
	/**
	 * 1 (no losses) to 2 (lost everything).
	 * @param data
	 * @return
	 */
	public float getConnWeightMultDueToLoss(MarketConnectionActivityData data) {
		float sent = data.getTradePointsSent().getAverage();
		float lost = data.getTradePointsLost().getAverage();

		if (sent < 1) sent = 1;
		float fraction = lost / sent;
		float connMult = 1f + Math.min(1f, fraction);
		if (connMult < 1) connMult = 1;
		
		return connMult;
	}
	
	/**
	 * 1 (no losses) to 2 (lost everything).
	 * @param data
	 * @return
	 */
	public float getConnWeightMultDueToSmugglingLoss(MarketConnectionActivityData data) {
		float sent = data.getSmugglingPointsSent().getAverage();
		float lost = data.getSmugglingPointsLost().getAverage();
		
		if (sent < 1) sent = 1;
		float fraction = lost / sent;
		float connMult = 1f + Math.min(1f, fraction);
		if (connMult < 1) connMult = 1;
		
		return connMult;
	}
	
	public List<MarketConnectionActivityData> getConnectionsInMostAffectedOrder() {
		SectorActivityTracker activity = SharedData.getData().getActivityTracker();
		List<MarketConnectionActivityData> sorted = new ArrayList<MarketConnectionActivityData>();
		
		EconomyAPI economy = Global.getSector().getEconomy();
		for (MarketAPI curr : economy.getMarketsCopy()) {
			if (curr == market) continue;
			if (!activity.hasConnectionData(market, curr)) continue;
			MarketConnectionActivityData data = activity.getConnectionData(market, curr);
			sorted.add(data);
		}

		Collections.sort(sorted, new Comparator<MarketConnectionActivityData>() {
			public int compare(MarketConnectionActivityData o1, MarketConnectionActivityData o2) {
				return (int) (o2.getTradePointsLost().getAverage() - o1.getTradePointsLost().getAverage());
			}
		});
		return sorted;
	}

//	protected void ensureDisruptedIfNeeded() {
//		if (ensureDisrupted && false) {
//			for (AffectedCommodity com : getDisruptedCommodities()) {
//				com.commodity.setAverageStockpile(com.targetStockpile);
//				com.commodity.setAverageStockpileAfterDemand(0f);
//				com.commodity.setStockpile(0f);
//			}
//		}
//	}
//	
//	@Override
//	public void reportPlayerOpenedMarket(MarketAPI market) {
//		super.reportPlayerOpenedMarket(market);
//		ensureDisrupted = false;
//	}

	public Map<String, String> getTokenReplacements() {
		Map<String, String> map = super.getTokenReplacements();

		map.put("$targetFaction", eventTarget.getEntity().getFaction().getDisplayName());
		
		map.put("$smugglingPenalty", "" + smugglingPenalty);
		
		EconomyAPI economy = Global.getSector().getEconomy();
		List<MarketConnectionActivityData> sorted = getConnectionsInMostAffectedOrder();
		
		highlights = new ArrayList<String>();
		
		String commoditySummary = "";
		for (AffectedCommodity com : getDisruptedCommodities()) {
			String line = "    " + com.commodity.getCommodity().getName() + ": ";
			PriceUpdate check = new PriceUpdate(com.commodity);
			//int price = check.getRoundedPriceForDisplay(com.priceFlat, com.pricePercent);
			int price = check.getRoundedPriceForDisplay();
			String priceStr = "";
			//if (com.pricePercent > 0) {
			if (com.isShortage) {
				priceStr += "price increased";// to ~" + price + Strings.C;
			} else {
				priceStr += "price decreased";// to ~" + price + Strings.C;
			}
			if (!priceStr.isEmpty()) {
				line += " " + priceStr;
				highlights.add("~" + price + Strings.C);
			}
			commoditySummary += line + "\n";
		}
		if (commoditySummary.isEmpty()) {
			commoditySummary = "None";
		}
		map.put("$commoditySummary", commoditySummary);
		
		
		
//		String routeSummary = "";
//		for (int i = 0; i < sorted.size() && i < 3; i++) {
//			MarketConnectionActivityData activityData = sorted.get(i);
//			MarketConnectionAPI conn = activityData.getConnection();
//			MarketAPI from = economy.getMarket(conn.getMarketIdOne());
//			MarketAPI to = economy.getMarket(conn.getMarketIdTwo());
//			if (to == market) {
//				MarketAPI temp = from;
//				from = to;
//				to = temp;
//			}
//			String section = "    " + to.getName();
//			if (to.getStarSystem() != null) {
//				section += " (" + to.getStarSystem().getBaseName() + " star system)";
//			} else {
//				section += " (hyperspace)";
//			}
//			//highlights.add(to.getName());
//			
//			routeSummary += section + "\n";
//		}
//		
//		//$routeSummary
//		map.put("$routeSummary", routeSummary);
		
		highlights.add("" + smugglingPenalty);
		
		return map;
	}
	
	
	

	@Override
	public Color[] getHighlightColors(String stageId) {
		return super.getHighlightColors(stageId);
	}

	@Override
	public String[] getHighlights(String stageId) {
		//return super.getHighlights(stageId);
		if (!stageId.equals("report_td") &&
				!stageId.equals("report_smuggling_player") &&
				!stageId.equals("report_smuggling")) {
			return null;
		}
		// needed since that's where highlights are computed
		getTokenReplacements();
		
		if (highlights == null) return null;
		return highlights.toArray(new String [0]);
	}
	
	
	@Override
	public List<String> getRelatedCommodities() {
		List<String> result = new ArrayList<String>();
		for (AffectedCommodity com : getDisruptedCommodities()) {
			result.add(com.commodity.getId());
		}
		return result;
	}
	
	@Override
	public List<PriceUpdatePlugin> getPriceUpdates() {
		List<PriceUpdatePlugin> updates = new ArrayList<PriceUpdatePlugin>();
		for (AffectedCommodity com : getDisruptedCommodities()) {
			updates.add(new PriceUpdate(com.commodity));
		}
		return updates;
	}
	
	public boolean showAllMessagesIfOngoing() {
		return false;
	}
	
	public boolean showLatestMessageIfOngoing() {
//		System.out.println("Market: " + market.getId());
//		if (market.getId().equals("sphinx")) {
//			System.out.println("sdfwfew");
//		}
		return market != null && market.hasCondition(Conditions.EVENT_TRADE_DISRUPTION);
	}	
}




