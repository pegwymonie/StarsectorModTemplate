package com.fs.starfarer.api.impl.campaign.missions;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.CommodityOnMarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.events.CampaignEventManagerAPI;
import com.fs.starfarer.api.campaign.events.CampaignEventPlugin;
import com.fs.starfarer.api.campaign.events.CampaignEventTarget;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.MissionCompletionRep;
import com.fs.starfarer.api.impl.campaign.ids.Events;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;

public class MarketProcurementMission extends BaseCampaignMission {
	
	public static final String PERSON_CHECKOUT_REASON = "MPM_mission_contact";
	
	private static final float MIN_BONUS_DUR = 5f;
	
	private MarketAPI market; 
	private PersonAPI contact = null;
	private String commodityId = null;
	private float baseReward;
	private float bonusReward;
	private float price = 100f;
	private float quantity = 10;
	private float preDuration = 1f;
	private float baseDuration = 1f;
	private float bonusDuration = 1f;
	
	private CommodityOnMarketAPI com;
	private MissionCompletionRep repChange = null;
	
	private IntervalUtil randomCancel = new IntervalUtil(4, 6);
	
	public MarketProcurementMission(String marketId, PersonAPI contact,
										 String commodityId, float price, float quantity, float bonusReward,
										 float preDuration, float baseDuration, float bonusDuration,
										 MissionCompletionRep rep) {
		
		this.market = Global.getSector().getEconomy().getMarket(marketId);
		this.contact = contact;
		this.commodityId = commodityId;
		this.price = price;
		this.quantity = quantity;
		this.baseDuration = baseDuration;
		this.bonusDuration = bonusDuration;
		this.preDuration = preDuration;
		this.repChange = rep;
		this.bonusReward = bonusReward;
		
		com = market.getCommodityData(commodityId);
		
		baseReward = price * quantity;
		
		CampaignEventManagerAPI eventManager = Global.getSector().getEventManager();
		
		CampaignEventTarget target = new CampaignEventTarget(market);
		target.setExtra(Misc.genUID() + com.getId());
		
		event = eventManager.primeEvent(target, Events.MARKET_PROCUREMENT, this);
		
		Global.getSector().getImportantPeople().checkOutPerson(contact, PERSON_CHECKOUT_REASON);
		
		// hack to set the target after priming the event so that multiple events
		// can be primed for the same target market etc
		//((BaseEventPlugin)event).setTarget(new CampaignEventTarget(market));
	}
	
	
	public void advance(float amount) {
		float days = Global.getSector().getClock().convertToDays(amount);
		
		if (preDuration > 0) {
			preDuration -= days;
		} else {
			baseDuration -= days;
			bonusDuration -= days;
			if (baseDuration < 10) {
				Global.getSector().getImportantPeople().returnPerson(contact, PERSON_CHECKOUT_REASON);
				Global.getSector().getMissionBoard().removeMission(this, true);
			}
			if (bonusDuration <= MIN_BONUS_DUR) {
				bonusDuration = 0f;
			}
		}
		
		randomCancel.advance(days);
		if (randomCancel.intervalElapsed()) {
			if ((float) Math.random() < 0.5f) {
				Global.getSector().getImportantPeople().returnPerson(contact, PERSON_CHECKOUT_REASON);
				Global.getSector().getMissionBoard().removeMission(this, true);
			}
		}
	}
	
	public float getBonusReward() {
		return bonusReward;
	}

	public boolean hasBonus(float eventElapsed) {
		return (bonusDuration - eventElapsed) > 0;
	}
	
	@Override
	public String getPostingStage() {
		if (hasBonus(0f)) return "posting_bonus";
		return super.getPostingStage();
	}


	public String getName() {
		return "Procurement Contract - " + com.getCommodity().getName() + ", " + (int) quantity + " units";
	}

	public void playerAccept(SectorEntityToken entity) {
		super.playerAccept(entity);
		CampaignEventManagerAPI eventManager = Global.getSector().getEventManager();
		eventManager.startEvent(event);
	}

	public PersonAPI getContact() {
		return contact;
	}

	public MarketAPI getMarket() {
		return market;
	}

	public String getCommodityId() {
		return commodityId;
	}

	public float getPrice() {
		return price;
	}

	public float getBaseDuration() {
		return baseDuration;
	}
	
	public float getPreDuration() {
		return preDuration;
	}

	public float getBonusDuration() {
		return bonusDuration;
	}

	public CommodityOnMarketAPI getCOM() {
		return com;
	}

	public float getQuantity() {
		return quantity;
	}

	public float getBaseReward() {
		return baseReward;
	}

	public CampaignEventPlugin getPrimedEvent() {
		return event;
	}
	
	public PersonAPI getImportantPerson() {
		return contact;
	}

	public MissionCompletionRep getRepChange() {
		return repChange;
	}

	public String getFactionId() {
		//return Factions.INDEPENDENT;
		//return mission.getCon
		return getContact().getFaction().getId();
		//return market.getFactionId();
	}

}




