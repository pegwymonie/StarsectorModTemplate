package com.fs.starfarer.api.impl.campaign.procgen.themes;

public class Themes {

	public static final String NO_THEME = "no_theme";
	
	public static final String DERELICTS = "derelicts";
	public static final String REMNANTS = "remnants";
	public static final String RUINS = "ruins";
	public static final String MISC = "misc";
	
}
