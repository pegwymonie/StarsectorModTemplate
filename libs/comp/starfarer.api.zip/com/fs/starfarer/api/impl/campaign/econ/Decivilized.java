package com.fs.starfarer.api.impl.campaign.econ;

import com.fs.starfarer.api.campaign.econ.CommodityOnMarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;

public class Decivilized extends BaseHazardCondition {
	
	private static String [] tags = new String [] {
		Commodities.TAG_HEAVY_INDUSTRY_IN,
		Commodities.TAG_HEAVY_INDUSTRY_OUT,
		Commodities.TAG_LIGHT_INDUSTRY_IN,
		Commodities.TAG_LIGHT_INDUSTRY_OUT,
		Commodities.TAG_REFINING_IN, 
		Commodities.TAG_REFINING_OUT, 
	};
	
	public void apply(String id) {
		super.apply(id);
		
		if (market.isPlanetConditionMarketOnly()) return;
		
		market.getDemand(Commodities.DOMESTIC_GOODS).getDemand().modifyMult(id, ConditionData.DECIV_GOODS_PENALTY);
		market.getDemand(Commodities.LUXURY_GOODS).getDemand().modifyMult(id, ConditionData.DECIV_GOODS_PENALTY);
		market.getDemand(Commodities.ORGANS).getDemand().modifyMult(id, ConditionData.DECIV_GOODS_PENALTY);
		
		market.getCommodityData(Commodities.CREW).getSupply().modifyMult(id, ConditionData.DECIV_CREW_MULT);
		
		float pop = getPopulation(market);
		market.getDemand(Commodities.HAND_WEAPONS).getDemand().modifyFlat(id, Math.max(10f, pop * ConditionData.DECIV_WEAPONS_MULT));
		market.getDemand(Commodities.SUPPLIES).getDemand().modifyFlat(id, Math.max(10f, pop * ConditionData.DECIV_SUPPLIES));
		market.getDemand(Commodities.DRUGS).getDemand().modifyMult(id, ConditionData.DECIV_DRUGS_MULT);
		
		for (CommodityOnMarketAPI com : market.getCommoditiesWithTags(tags)) {
			com.getSupply().modifyMult(id, ConditionData.DECIV_PRODUCTION_PENALTY);
		}
		for (CommodityOnMarketAPI com : market.getCommoditiesWithTags(Commodities.FOOD)) {
			com.getSupply().modifyMult(id, ConditionData.DECIV_FOOD_PENALTY);
		}
		
		//market.getDemandPriceMod().modifyMult(id, ConditionData.DECIV_DEMAND_PRICE_MULT);
		market.getStability().modifyFlat(id, ConditionData.STABILITY_DECIVILIZED, "Decivilized");
	}

	public void unapply(String id) {
		super.unapply(id);
		
		if (market.isPlanetConditionMarketOnly()) return;
		
		market.getCommodityData(Commodities.CREW).getSupply().unmodify(id);
		
		market.getDemand(Commodities.DOMESTIC_GOODS).getDemand().unmodify(id);
		market.getDemand(Commodities.LUXURY_GOODS).getDemand().unmodify(id);
		market.getDemand(Commodities.ORGANS).getDemand().unmodify(id);
		
		market.getDemand(Commodities.HAND_WEAPONS).getDemand().unmodify(id);
		market.getDemand(Commodities.SUPPLIES).getDemand().unmodify(id);
		market.getDemand(Commodities.DRUGS).getDemand().unmodify(id);
		
		for (CommodityOnMarketAPI com : market.getCommoditiesWithTags(tags)) {
			com.getSupply().unmodify(id);
		}
		
		for (CommodityOnMarketAPI com : market.getCommoditiesWithTags(Commodities.FOOD)) {
			com.getSupply().unmodify(id);
		}
		
		//market.getDemandPriceMod().unmodify(id);
		market.getStability().unmodify(id);
	}

}
