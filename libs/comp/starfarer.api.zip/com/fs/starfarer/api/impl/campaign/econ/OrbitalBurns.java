package com.fs.starfarer.api.impl.campaign.econ;

import com.fs.starfarer.api.campaign.econ.CommodityOnMarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;

public class OrbitalBurns extends BaseMarketConditionPlugin {

	public void apply(String id) {
		for (CommodityOnMarketAPI com : market.getCommoditiesWithTag(Commodities.FOOD)) {
			com.getSupply().modifyMult(id, ConditionData.ORBITAL_BURNS_FOOD_BONUS);
		}
	}

	public void unapply(String id) {
		for (CommodityOnMarketAPI com : market.getCommoditiesWithTag(Commodities.FOOD)) {
			com.getSupply().unmodify(id);
		}
	}

}
