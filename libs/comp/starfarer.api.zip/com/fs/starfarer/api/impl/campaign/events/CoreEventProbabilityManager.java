package com.fs.starfarer.api.impl.campaign.events;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BaseCampaignEventListener;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.FleetAssignment;
import com.fs.starfarer.api.campaign.PlayerMarketTransaction;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.SubmarketPlugin;
import com.fs.starfarer.api.campaign.SectorEntityToken.VisibilityLevel;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.events.CampaignEventManagerAPI;
import com.fs.starfarer.api.campaign.events.CampaignEventTarget;
import com.fs.starfarer.api.campaign.events.EventProbabilityAPI;
import com.fs.starfarer.api.impl.campaign.econ.BaseMarketConditionPlugin;
import com.fs.starfarer.api.impl.campaign.events.FactionHostilityEvent.FactionHostilityPairKey;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Events;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.impl.campaign.shared.SharedData;
import com.fs.starfarer.api.impl.campaign.shared.PlayerActivityTracker.FleetStatsSnapshot;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import com.fs.starfarer.api.util.Misc.FleetFilter;

public class CoreEventProbabilityManager extends BaseCampaignEventListener implements EveryFrameScript {
	public static Logger log = Global.getLogger(CoreEventProbabilityManager.class);
	
	protected float eventCheckInterval;
	protected IntervalUtil foodShortageTracker;
	protected IntervalUtil customsInspectionTracker;
	protected IntervalUtil commSnifferInvestigationTracker;
	protected IntervalUtil tradeDisruptionTracker;
	protected CampaignEventManagerAPI eventManager;
	
	protected IntervalUtil personBountyTracker;
	protected IntervalUtil factionHostilityTracker;
	protected float maxPersonBounties;
	protected boolean increasedSmugglingInvestigationChanceThisFrame = false;
	
	public CoreEventProbabilityManager() {
		super(true);
		
		eventCheckInterval = Global.getSettings().getFloat("eventCheckInterval");
		
		tradeDisruptionTracker = new IntervalUtil(0.5f, 1.5f);
		customsInspectionTracker = new IntervalUtil(0.25f, 0.75f);
		
		foodShortageTracker = createTracker();
		commSnifferInvestigationTracker = createTracker();
		
		maxPersonBounties = Global.getSettings().getFloat("maxPersonBounties");
		personBountyTracker = new IntervalUtil(eventCheckInterval * 0.75f / maxPersonBounties * 0.25f, eventCheckInterval * 1.25f / maxPersonBounties * 0.25f);
		
		factionHostilityTracker = createTracker();
	}
	
	protected Object readResolve() {
		if (factionHostilityTracker == null) {
			factionHostilityTracker = createTracker();
		}
		return this;
	}
	
	protected IntervalUtil createTracker() {
		IntervalUtil tracker = new IntervalUtil(eventCheckInterval * 0.75f, eventCheckInterval * 1.25f);
		tracker.setElapsed(eventCheckInterval * 0.75f);
		return tracker;
	}
	
	protected boolean firstFrame = true;
	public void advance(float amount) {
		Global.getSettings().profilerBegin(this.getClass().getSimpleName() + ".advance()");
		if (eventManager == null) eventManager = Global.getSector().getEventManager();
		float days = Global.getSector().getClock().convertToDays(amount);
		
		if (firstFrame) {
			startTradeDisruptionEventsIfNeeded(days, true);
			eventManager.startEvent(null, Events.REP_TRACKER, null);
			eventManager.startEvent(null, Events.TRADE_INFO, null);
			eventManager.startEvent(null, Events.OFFICER_MANAGER, null);
			eventManager.startEvent(null, Events.NEARBY_EVENTS, null);
			firstFrame = false;
		}
		
		startTradeDisruptionEventsIfNeeded(days, false);
		updateFoodShortageProbatility(days);
		updateFactionHostilityProbability(days);
		//updateCommSnifferInvestigationProbability(days);
		//checkForCustomsInspectionEvents(days);
		
		startPersonBountiesIfNeeded(days);
		
		increasedSmugglingInvestigationChanceThisFrame = false;
		Global.getSettings().profilerEnd();
	}

	protected void startPersonBountiesIfNeeded(float days) {
		personBountyTracker.advance(days);
		if (personBountyTracker.intervalElapsed()) {
			int ongoing = SharedData.getData().getPersonBountyEventData().getNumOngoing();
			if (ongoing < maxPersonBounties && (float) Math.random() > 0.5f) {
				Global.getSector().getEventManager().startEvent(null, Events.PERSON_BOUNTY, null);
			}
		}
	}

	protected void updateCommSnifferInvestigationProbability(float days) {
		commSnifferInvestigationTracker.advance(days);
		if (commSnifferInvestigationTracker.intervalElapsed()) {
			log.info("");
			log.info("Updating comm sniffer investigation probabilities on " + Global.getSector().getClock().getDateString());
			
			for (SectorEntityToken entity : Global.getSector().getIntel().getCommSnifferLocations()) {
				EventProbabilityAPI ep = eventManager.getProbability(Events.INVESTIGATION_COMM_SNIFFER, entity);
				if (eventManager.isOngoing(ep)) {
					continue;
				}
				float probabilityIncrease = 0.1f;
				ep.increaseProbability(probabilityIncrease);
				log.info("Increasing comm sniffer investigation probability for " + entity.getName() + " by " + probabilityIncrease + ", is now " + ep.getProbability());
			}
		}
	}
	

	protected FleetStatsSnapshot prevStats = null;
	protected void checkForCustomsInspectionEvents(float days) {
		if (true) return;
		
		customsInspectionTracker.advance(days);
		if (customsInspectionTracker.intervalElapsed()) {
			if (eventManager.isOngoing(null, Events.CUSTOMS_INSPECTION)) {
				return;
			}
			
			CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
			if (playerFleet.isInHyperspaceTransition()) return;
			if (playerFleet.getCargo().getFuel() <= 0 && playerFleet.isInHyperspace()) return;
			
			StarSystemAPI starSystem = Misc.getNearbyStarSystem(playerFleet);
			if (starSystem == null) return;
			
			
			FleetStatsSnapshot currStats = SharedData.getData().getPlayerActivityTracker().getPlayerFleetStats();
			if (prevStats != null) {
				if (currStats.getCargoOnBoard() > prevStats.getCargoOnBoard() * 2f
						|| currStats.getCargoOnBoard() - prevStats.getCargoOnBoard() > 2000f) {
					SharedData.getData().resetCustomsTimeouts();
				}
				if (currStats.getFleetSizeNum() > prevStats.getFleetSizeNum() * 2f 
						|| currStats.getFleetSizeNum() - prevStats.getFleetSizeNum() > 15f) {
					SharedData.getData().resetCustomsTimeouts();
				}
			}
			
			
			String starSystemId = starSystem.getId();
			
			List<MarketAPI> localMarkets = Misc.getMarketsInLocation(starSystem);
			if (localMarkets.isEmpty()) return;
			Collections.shuffle(localMarkets);
			
			MarketAPI largestMarket = null;
			Map<FactionAPI, Float> totals = new HashMap<FactionAPI, Float>();
			for (MarketAPI market : localMarkets) {
				FactionAPI faction = market.getFaction();
				if (largestMarket == null || market.getSize() > largestMarket.getSize()) {
					largestMarket = market;
				}
				Float curr = totals.get(faction);
				if (curr == null) curr = 0f;
				curr += market.getSize();
				totals.put(faction, curr);
			}
			if (largestMarket == null) return;
			
			Set<FactionAPI> contenders = new HashSet<FactionAPI>();
			for (MarketAPI market : localMarkets) {
				if (market.getSize() >= largestMarket.getSize()) {
					contenders.add(market.getFaction());
				}
			}
			
			FactionAPI controllingFaction = null;
			for (FactionAPI curr : contenders) {
				if (controllingFaction == null) {
					controllingFaction = curr;
				} else {
					Float controllingTotal = totals.get(controllingFaction);
					Float currTotal = totals.get(curr);
					if (controllingTotal == null) controllingTotal = 0f;
					if (currTotal == null) currTotal = 0f;
					if (currTotal > controllingTotal || 
							(currTotal == controllingTotal && controllingFaction.getId().equals(Factions.INDEPENDENT))) {
						controllingFaction = curr;
					}
				}
			}
			if (controllingFaction == null) return;
			
			List<CampaignFleetAPI> allFleets = new ArrayList<CampaignFleetAPI>(starSystem.getFleets());
			allFleets.addAll(Global.getSector().getHyperspace().getFleets());
			WeightedRandomPicker<CampaignFleetAPI> picker = new WeightedRandomPicker<CampaignFleetAPI>();
			for (final CampaignFleetAPI fleet : allFleets) {
				if (fleet == playerFleet) continue;
				if (fleet.getFaction() == playerFleet.getFaction()) continue;
				if (fleet.isInHyperspace() && !fleet.isInOrNearSystem(starSystem)) continue;
				//if (fleet.getFaction() == Global.getSector().getFaction(Factions.PIRATES)) continue;
				//if (fleet.getFaction().isHostileTo(playerFleet.getFaction())) continue;
				if (fleet.isHostileTo(playerFleet)) continue;

				if (fleet.isInHyperspaceTransition()) continue;
				if (!fleet.isInCurrentLocation()) continue;
				//if (fleet.isI)
				if (fleet.getAI() != null && fleet.getAI().isCurrentAssignment(FleetAssignment.ORBIT_PASSIVE)) continue;
				
				if (fleet.getMemoryWithoutUpdate().contains(MemFlags.FLEET_BUSY)) continue;
				
				// hack, avoids customs inspections by fleets pursuing player for transponder being off
				if (fleet.getMemoryWithoutUpdate().contains(MemFlags.MEMORY_KEY_MAKE_AGGRESSIVE)) continue;
				if (!fleet.getMemoryWithoutUpdate().contains(MemFlags.MEMORY_KEY_CUSTOMS_INSPECTOR)) continue;
				
				VisibilityLevel level = playerFleet.getVisibilityLevelTo(fleet);
				if (level == VisibilityLevel.NONE) continue;
				
				float dist = Misc.getDistance(fleet.getLocation(), playerFleet.getLocation());
				if (dist > 750) continue;
				
				if (dist < 100) dist = 100f;
				
				
				String factionId = fleet.getFaction().getId();
				if (SharedData.getData().getStarSystemCustomsTimeout(factionId).contains(starSystemId)) {
					continue;
				}
				
				
				float distToLocalFactionMarket = Float.MAX_VALUE;
				//float distToOtherLocalMarket = Float.MAX_VALUE;
				for (MarketAPI market : localMarkets) {
					if (market.getFaction() == fleet.getFaction()) {
						if (market.getPrimaryEntity() == null) continue;
						if (!market.getPrimaryEntity().isInCurrentLocation()) continue;
						
						float currDist = Misc.getDistance(market.getPrimaryEntity().getLocation(), fleet.getLocation());
						if (currDist < distToLocalFactionMarket) {
							distToLocalFactionMarket = currDist;
						}
					}
				}
				//if (largestMarket == null || !largestMarket.getFactionId().equals(fleet.getFaction().getId())) {
				if (!controllingFaction.getId().equals(fleet.getFaction().getId())) {
					if (distToLocalFactionMarket > 1500f) continue;
				}
				
				List<CampaignFleetAPI> hostiles = Misc.findNearbyFleets(fleet, 600, new FleetFilter() {
					public boolean accept(CampaignFleetAPI curr) {
						return fleet.isHostileTo(curr);
					}
				});
				if (!hostiles.isEmpty()) continue;

				hostiles = Misc.findNearbyFleets(playerFleet, 600, new FleetFilter() {
					public boolean accept(CampaignFleetAPI curr) {
						return fleet.isHostileTo(curr);
					}
				});
				if (!hostiles.isEmpty()) continue;
				
				
				//picker.add(fleet, fleet.getFleetPoints());
				picker.add(fleet, 1000f / dist);
			}
			
			if (picker.isEmpty()) return;
			
			CampaignFleetAPI fleet = picker.pick();
		
			RepLevel level = fleet.getFaction().getRelationshipLevel(playerFleet.getFaction());
			float chance = 1f;
			switch (level) {
			case COOPERATIVE:
				chance = 0.1f;
				break;
			case FRIENDLY:
				chance = 0.2f;
				break;
			case WELCOMING:
				chance = 0.3f;
				break;
			case FAVORABLE:
				chance = 0.4f;
				break;
			case NEUTRAL:
				chance = 0.5f;
				break;
			case SUSPICIOUS:
				chance = 0.75f;
				break;
			case INHOSPITABLE:
				chance = .9f;
				break;
			case HOSTILE:
			case VENGEFUL:
				chance = 0f;
				break;
			}
			
			float size = playerFleet.getFleetSizeCount();
			if (size <= 1 && level.isAtWorst(RepLevel.NEUTRAL)) {
				chance = 0f;
			} else if (size <= 3 && level.isAtWorst(RepLevel.NEUTRAL)) {
				//chance = 0f;
				chance *= 0.5f;
			}
//			if (size <= 3) {
//				chance -= 0.4f;
//			} else if (size <= 6) {
//				chance -= 0.2f;
//			} else {
//				
//			}
			
			//if ((float) Math.random() > chance && false) {
			if ((float) Math.random() > chance) {
				SharedData.getData().getStarSystemCustomsTimeout(fleet.getFaction().getId()).add(starSystemId, 2f);
				return;
			}
			
			prevStats = currStats.clone();
			
			fleet.getMemoryWithoutUpdate().set(MemFlags.FLEET_BUSY, true, 11f);
			eventManager.startEvent(new CampaignEventTarget(fleet), Events.CUSTOMS_INSPECTION, null);
		}
	}
	
	
	
	

	protected void startTradeDisruptionEventsIfNeeded(float days, boolean force) {
		tradeDisruptionTracker.advance(days);
		if (tradeDisruptionTracker.intervalElapsed() || force) {
			for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
				Misc.startEvent(new CampaignEventTarget(market), Events.TRADE_DISRUPTION, null);
			}
		}
	}
	
	
	protected void updateFoodShortageProbatility(float days) {
		foodShortageTracker.advance(days);
		if (!foodShortageTracker.intervalElapsed()) return;

		log.info("");
		log.info("Updating food shortage probabilities on " + Global.getSector().getClock().getDateString());
		for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
			//if (market.getFactionId().equals(Factions.PIRATES)) {
			if (market.getFaction().getCustom().optBoolean(Factions.CUSTOM_EXEMPT_FOOD_SHORTAGES)) {
				continue;
			}
			//if (market.getSize() >= 7) continue;
			if (market.getSize() >= 6) continue;
			if (market.hasCondition(Conditions.DECIVILIZED)) continue;
			
			EventProbabilityAPI ep = eventManager.getProbability(Events.FOOD_SHORTAGE, market);
			if (eventManager.isOngoing(ep)) {
				continue;
			}
			
			float lowStabilityMult = BaseMarketConditionPlugin.getLowStabilityBonusMult(market);
			float highStabilityMult = BaseMarketConditionPlugin.getHighStabilityPenaltyMult(market);
			float demandMet = market.getCommodityData(Commodities.FOOD).getDemand().getClampedFractionMet();
			float unmet = 1f - demandMet;
			
			// low stability + some unmet demand = chance for shortage
			float probabilityIncrease = unmet * 0.1f * lowStabilityMult * highStabilityMult;
			if (probabilityIncrease > 0) {
				ep.increaseProbability(probabilityIncrease);
				log.info("Increasing food shortage probability for " + market.getName() + " by " + probabilityIncrease + ", is now " + ep.getProbability());
			}
		}
	}
	
	public boolean isDone() {
		return false;
	}

	public boolean runWhilePaused() {
		return false;
	}
	
	
	@Override
	public void reportPlayerMarketTransaction(PlayerMarketTransaction transaction) {
		super.reportPlayerMarketTransaction(transaction);
		
		//SharedData.getData().getPlayerActivityTracker().updateLastVisit(transaction.getMarket());
		//increaseSmugglingInvestigationChance(transaction);
	}
	
	protected void increaseSmugglingInvestigationChance(PlayerMarketTransaction transaction) {
		SubmarketPlugin plugin = transaction.getSubmarket().getPlugin();
		if (!plugin.isParticipatesInEconomy()) return;
		
		MarketAPI market = transaction.getMarket();
		if (market.hasCondition(Conditions.FREE_PORT)) return;
		
		
		FactionAPI player = Global.getSector().getFaction(Factions.PLAYER);
		RepLevel level = market.getFaction().getRelationshipLevel(player);
		
//		CampaignEventPlugin event = eventManager.getOngoingEvent(new CampaignEventTarget(market), Events.TRADE_DISRUPTION);
//		TradeDisruptionAndSmugglingEvent td = null;
//		if (event instanceof TradeDisruptionAndSmugglingEvent) {
//			td = (TradeDisruptionAndSmugglingEvent) event;
//		}
		
		EventProbabilityAPI ep = eventManager.getProbability(Events.INVESTIGATION_SMUGGLING, market);
		if (eventManager.isOngoing(ep)) {
			log.info("Skipping market " + market.getName() + ", investigation already ongoing");
			return;
		}
		
		float valueImpact = transaction.getBaseTradeValueImpact();
		float marketVolume = transaction.getMarket().getTradeVolume();
		
		float transponderMult = 1f;
		if (!Global.getSector().getPlayerFleet().isTransponderOn()) {
			transponderMult = Global.getSettings().getFloat("transponderOffMarketAwarenessMult");
		}
		valueImpact *= transponderMult;
		//System.out.println("IMPACT: " + valueImpact);
		//boolean increase = plugin.isBlackMarket();
		//increase |= level.isAtBest(RepLevel.SUSPICIOUS) && td != null && td.getSmugglingPenalty() > 0;
		
		//if (increase) {
		if (plugin.isBlackMarket()) {
			float lowStabilityMult = BaseMarketConditionPlugin.getLowStabilityPenaltyMult(market);
			float highStabilityMult = BaseMarketConditionPlugin.getHighStabilityBonusMult(market);
			float probabilityChange = valueImpact / marketVolume * lowStabilityMult * highStabilityMult;
//			if (!increasedSmugglingInvestigationChanceThisFrame) {
//				if (probabilityChange < 0.01f) probabilityChange = 0.01f;
//				if (level.isAtBest(RepLevel.INHOSPITABLE) && probabilityChange < 0.25f) {
//					probabilityChange = 0.25f;
//				}
//			}
			ep.increaseProbability(probabilityChange);
			if (ep.getProbability() < 0.01f) {
				ep.setProbabilityAfterMult(0.01f);
			}
//			increasedSmugglingInvestigationChanceThisFrame = true;
			log.info("Increasing smuggling investigation probability for " + market.getName() + " by " + probabilityChange + ", is now " + ep.getProbability());
		} else {
			float lowStabilityMult = BaseMarketConditionPlugin.getLowStabilityBonusMult(market);
			float highStabilityMult = BaseMarketConditionPlugin.getHighStabilityPenaltyMult(market);
			float probabilityChange = valueImpact / marketVolume * lowStabilityMult * highStabilityMult;
			boolean wasGTZero = ep.getProbability() > 0;
			ep.decreaseProbability(probabilityChange);
			if (ep.getProbability() < 0.01f && wasGTZero) {
				ep.setProbabilityAfterMult(0.01f);
			}
//			increasedSmugglingInvestigationChanceThisFrame = true;
			log.info("Decreasing smuggling investigation probability for " + market.getName() + " by " + probabilityChange + ", is now " + ep.getProbability());			
		}
	}
	
	
	protected void updateFactionHostilityProbability(float days) {
		factionHostilityTracker.advance(days);
		if (factionHostilityTracker.intervalElapsed()) {
			List<FactionAPI> factions = Global.getSector().getAllFactions();
			float count = 0f;
			for (int i = 0; i < factions.size(); i++) {
				FactionAPI faction = factions.get(i);
				if (!faction.getCustom().optBoolean(Factions.CUSTOM_ENGAGES_IN_HOSTILITIES)) {
					continue;
				}
				count++;
			}
			float pMult = 1f;
			float vanillaFactions = 5;
			if (count > vanillaFactions) {
				pMult = vanillaFactions / count; 
			}
			for (int i = 0; i < factions.size(); i++) {
				FactionAPI faction = factions.get(i);
				if (!faction.getCustom().optBoolean(Factions.CUSTOM_ENGAGES_IN_HOSTILITIES)) {
					continue;
				}
				if (Misc.getFactionMarkets(faction).isEmpty()) continue;
				for (int j = i + 1; j < factions.size(); j++) {
					FactionAPI other = factions.get(j);
					if (faction == other) continue;
					if (faction.isHostileTo(other)) continue;
					if (faction.isAtWorst(other, RepLevel.COOPERATIVE)) continue;
					if (!other.getCustom().optBoolean(Factions.CUSTOM_ENGAGES_IN_HOSTILITIES)) {
						continue;
					}
					if (Misc.getFactionMarkets(other).isEmpty()) continue;
					
					FactionHostilityPairKey key = new FactionHostilityPairKey(faction, other);
					
					EventProbabilityAPI ep = eventManager.getProbability(Events.FACTION_HOSTILITY, key);
					float increase = 0.03f * pMult;
					if (increase > 0) {
						ep.increaseProbability(increase);
						log.info(String.format("Increasing faction hostility probability %s -> %s, by %s, is now %s",
											faction.getDisplayName(), other.getDisplayName(), "" + increase,
											"" + ep.getProbability()));
					}
				}
			}
		}
	}
}


















