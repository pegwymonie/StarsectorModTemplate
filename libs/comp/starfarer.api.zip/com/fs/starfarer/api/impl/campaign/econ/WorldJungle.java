package com.fs.starfarer.api.impl.campaign.econ;


public class WorldJungle extends WorldFarming {

	public WorldJungle() {
		super(ConditionData.WORLD_JUNGLE_FARMING_MULT, ConditionData.WORLD_JUNGLE_MACHINERY_MULT);
	}

}
