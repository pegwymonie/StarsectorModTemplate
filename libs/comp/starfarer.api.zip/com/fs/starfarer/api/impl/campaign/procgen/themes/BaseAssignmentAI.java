package com.fs.starfarer.api.impl.campaign.procgen.themes;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;

public abstract class BaseAssignmentAI implements EveryFrameScript {

	protected CampaignFleetAPI fleet;
	protected Boolean done = null;
	protected Boolean giveInitial = true;
	
	public BaseAssignmentAI() {
	}

	public BaseAssignmentAI(CampaignFleetAPI fleet) {
		this.fleet = fleet;
		giveInitialAssignments();
	}
	
	protected abstract void giveInitialAssignments();
	protected abstract void pickNext();

	public void advance(float amount) {
		if (fleet.getCurrentAssignment() == null) {
			pickNext();
		}
	}

	
	public boolean isDone() {
		return done != null;
	}
	
	public void setDone() {
		done = true;
	}

	public boolean runWhilePaused() {
		return false;
	}

}










