package com.fs.starfarer.api.impl.campaign.econ;

import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;

public class MilitaryBase extends BaseMarketConditionPlugin {

	public void apply(String id) {
		
		if (!market.hasSubmarket(Submarkets.GENERIC_MILITARY)) {
			market.addSubmarket(Submarkets.GENERIC_MILITARY);
		}
		
		market.getDemand(Commodities.FUEL).getDemand().modifyFlat(id, ConditionData.MILITARY_BASE_FUEL);
		market.getDemand(Commodities.FUEL).getNonConsumingDemand().modifyFlat(id, ConditionData.MILITARY_BASE_FUEL * 0.5f);
		
		market.getDemand(Commodities.SUPPLIES).getDemand().modifyFlat(id, ConditionData.MILITARY_BASE_SUPPLIES);
		market.getDemand(Commodities.SUPPLIES).getNonConsumingDemand().modifyFlat(id, ConditionData.MILITARY_BASE_SUPPLIES * 0.5f);
		
		market.getDemand(Commodities.HAND_WEAPONS).getDemand().modifyFlat(id, ConditionData.MILITARY_BASE_WEAPONS);
		market.getDemand(Commodities.HEAVY_MACHINERY).getDemand().modifyFlat(id, ConditionData.MILITARY_BASE_MACHINERY);
		
		market.getDemand(Commodities.MARINES).getDemand().modifyFlat(id, ConditionData.MILITARY_BASE_MARINES_DEMAND);
		market.getDemand(Commodities.MARINES).getNonConsumingDemand().modifyFlat(id, ConditionData.MILITARY_BASE_MARINES_DEMAND * ConditionData.CREW_MARINES_NON_CONSUMING_FRACTION);
		market.getDemand(Commodities.CREW).getDemand().modifyFlat(id, ConditionData.MILITARY_BASE_CREW_DEMAND);
		market.getDemand(Commodities.CREW).getNonConsumingDemand().modifyFlat(id, ConditionData.MILITARY_BASE_CREW_DEMAND * ConditionData.CREW_MARINES_NON_CONSUMING_FRACTION);
		
		market.getCommodityData(Commodities.MARINES).getSupply().modifyFlat(id, ConditionData.MILITARY_BASE_MARINES_SUPPLY);
		market.getCommodityData(Commodities.CREW).getSupply().modifyFlat(id, ConditionData.MILITARY_BASE_CREW_SUPPLY);
		
		market.getStability().modifyFlat(id, ConditionData.STABILITY_MILITARY_BASE, "Military base");
		
		market.getStats().getDynamic().getStat(Stats.OFFICER_NUM_MULT).modifyFlat(id, ConditionData.MILITARY_BASE_OFFICER_NUM_MULT_BONUS);
		market.getStats().getDynamic().getStat(Stats.OFFICER_LEVEL_MULT).modifyFlat(id, ConditionData.MILITARY_BASE_OFFICER_LEVEL_MULT_BONUS);
	}

	public void unapply(String id) {
		market.getDemand(Commodities.SUPPLIES).getDemand().unmodify(id);
		market.getDemand(Commodities.FUEL).getDemand().unmodify(id);
		
		market.getDemand(Commodities.SUPPLIES).getNonConsumingDemand().unmodify(id);
		market.getDemand(Commodities.FUEL).getNonConsumingDemand().unmodify(id);
		
		market.getDemand(Commodities.HAND_WEAPONS).getDemand().unmodify(id);
		market.getDemand(Commodities.HEAVY_MACHINERY).getDemand().unmodify(id);
		
		market.getDemand(Commodities.MARINES).getDemand().unmodify(id);
		market.getDemand(Commodities.MARINES).getNonConsumingDemand().unmodify(id);
		market.getDemand(Commodities.CREW).getDemand().unmodify(id);
		market.getDemand(Commodities.CREW).getNonConsumingDemand().unmodify(id);
		
		market.getCommodityData(Commodities.MARINES).getSupply().unmodify(id);
		market.getCommodityData(Commodities.CREW).getSupply().unmodify(id);
		
		market.getStability().unmodify(id);
		
		market.getStats().getDynamic().getStat(Stats.OFFICER_NUM_MULT).unmodify(id);
		market.getStats().getDynamic().getStat(Stats.OFFICER_LEVEL_MULT).unmodify(id);
	}

}
