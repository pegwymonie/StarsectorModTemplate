package com.fs.starfarer.api.impl.campaign.econ;

import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Stats;

public class Spaceport extends BaseMarketConditionPlugin {

	public void apply(String id) {
		float pop = getPopulation(market);
		
		float fuelDemand = ConditionData.SPACEPORT_FUEL_BASE + pop * ConditionData.SPACEPORT_FUEL_MULT;
		if (fuelDemand > ConditionData.SPACEPORT_FUEL_MAX) {
			fuelDemand = ConditionData.SPACEPORT_FUEL_MAX;
		}
		
		market.getCommodityData(Commodities.CREW).getSupply().modifyFlat(id, ConditionData.ORBITAL_STATION_REGULAR_CREW_SUPPLY);
		
		market.getDemand(Commodities.CREW).getDemand().modifyFlat(id, ConditionData.SPACEPORT_CREW);
		//market.getDemand(Commodities.REGULAR_CREW).getNonConsumingDemand().modifyFlat(id, ConditionData.SPACEPORT_CREW * ConditionData.CREW_MARINES_NON_CONSUMING_FRACTION);
		
		market.getDemand(Commodities.SUPPLIES).getDemand().modifyFlat(id, ConditionData.SPACEPORT_SUPPLIES);
		market.getDemand(Commodities.FUEL).getDemand().modifyFlat(id, fuelDemand);
		
//		market.getDemand(Commodities.SUPPLIES).getNonConsumingDemand().modifyFlat(id, ConditionData.SPACEPORT_SUPPLIES * 0.5f);
//		market.getDemand(Commodities.FUEL).getNonConsumingDemand().modifyFlat(id, fuelDemand * 0.5f);
		
		market.getStability().modifyFlat(id, ConditionData.STABILITY_SPACEPORT, "Spaceport");
		
		market.getStats().getDynamic().getStat(Stats.OFFICER_NUM_MULT).modifyFlat(id, ConditionData.SPACEPORT_OFFICER_NUM_MULT_BONUS);
	}

	public void unapply(String id) {
		
		market.getCommodityData(Commodities.CREW).getSupply().unmodify(id);
		
		market.getDemand(Commodities.CREW).getDemand().unmodify(id);
		//market.getDemand(Commodities.REGULAR_CREW).getNonConsumingDemand().unmodify(id);
		
		market.getDemand(Commodities.SUPPLIES).getDemand().unmodify(id);
		market.getDemand(Commodities.FUEL).getDemand().unmodify(id);
		
//		market.getDemand(Commodities.SUPPLIES).getNonConsumingDemand().unmodify(id);
//		market.getDemand(Commodities.FUEL).getNonConsumingDemand().unmodify(id);
		
		market.getStability().unmodify(id);
		
		market.getStats().getDynamic().getStat(Stats.OFFICER_NUM_MULT).unmodify(id);
	}

}
