package com.fs.starfarer.api.impl.campaign.econ;

import com.fs.starfarer.api.impl.campaign.ids.Commodities;

public class FuelProduction extends BaseMarketConditionPlugin {

	public void apply(String id) {

//		market.getDemand(Commodities.REGULAR_CREW).getDemand().modifyFlat(id, ConditionData.FUEL_PRODUCTION_CREW);
//		market.getDemand(Commodities.REGULAR_CREW).getNonConsumingDemand().modifyFlat(id, ConditionData.FUEL_PRODUCTION_CREW * ConditionData.CREW_MARINES_NON_CONSUMING_FRACTION);
//		float crewDemandMet = getCrewDemandMet(market);
		
		float mult = getBaseSizeMult();
		
		market.getDemand(Commodities.ORGANICS).getDemand().modifyFlat(id, ConditionData.FUEL_PRODUCTION_ORGANICS * mult);
		market.getDemand(Commodities.VOLATILES).getDemand().modifyFlat(id, ConditionData.FUEL_PRODUCTION_VOLATILES * mult);
		market.getDemand(Commodities.RARE_METALS).getDemand().modifyFlat(id, ConditionData.FUEL_PRODUCTION_RARE_METALS * mult);
		market.getDemand(Commodities.HEAVY_MACHINERY).getDemand().modifyFlat(id, ConditionData.FUEL_PRODUCTION_MACHINERY);
		
		float productionMult = getProductionMult(market, Commodities.ORGANICS, Commodities.VOLATILES, Commodities.RARE_METALS) * mult;
		market.getCommodityData(Commodities.FUEL).getSupply().modifyFlat(id, ConditionData.FUEL_PRODUCTION_FUEL * productionMult * mult);
	}

	public void unapply(String id) {
		market.getDemand(Commodities.ORGANICS).getDemand().unmodify(id);
		market.getDemand(Commodities.VOLATILES).getDemand().unmodify(id);
		market.getDemand(Commodities.RARE_METALS).getDemand().unmodify(id);
		market.getDemand(Commodities.HEAVY_MACHINERY).getDemand().unmodify(id);
		
//		market.getDemand(Commodities.REGULAR_CREW).getDemand().unmodify(id);
//		market.getDemand(Commodities.REGULAR_CREW).getNonConsumingDemand().unmodify(id);
		
		market.getCommodityData(Commodities.FUEL).getSupply().unmodify(id);
	}

}
