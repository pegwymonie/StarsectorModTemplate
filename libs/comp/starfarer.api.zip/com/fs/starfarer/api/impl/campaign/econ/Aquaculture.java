package com.fs.starfarer.api.impl.campaign.econ;


public class Aquaculture extends BaseMarketConditionPlugin {

	public void apply(String id) {
		
//		float pop = getPopulation(market);
//		float foodProduced = pop * ConditionData.AQUACULTURE_FOOD_MULT;
//		float organicsProduced = foodProduced * ConditionData.FARMING_ORGANICS_FRACTION;
//		market.getCommodityData(Commodities.ORGANICS).getSupply().modifyFlat(id, organicsProduced);
//		market.getCommodityData(Commodities.FOOD).getSupply().modifyFlat(id, foodProduced);
//		market.getDemand(Commodities.HEAVY_MACHINERY).getDemand().modifyFlat(id, 
//										foodProduced * ConditionData.AQUACULTURE_MACHINERY_MULT);
	}

	public void unapply(String id) {
//		market.getCommodityData(Commodities.ORGANICS).getSupply().unmodify(id);
//		market.getCommodityData(Commodities.FOOD).getSupply().unmodify(id);
//		market.getDemand(Commodities.HEAVY_MACHINERY).getDemand().unmodify(id);
	}

}
