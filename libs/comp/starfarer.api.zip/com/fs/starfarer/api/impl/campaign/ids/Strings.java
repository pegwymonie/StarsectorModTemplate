package com.fs.starfarer.api.impl.campaign.ids;

public class Strings {

	public static final String C = "�";
	public static final String X = "�";
	
//	public static final String SUBMARKET_STORAGE = "storage";
//	public static final String SUBMARKET_OPEN = "open_market";
//	public static final String SUBMARKET_BLACK = "black_market";
}
