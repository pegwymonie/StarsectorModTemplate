package com.fs.starfarer.api.impl.campaign.econ;

import java.util.Map;

import com.fs.starfarer.api.impl.campaign.events.SystemBountyEvent;

public class SystemBounty extends BaseMarketConditionPlugin {
	
	private SystemBountyEvent event = null;
	
	public SystemBounty() {
	}

	public void apply(String id) {
	}

	public void unapply(String id) {
	}
	
	@Override
	public void setParam(Object param) {
		event = (SystemBountyEvent) param;
	}
	
	public Map<String, String> getTokenReplacements() {
		return event.getTokenReplacements();
	}

	@Override
	public String[] getHighlights() {
		return event.getHighlights("condition");
	}
	
	@Override
	public boolean isTransient() {
		return false;
	}
}
