package com.fs.starfarer.api.impl.campaign.fleets;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactory.MercType;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;

public class MercFleetManager extends BaseLimitedFleetManager {

	@Override
	protected int getMaxFleets() {
		return (int) Global.getSettings().getFloat("maxMercFleets");
	}

	@Override
	protected CampaignFleetAPI spawnFleet() {

		MarketAPI source = pickMarket();
		if (source == null) return null;
		
		WeightedRandomPicker<MercType> picker = new WeightedRandomPicker<MercType>();
		picker.add(MercType.SCOUT, 10f); 
		picker.add(MercType.BOUNTY_HUNTER, 10f); 
		picker.add(MercType.PRIVATEER, 10f); 
		picker.add(MercType.PATROL, 10f); 
		picker.add(MercType.ARMADA, 3f); 
		
		MercType type = picker.pick();
		
		float combat = 0f;
		float tanker = 0f;
		float freighter = 0f;
		String fleetType = type.fleetType;
		switch (type) {
		case SCOUT:
			combat = Math.round(1f + (float) Math.random() * 2f);
			break;
		case PRIVATEER:
		case BOUNTY_HUNTER:
			combat = Math.round(3f + (float) Math.random() * 2f);
			break;
		case PATROL:
			combat = Math.round(9f + (float) Math.random() * 3f);
			break;
		case ARMADA:
			combat = Math.round(10f + (float) Math.random() * 4f);
			break;
		}

		
		CampaignFleetAPI fleet = FleetFactoryV2.createFleet(new FleetParams(
				null,
				source, 
				Factions.INDEPENDENT,
				null, // fleet's faction, if different from above, which is also used for source market picking
				fleetType,
				combat, // combatPts
				freighter, // freighterPts 
				tanker, // tankerPts
				0f, // transportPts
				0f, // linerPts
				0f, // civilianPts 
				0f, // utilityPts
				0f, // qualityBonus
				-1f, // qualityOverride
				1f, // officer num mult
				0 // officer level bonus
				));
		

		
		source.getPrimaryEntity().getContainingLocation().addEntity(fleet);
		fleet.setLocation(source.getPrimaryEntity().getLocation().x, source.getPrimaryEntity().getLocation().y);
		
		MercAssignmentAI ai = new MercAssignmentAI(fleet, source);
		fleet.addScript(ai);
		
		
		return fleet;
	}

	
	protected MarketAPI pickMarket() {
		WeightedRandomPicker<MarketAPI> picker = new WeightedRandomPicker<MarketAPI>();
		for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
			if (market.getFactionId().equals(Factions.PIRATES)) continue;
			if (market.getFaction().isHostileTo(Factions.INDEPENDENT)) continue;
			float mult = Misc.getSpawnChanceMult(market.getLocationInHyperspace());
			float w = market.getStabilityValue() + market.getSize();
			
			w *= mult;
			picker.add(market, w);
 			//System.out.println("Market: " + market.getName() + ", weight: " + w);
		}
		return picker.pick();
	}

	
}















