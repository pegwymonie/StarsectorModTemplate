package com.fs.starfarer.api.impl.campaign;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.FleetDespawnListener;
import com.fs.starfarer.api.campaign.FleetStubAPI;
import com.fs.starfarer.api.campaign.FleetStubConverterPlugin;
import com.fs.starfarer.api.campaign.ai.FleetAssignmentDataAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactoryV2;
import com.fs.starfarer.api.impl.campaign.fleets.FleetParams;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.util.Misc;

public class FleetStubConverterPluginImpl implements FleetStubConverterPlugin {

	public CampaignFleetAPI convertToFleet(FleetStubAPI stub) {
		if (stub == null || !(stub.getParams() instanceof FleetParams)) {
			throw new RuntimeException("Trying to convert invalid fleet stub with FleetStubConverterPluginImpl");
		}
		
		FleetParams params = (FleetParams) stub.getParams();
		CampaignFleetAPI fleet = FleetFactoryV2.createFleet(params);
		
		MemoryAPI memory = fleet.getMemoryWithoutUpdate();
		fleet.setMemory(stub.getMemoryWithoutUpdate());
		
		String sourceMarket = memory.getString(MemFlags.MEMORY_KEY_SOURCE_MARKET);
		if (sourceMarket != null) {
			fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_SOURCE_MARKET, sourceMarket);
		}
		
		fleet.setId(stub.getId());
		
		
		for (FleetAssignmentDataAPI curr : stub.getAssignmentsCopy()) {
			fleet.addAssignment(curr.getAssignment(), curr.getTarget(), curr.getMaxDurationInDays(),
								curr.getActionText(), curr.getOnCompletion());
		}
		
		if (stub.getContainingLocation() != null) {
			stub.getContainingLocation().addEntity(fleet);
			stub.getContainingLocation().removeFleetStub(stub);
		}
		
		fleet.setLocation(stub.getLocation().x, stub.getLocation().y);
		
		
		if (stub.getScripts() != null) {
			for (EveryFrameScript script : stub.getScripts()) {
				fleet.addScript(script);
			}
			//stub.getScripts().clear();
		}
		
		if (stub.getDespawnListeners() != null) {
			for (FleetDespawnListener listener : stub.getDespawnListeners()) {
				fleet.addDespawnListener(listener);
			}
			stub.getDespawnListeners().clear();
		}
		
		stub.setFleet(fleet);
		stub.setMemory(null);
		stub.clearAssignments();
		
		fleet.setStub(stub);
		
		return fleet;
	}

	
	public FleetStubAPI convertToStub(CampaignFleetAPI fleet) {
		MemoryAPI memory = fleet.getMemoryWithoutUpdate();
		memory.advance(10000f); // flush out anything temporary
		
		FleetStubAPI stub = fleet.getStub();
		stub.setMemory(memory);
		stub.setFleet(null);
		
		stub.clearAssignments();
		for (FleetAssignmentDataAPI curr : fleet.getAssignmentsCopy()) {
			stub.addAssignment(curr.getAssignment(), curr.getTarget(), curr.getMaxDurationInDays(),
								curr.getActionText(), curr.getOnCompletion());
		}
		
//		if (fleet.getScripts() != null) {
//			if (stub.getScripts() != null) {
//				stub.getScripts().clear();
//			}
//			for (EveryFrameScript script : fleet.getScripts()) {
//				stub.addScript(script);
//			}
//		}
		
		if (fleet.getDespawnListeners() != null) {
			if (stub.getDespawnListeners() != null) {
				stub.getDespawnListeners().clear();
			}
			for (FleetDespawnListener listener : fleet.getDespawnListeners()) {
				stub.addDespawnListener(listener);
			}
		}
		
		if (fleet.getContainingLocation() != null) {
			fleet.getContainingLocation().removeEntity(fleet);
			fleet.getContainingLocation().addFleetStub(stub);
			stub.setContainingLocation(fleet.getContainingLocation());
		}
		
		stub.getLocation().set(fleet.getLocation().x, fleet.getLocation().y);
		
		
		return null;
	}

	
	public boolean shouldConvertFromStub(FleetStubAPI stub) {
		//if (true) return true;
		return Misc.shouldConvertFromStub(stub);
	}
	
	public boolean shouldConvertToStub(CampaignFleetAPI fleet) {
		//if (true) return false;
		return Misc.shouldConvertToStub(fleet);
	}
}











