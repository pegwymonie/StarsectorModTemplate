package com.fs.starfarer.api.impl.campaign.econ;

import com.fs.starfarer.api.impl.campaign.ids.Commodities;


public class FreeMarket extends BaseMarketConditionPlugin {

	public void apply(String id) {
		market.resetSmugglingValue();
		
		float mult = getBaseSizeMult();
		
		market.getDemand(Commodities.DRUGS).getDemand().modifyFlat(id, 
						mult * ConditionData.FREE_PORT_DRUGS);
	}

	public void unapply(String id) {
		market.getDemand(Commodities.DRUGS).getDemand().unmodify(id);
	}

}
