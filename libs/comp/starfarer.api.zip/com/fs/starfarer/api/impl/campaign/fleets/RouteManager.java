package com.fs.starfarer.api.impl.campaign.fleets;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.FleetDespawnListener;
import com.fs.starfarer.api.campaign.FleetOrStubAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.CampaignEventListener.FleetDespawnReason;
import com.fs.starfarer.api.campaign.SectorEntityToken.VisibilityLevel;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.util.Misc;

public class RouteManager implements FleetDespawnListener {
	public static final String KEY = "$core_routeManager";
	
	public static float DAYS_SINCE_SEEN_BEFORE_DESPAWN = 60f;
	public static float DESPAWN_DIST_LY = 4f;
	public static float SPAWN_DIST_LY = 3.5f;
	
	
	public static class RouteSegment {
		public float elapsed = 0f;
		public float daysMax;
		public Vector2f from;
		public Vector2f to;
		public LocationAPI systemFrom;
		public LocationAPI systemTo;
		public Object custom;
		
		public RouteSegment(float daysMax, Vector2f from, LocationAPI systemFrom, Object custom) {
			this.daysMax = daysMax;
			this.from = from;
			this.systemFrom = (StarSystemAPI) systemFrom;
			this.custom = custom;
		}
		
		public RouteSegment(float daysMax, Vector2f from, LocationAPI systemFrom) {
			this(daysMax, from, systemFrom, null);
		}

		public RouteSegment(float daysMax, Vector2f from, LocationAPI systemFrom, 
				Vector2f to, LocationAPI systemTo) {
			this(daysMax, from, systemFrom, to, systemTo, null);
		}
		public RouteSegment(float daysMax, Vector2f from, LocationAPI systemFrom, 
										   Vector2f to, LocationAPI systemTo, Object custom) {
			this.daysMax = daysMax;
			this.from = from;
			this.to = to;
			this.systemFrom = (StarSystemAPI) systemFrom;
			this.systemTo = (StarSystemAPI) systemTo;
			this.custom = custom;
		}
		
		public boolean isTravel() {
			return to != null && to != from;
		}

	}
	
	
	public static interface RouteFleetSpawner {
		CampaignFleetAPI spawnFleet(RouteData data);
	}
	
	public static class RouteData {
		protected String source;
		protected MarketAPI market;
		protected Long seed;
		protected List<RouteSegment> segments = new ArrayList<RouteSegment>();
		protected CampaignFleetAPI activeFleet = null;
		protected float daysSinceSeenByPlayer = 1000f;
		protected Object custom;
		protected RouteSegment current;
		protected RouteFleetSpawner spawner;
		//protected Boolean suspended = null;
		/**
		 * "source" is a unique string ID for a given set of fleets. Useful to, for example,
		 * limit the number of fleets of a particular type being spawned.
		 * Use RouteManager.getNumRoutesFor(String source) to check number of routes with a given
		 * source that already exist. 
		 * @param source
		 * @param market
		 * @param seed
		 */
		public RouteData(String source, MarketAPI market, Long seed) {
			this.source = source;
			this.market = market;
			this.seed = seed;
		}
		public MarketAPI getMarket() {
			return market;
		}
		public void goToAtLeastNext(RouteSegment from) {
			int index = segments.indexOf(current);
			int indexFrom = segments.indexOf(from);
			if (indexFrom < 0) return;
			if (indexFrom < index) return;
			
			if (indexFrom < segments.size() - 1) {
				current = segments.get(indexFrom + 1);
			} else {
				current.elapsed = current.daysMax;
			}
		}
		
//		public boolean isSuspended() {
//			return suspended != null && suspended == false;
//		}
//		/**
//		 * Set to true to prevent route points from changing the "current" assignment.
//		 * Useful when fleet is active and so route point advancement should be handled directly based on
//		 * what the fleet does.
//		 * @param suspended
//		 */
//		public void setSuspended(boolean suspended) {
//			if (!suspended) {
//				this.suspended = null;
//			} else {
//				this.suspended = suspended;
//			}
//		}
		public Long getSeed() {
			return seed;
		}
		public void addSegment(RouteSegment segment) {
			segments.add(segment);
		}
		public List<RouteSegment> getSegments() {
			return segments;
		}
		public void setCurrent(RouteSegment current) {
			this.current = current;
		}
		public CampaignFleetAPI getActiveFleet() {
			return activeFleet;
		}
		public float getDaysSinceSeenByPlayer() {
			return daysSinceSeenByPlayer;
		}
		public Object getCustom() {
			return custom;
		}
		public RouteSegment getCurrent() {
			return current;
		}
		public RouteFleetSpawner getSpawner() {
			return spawner;
		}
		public String getSource() {
			return source;
		}
		public Vector2f getInterpolatedLocation() {
			if (current == null) return new Vector2f(100000000f, 0);
			
			if (current.to == null) return new Vector2f(current.from);
			
			Vector2f interpLoc = Misc.interpolateVector(current.from, current.to, current.elapsed / current.daysMax);
			return interpLoc;
		}
		
		public LocationAPI getCurrentContainingLocation() {
			if (current.systemFrom == null || (current.systemTo != null && current.systemFrom != current.systemTo)) {
				return Global.getSector().getHyperspace(); 
			}
			return current.systemFrom;
		}
		
		public boolean isExpired() {
			if (segments.indexOf(current) == segments.size() - 1 && current.elapsed >= current.daysMax) {
				return true;
			}
			return false;
		}
		
	}
	
	public static RouteManager getInstance() {
		
		Object test = Global.getSector().getMemoryWithoutUpdate().get(KEY);
		if (test instanceof RouteManager) {
			return (RouteManager) test; 
		}
		
		RouteManager manager = new RouteManager();
		Global.getSector().getMemoryWithoutUpdate().set(KEY, manager);
		return manager;
	}
	
	protected List<RouteData> routes = new ArrayList<RouteData>();
	protected transient Map<String, List<RouteData>> sourceToRoute = new LinkedHashMap<String, List<RouteData>>();
	
	Object readResolve() {
		sourceToRoute = new LinkedHashMap<String, List<RouteData>>();
		for (RouteData route : routes) {
			addToMap(route);
		}
		return this;
	}
	
	public RouteData addRoute(String source, MarketAPI market, Long seed, RouteFleetSpawner spawner) {
		return addRoute(source, market, seed, spawner, null);
	}
	
	public RouteData addRoute(String source, MarketAPI market, Long seed, RouteFleetSpawner spawner, Object custom) {
		RouteData route = new RouteData(source, market, seed);
		route.spawner = spawner;
		route.custom = custom;
		routes.add(route);
		addToMap(route);
		//routes.clear();
		return route;
	}
	
	public int getNumRoutesFor(String source) {
		if (!sourceToRoute.containsKey(source)) return 0;
		return sourceToRoute.get(source).size();
	}
	
	public void addToMap(RouteData route) {
		if (route.source == null) return;
		
		List<RouteData> forSource = getRoutesForSource(route.source);
		forSource.add(route);
	}
	
	public void removeFromMap(RouteData route) {
		if (route.source == null) return;
		
		List<RouteData> forSource = getRoutesForSource(route.source);
		forSource.remove(route);
		if (forSource.isEmpty()) {
			sourceToRoute.remove(route.source);
		}
	}
	
	public List<RouteData> getRoutesForSource(String source) {
		List<RouteData> forSource = sourceToRoute.get(source);
		if (forSource == null) {
			forSource = new ArrayList<RouteData>();
			sourceToRoute.put(source, forSource);
		}
		return forSource;
	}
	
	
	public void advance(float amount) {
		float days = Global.getSector().getClock().convertToDays(amount);
//		sourceToRoute.get("salvage_aegea")
//		int empty = 0;
//		int total = 0;
//		for (RouteData curr : routes) {
//			total++;
//			//if (curr.activeFleet != null && curr.activeFleet.getFleetData().getMembersListCopy().isEmpty()) {
//			if (curr.activeFleet != null && !curr.activeFleet.isAlive()) {
//			//if (curr.activeFleet != null) {
//				empty++;
//			}
//		}
//		System.out.println("Empty: " + empty + ", total: " + total);
//		System.out.println("Routes: " + routes.size());
		advanceRoutes(days);
		spawnAndDespawn();
	}
	
	protected void spawnAndDespawn() {
		CampaignFleetAPI player = Global.getSector().getPlayerFleet();
		if (player == null) return;
		
		//System.out.println("Num routes: " + routes.size());
		
		for (RouteData data : routes) {
			if (data.activeFleet != null && data.activeFleet.getContainingLocation() == player.getContainingLocation()) {
				VisibilityLevel level = data.activeFleet.getVisibilityLevelToPlayerFleet();
				if ((level == VisibilityLevel.COMPOSITION_AND_FACTION_DETAILS ||
						level == VisibilityLevel.COMPOSITION_DETAILS) && 
						data.activeFleet.wasMousedOverByPlayer()) {
					data.daysSinceSeenByPlayer = 0f;
				}
			}
			
			if (shouldDespawn(data)) {
				data.activeFleet.despawn(FleetDespawnReason.PLAYER_FAR_AWAY, null);
				data.activeFleet = null;
				continue;
			}
			
			if (shouldSpawn(data)) {
				data.activeFleet = data.spawner.spawnFleet(data);
				if (data.activeFleet != null) {
					data.activeFleet.addDespawnListener(this);
				}
				continue;
			}
			
		}
	}
	
	protected boolean shouldSpawn(RouteData data) {
		if (data.activeFleet != null) return false;
		
		//if (true) return true;
		
		Vector2f interpLoc = data.getInterpolatedLocation();
		
		CampaignFleetAPI player = Global.getSector().getPlayerFleet();
		float distLY = Misc.getDistanceLY(interpLoc, player.getLocationInHyperspace());
		if (distLY < SPAWN_DIST_LY) return true;
		
		return false;
	}
	
	protected boolean shouldDespawn(RouteData data) {
		if (data.activeFleet == null) return false;
		if (data.daysSinceSeenByPlayer < DAYS_SINCE_SEEN_BEFORE_DESPAWN) return false;
		if (data.activeFleet.getBattle() != null) return false;
		
		//if (true) return false;
		
		CampaignFleetAPI player = Global.getSector().getPlayerFleet();
		float distLY = Misc.getDistanceLY(data.activeFleet.getLocationInHyperspace(), player.getLocationInHyperspace());
		if (distLY > DESPAWN_DIST_LY) return true;
		
		return false;
	}
	
	protected void advanceRoutes(float days) {
		Iterator<RouteData> iter = routes.iterator();
		while (iter.hasNext()) {
			RouteData route = iter.next();
			//if (route.isSuspended()) continue;
			
			if (route.current == null && route.segments.isEmpty()) {
				iter.remove();
				removeFromMap(route);
				continue;
			}
			
			if (route.current == null) route.current = route.segments.get(0);
			
			route.current.elapsed += days;
			route.daysSinceSeenByPlayer += days;
			
			//if (route.isSuspended()) continue;
			
			if (route.current.elapsed >= route.current.daysMax) {
				int index = route.segments.indexOf(route.current);
				if (index < route.segments.size() - 1) {
					route.current = route.segments.get(index + 1);
				} else {
					removeFromMap(route);
					iter.remove();
				}
			}
		}
	}
	
	
	
	public void reportFleetDespawnedToListener(FleetOrStubAPI fleet, FleetDespawnReason reason, Object param) {
		if (reason == FleetDespawnReason.PLAYER_FAR_AWAY) {
			return;
		}
		//((CampaignFleetAPI)fleet).getName()
		boolean found = false;
		for (RouteData curr : routes) {
			if (curr.activeFleet != null && curr.activeFleet == fleet) {
				if (reason == FleetDespawnReason.PLAYER_FAR_AWAY) {
					//curr.setSuspended(false);
				} else {
					routes.remove(curr);
					removeFromMap(curr);
					found = true;
				}
				break;
			}
		}

// this can happen when route expires while fleet is active
//		if (!found) {
//			System.out.println("NOT FOUND FLEET BEING REMOVED");
//		}

	}

}


