package com.fs.starfarer.api.impl.campaign.ids;

public class Ranks {
	
	public static String SPACE_SAILOR = "spaceSailor";
	public static String SPACE_CHIEF = "spaceChief";
	public static String SPACE_ENSIGN = "spaceEnsign";
	public static String SPACE_LIEUTENANT = "spaceLieutenant";
	public static String SPACE_COMMANDER = "spaceCommander";
	public static String SPACE_CAPTAIN = "spaceCaptain";
	public static String SPACE_ADMIRAL = "spaceAdmiral";
	
	public static String GROUND_PRIVATE = "groundPrivate";
	public static String GROUND_SERGEANT = "groundSergeant";
	public static String GROUND_LIEUTENANT = "groundLieutenant";
	public static String GROUND_CAPTAIN = "groundCaptain";
	public static String GROUND_MAJOR = "groundMajor";
	public static String GROUND_COLONEL = "groundColonel";
	public static String GROUND_GENERAL = "groundGeneral";
	
	public static String CITIZEN = "citizen";
	
	public static String AGENT = "agent";
	
	
	public static String POST_AGENT = "agent";
	
	public static String POST_PATROL_COMMANDER = "patrolCommander";
	public static String POST_FLEET_COMMANDER = "fleetCommander";
	public static String POST_BASE_COMMANDER = "baseCommander";
	public static String POST_OUTPOST_COMMANDER = "outpostCommander";
	public static String POST_PORTMASTER = "portmaster";
	
	public static String POST_STATION_COMMANDER = "stationCommander";
	public static String POST_SUPPLY_OFFICER = "supplyOfficer";
	public static String POST_SUPPLY_MANAGER = "supplyManager";
	public static String POST_MEDICAL_SUPPLIER = "medicalSupplier";
	
	public static String POST_CITIZEN = "citizen";
	
	public static String POST_MERCENARY = "mercenary";
	public static String POST_INVESTIGATOR = "investigator";
	
	
	public static String POST_ADMINISTRATOR = "administrator";
	
	public static String POST_TRADER = "trader";
	public static String POST_MERCHANT = "merchant";
	public static String POST_INVESTOR = "investor";
	public static String POST_COMMODITIES_AGENT = "commodities_agent";
	
	public static String POST_SHADY = "shady";
	public static String POST_GANGSTER = "gangster";
	public static String POST_SMUGGLER = "smuggler";
	public static String POST_FENCE = "fence";
	
	//public static String POST_ = "";
	
	
}



