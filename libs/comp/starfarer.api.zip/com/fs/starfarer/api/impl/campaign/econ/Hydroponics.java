package com.fs.starfarer.api.impl.campaign.econ;

import com.fs.starfarer.api.impl.campaign.ids.Commodities;



public class Hydroponics extends BaseMarketConditionPlugin {

	public void apply(String id) {
//		market.getDemand(Commodities.REGULAR_CREW).getDemand().modifyFlat(id, ConditionData.HYDROPONICS_COMPLEX_CREW);
//		market.getDemand(Commodities.REGULAR_CREW).getNonConsumingDemand().modifyFlat(id, ConditionData.HYDROPONICS_COMPLEX_CREW * ConditionData.CREW_MARINES_NON_CONSUMING_FRACTION);
//		
//		float crewDemandMet = market.getDemand(Commodities.REGULAR_CREW).getClampedAverageFractionMet();
//		
//		market.getDemand(Commodities.ORGANICS).getDemand().modifyFlat(id, ConditionData.HYDROPONICS_COMPLEX_ORGANICS * crewDemandMet);
//		market.getDemand(Commodities.HEAVY_MACHINERY).getDemand().modifyFlat(id, ConditionData.HYDROPONICS_COMPLEX_MACHINERY * crewDemandMet);
//		
//		float productionMult = getProductionMult(market, Commodities.ORGANICS);
//		
		
		
		float mult = getBaseSizeMult();
		market.getCommodityData(Commodities.FOOD).getSupply().modifyFlat(id, ConditionData.HYDROPONICS_COMPLEX_FOOD * mult);
		//market.getCommodityData(Commodities.FOOD).getSupply().modifyFlat(id, ConditionData.HYDROPONICS_COMPLEX_FOOD);
	}

	public void unapply(String id) {
//		market.getDemand(Commodities.REGULAR_CREW).getDemand().unmodify(id);
//		market.getDemand(Commodities.REGULAR_CREW).getNonConsumingDemand().unmodify(id);
//		
//		market.getDemand(Commodities.ORGANICS).getDemand().unmodify(id);
//		market.getDemand(Commodities.HEAVY_MACHINERY).getDemand().unmodify(id);
//		
		market.getCommodityData(Commodities.FOOD).getSupply().unmodify(id);
	}

}
