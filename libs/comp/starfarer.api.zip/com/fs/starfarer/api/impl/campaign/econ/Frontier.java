package com.fs.starfarer.api.impl.campaign.econ;

import com.fs.starfarer.api.impl.campaign.ids.Commodities;

public class Frontier extends BaseMarketConditionPlugin {

	public void apply(String id) {
		float pop = getPopulation(market);
		market.getDemand(Commodities.HAND_WEAPONS).getDemand().modifyFlat(id, Math.max(10f, pop * ConditionData.FRONTIER_WEAPONS));
		market.getDemand(Commodities.SUPPLIES).getDemand().modifyFlat(id, Math.max(10f, pop * ConditionData.FRONTIER_SUPPLIES));
		market.getDemand(Commodities.LUXURY_GOODS).getDemand().modifyMult(id, ConditionData.FRONTIER_LUXURY_PENALTY);
	}

	public void unapply(String id) {
		market.getDemand(Commodities.HAND_WEAPONS).getDemand().unmodify(id);
		market.getDemand(Commodities.SUPPLIES).getDemand().unmodify(id);
		market.getDemand(Commodities.LUXURY_GOODS).getDemand().unmodify(id);
	}

}
