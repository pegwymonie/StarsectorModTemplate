package com.fs.starfarer.api.impl.campaign.procgen.themes;

import java.util.Random;

import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.fleets.BaseRouteFleetManager;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactoryV2;
import com.fs.starfarer.api.impl.campaign.fleets.FleetParams;
import com.fs.starfarer.api.impl.campaign.fleets.RouteManager;
import com.fs.starfarer.api.impl.campaign.fleets.RouteManager.RouteData;
import com.fs.starfarer.api.impl.campaign.fleets.RouteManager.RouteSegment;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.FleetTypes;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;

public class RuinsFleetRouteManager extends BaseRouteFleetManager {

	protected StarSystemAPI system;
	protected IntervalUtil interval = new IntervalUtil(1f, 14f); 
	
	public RuinsFleetRouteManager(StarSystemAPI system) {
		this.system = system;
	}

	public String getRouteSourceId() {
		return "salvage_" + system.getId();
	}
	
	public void advance(float amount) {

//		if (!system.getName().toLowerCase().contains("lamya")) {
//			return;
//		}
		float days = Global.getSector().getClock().convertToDays(amount);
		interval.advance(days);
		if (interval.intervalElapsed()) {
			String id = getRouteSourceId();
			int max = getMaxFleets();
			int curr = RouteManager.getInstance().getNumRoutesFor(id);
			if (curr >= max) return;
			
			
			MarketAPI market = pickSourceMarket();
			if (market != null) {
				Long seed = new Random().nextLong();
				RouteData route = RouteManager.getInstance().addRoute(id, market, seed, this);
				float distLY = Misc.getDistanceLY(market.getLocationInHyperspace(), system.getLocation());
				float travelDays = distLY * 1.5f;
				
				float prepDays = 2f + (float) Math.random() * 3f;
				float endDays = 8f + (float) Math.random() * 3f; // longer since includes time from jump-point to source

				float totalTravelTime = prepDays + endDays + travelDays * 2f;
				float stayDays = Math.max(20f, totalTravelTime);
				
				route.addSegment(new RouteSegment(prepDays, market.getLocationInHyperspace(), market.getContainingLocation()));
				route.addSegment(new RouteSegment(travelDays,
												  market.getLocationInHyperspace(), market.getContainingLocation(), 
												  system.getLocation(), system));
				route.addSegment(new RouteSegment(stayDays, system.getLocation(), system));
				route.addSegment(new RouteSegment(travelDays, 
												  system.getLocation(), system,
												  market.getLocationInHyperspace(), market.getContainingLocation()));
				route.addSegment(new RouteSegment(endDays, market.getLocationInHyperspace(), market.getContainingLocation()));
			}
		}
	}
	
	protected int getMaxFleets() {
		float salvage = getVeryApproximateSalvageValue(system);
		return (int) (1 + Math.min(salvage / 2, 7));
	}
	
	public static float getVeryApproximateSalvageValue(StarSystemAPI system) {
		return system.getEntitiesWithTag(Tags.SALVAGEABLE).size();
	}
	
	public MarketAPI pickSourceMarket() {
//		if (true) {
//			return Global.getSector().getEconomy().getMarket("jangala");
//		}
		
		WeightedRandomPicker<MarketAPI> markets = new WeightedRandomPicker<MarketAPI>();
		
		for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
			if (market.getFaction().isHostileTo(Factions.INDEPENDENT)) continue;
			if (market.getContainingLocation() == null) continue;
			if (market.getContainingLocation().isHyperspace()) continue;
			
			float distLY = Misc.getDistanceLY(system.getLocation(), market.getLocationInHyperspace());
			float weight = market.getSize();
			
			float f = Math.max(0.1f, 1f - Math.min(1f, distLY / 20f));
			f *= f;
			weight *= f;
			
			markets.add(market, weight);
		}
		
		return markets.pick();
	}
	

	public CampaignFleetAPI spawnFleet(RouteData route) {
		Random random = new Random();
		if (route.getSeed() != null) {
			random = new Random(route.getSeed());
		}
		
		WeightedRandomPicker<String> picker = new WeightedRandomPicker<String>(random);
		picker.add(FleetTypes.SCAVENGER_SMALL, 10f);
		picker.add(FleetTypes.SCAVENGER_MEDIUM, 15f);
		picker.add(FleetTypes.SCAVENGER_LARGE, 5f);
		
		String type = picker.pick();
		
		boolean pirate = random.nextBoolean();
		CampaignFleetAPI fleet = createScavenger(type, system.getLocation(), route.getMarket(), pirate, random);
		if (fleet == null) return null;;
		
		fleet.addScript(new ScavengerFleetAssignmentAI(fleet, route, pirate));
		
		return fleet;
	}
	
	public static CampaignFleetAPI createScavenger(String type, Vector2f locInHyper, MarketAPI source, boolean pirate, Random random) {
		if (random == null) random = new Random();

		
		if (type == null) {
			WeightedRandomPicker<String> picker = new WeightedRandomPicker<String>(random);
			picker.add(FleetTypes.SCAVENGER_SMALL, 10f);
			picker.add(FleetTypes.SCAVENGER_MEDIUM, 15f);
			picker.add(FleetTypes.SCAVENGER_LARGE, 5f);
			type = picker.pick();
		}
		
		
		int combat = 0;
		int freighter = 0;
		int tanker = 0;
		int transport = 0;
		int utility = 0;
		
		
		if (type.equals(FleetTypes.SCAVENGER_SMALL)) {
			combat = random.nextInt(2) + 1;
			tanker = random.nextInt(2) + 1;
			utility = random.nextInt(2) + 1;
		} else if (type.equals(FleetTypes.SCAVENGER_MEDIUM)) {
			combat = 4 + random.nextInt(7);
			freighter = 4 + random.nextInt(5);
			tanker = 3 + random.nextInt(4);
			transport = random.nextInt(2);
			utility = 3 + random.nextInt(4);
		} else if (type.equals(FleetTypes.SCAVENGER_LARGE)) {
			combat = 10 + random.nextInt(11);
			freighter = 6 + random.nextInt(7);
			tanker = 5 + random.nextInt(6);
			transport = 3 + random.nextInt(8);
			utility = 6 + random.nextInt(7);
		}
		
		if (pirate) {
			combat += transport;
			combat += utility;
			transport = utility = 0;
		}
		
		
		FleetParams params = new FleetParams(
				locInHyper,
				source, 
				Factions.INDEPENDENT,
				Factions.SCAVENGERS, // fleet's faction, if different from above; the above is also used for source market picking
				type,
				combat, // combatPts
				freighter, // freighterPts 
				tanker, // tankerPts
				transport, // transportPts
				0, // linerPts
				0, // civilianPts 
				utility, // utilityPts
				0f, // qualityBonus
				1f, // qualityOverride
				1f, // officer num mult
				0 // officer level bonus
				);
		params.random = random;
		
		CampaignFleetAPI fleet = FleetFactoryV2.createFleet(params);
		if (fleet == null) return null;;
		
		fleet.setFaction(Factions.INDEPENDENT, true);
		
		fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_SCAVENGER, true);
		
		if (pirate) {
			Misc.makeLowRepImpact(fleet, "scav");
		}
		
		return fleet;
	}
	

}







