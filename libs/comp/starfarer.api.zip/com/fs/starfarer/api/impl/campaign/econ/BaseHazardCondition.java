package com.fs.starfarer.api.impl.campaign.econ;

import java.util.Map;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.impl.campaign.procgen.ConditionGenDataSpec;


public class BaseHazardCondition extends BaseMarketConditionPlugin {
	
	public void apply(String id) {
		Object test = Global.getSettings().getSpec(ConditionGenDataSpec.class, condition.getId(), true);
		if (test instanceof ConditionGenDataSpec) {
			ConditionGenDataSpec spec = (ConditionGenDataSpec) test;
			float hazard = spec.getHazard();
			if (hazard != 0) {
				market.getHazard().modifyFlat(id, hazard, condition.getName());
			}
		}
		
	}

	public void unapply(String id) {
		market.getHazard().unmodifyFlat(id);
	}

	@Override
	public Map<String, String> getTokenReplacements() {
		return super.getTokenReplacements();
	}

}
