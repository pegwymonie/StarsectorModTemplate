package com.fs.starfarer.api.impl.campaign.missions;

import java.util.ArrayList;

import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketConditionAPI;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.MissionCompletionRep;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.RepRewards;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;

public class SurveyPlanetMissionCreator extends BaseMissionCreator {
	
	protected transient WeightedRandomPicker<PlanetAPI> planetPicker = new WeightedRandomPicker<PlanetAPI>();
	
	protected Object readResolve() {
		return this;
	}
	
	@Override
	public void advance(float amount) {
		super.advance(amount);
	}


	protected void initPicker() {
		planetPicker = new WeightedRandomPicker<PlanetAPI>();
		for (StarSystemAPI system : Global.getSector().getStarSystems()) {
			if (!Misc.getMarketsInLocation(system).isEmpty()) continue;
			
			for (PlanetAPI planet : system.getPlanets()) {
				if (!SurveyPlanetMission.isValidMissionTarget(planet)) continue;
				
				float weight = 1f;
				for (MarketConditionAPI mc : planet.getMarket().getConditions()) {
					weight += mc.getGenSpec().getXpMult();
				}
				
				planetPicker.add(planet);
			}
		}
	}
	
	protected void prunePicker() {
		for (PlanetAPI planet : new ArrayList<PlanetAPI>(planetPicker.getItems())) {
			if (!SurveyPlanetMission.isValidMissionTarget(planet)) {
				planetPicker.remove(planet);
			}
		}
	}
	

	@Override
	protected MissionCreationData createMission() {
		
		initPicker();
		prunePicker();
		
		PlanetAPI target = planetPicker.pick();
		if (target == null) return null;
		
		WeightedRandomPicker<MarketAPI> marketPicker = new WeightedRandomPicker<MarketAPI>();
		for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
			marketPicker.add(market, market.getSize());
		}
		MarketAPI market = marketPicker.pick();
		if (market == null) return null;
		
		String faction = market.getFactionId();
		if (!market.getFaction().isHostileTo(Factions.INDEPENDENT) && (float) Math.random() > 0.67f) {
			faction = Factions.INDEPENDENT;
		}
		
		MissionCompletionRep rep = new MissionCompletionRep(RepRewards.HIGH, RepLevel.WELCOMING,
														   -RepRewards.TINY, RepLevel.INHOSPITABLE);
		
		int days = 120;
//		int reward = (int) Misc.getDistance(market.getLocationInHyperspace(), target.getLocationInHyperspace());
//		reward *= 1.5f;
		
		int reward = (int) Misc.getDistance(new Vector2f(), target.getLocationInHyperspace());
		//reward *= 0.75f;
		
		reward = (reward / 10000) * 10000;
		//reward += 10000;
		if (reward < 10000) reward = 10000;

		
		SurveyPlanetMission mission = new SurveyPlanetMission(market.getId(), faction, target, reward, days, rep);
		MissionCreationData data = new MissionCreationData(mission, mission.getMarket());
		
		return data;
	}

	@Override
	protected int getMaxConcurrent() {
		return (int) Global.getSettings().getFloat("maxSurveyPlanetConcurrent");
	}

	@Override
	protected Class<?> getMissionClass() {
		return AnalyzeEntityMission.class;
	}

	
}



