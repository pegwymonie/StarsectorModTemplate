package com.fs.starfarer.api.impl.campaign.econ;

import com.fs.starfarer.api.impl.campaign.ids.Commodities;

public class Cryosanctum extends BaseMarketConditionPlugin {

	public void apply(String id) {
		float pop = getPopulation(market);
		
		market.getDemand(Commodities.CREW).getDemand().modifyFlat(id, pop * ConditionData.CRYOSANCTUM_CREW_MULT);
		market.getDemand(Commodities.CREW).getNonConsumingDemand().modifyFlat(id, pop * ConditionData.CRYOSANCTUM_CREW_MULT * ConditionData.CREW_MARINES_NON_CONSUMING_FRACTION);
		
		market.getDemand(Commodities.VOLATILES).getDemand().modifyFlat(id, pop * ConditionData.CRYOSANCTUM_VOLATILES_MULT);
		market.getDemand(Commodities.ORGANICS).getDemand().modifyFlat(id, pop * ConditionData.CRYOSANCTUM_ORGANICS_MULT);
		market.getDemand(Commodities.HEAVY_MACHINERY).getDemand().modifyFlat(id, pop * ConditionData.CRYOSANCTUM_MACHINERY_MULT);
		
		market.getCommodityData(Commodities.CREW).getSupply().modifyFlat(id, ConditionData.CRYOSANCTUM_CREW);
		market.getCommodityData(Commodities.ORGANS).getSupply().modifyFlat(id, ConditionData.CRYOSANCTUM_ORGANS);
		market.getStability().modifyFlat(id, ConditionData.STABILITY_CRYOSANCTUM, "Cryosanctum");
	}

	public void unapply(String id) {
		market.getDemand(Commodities.CREW).getDemand().unmodify(id);
		market.getDemand(Commodities.CREW).getNonConsumingDemand().unmodify(id);
		
		market.getDemand(Commodities.VOLATILES).getDemand().unmodify(id);
		market.getDemand(Commodities.ORGANICS).getDemand().unmodify(id);
		market.getDemand(Commodities.HEAVY_MACHINERY).getDemand().unmodify(id);
		
		market.getCommodityData(Commodities.CREW).getSupply().unmodify(id);
		market.getCommodityData(Commodities.ORGANS).getSupply().unmodify(id);
		market.getStability().unmodify(id);
		
	}

}
