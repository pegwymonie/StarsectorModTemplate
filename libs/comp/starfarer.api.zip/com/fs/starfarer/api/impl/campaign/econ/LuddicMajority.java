package com.fs.starfarer.api.impl.campaign.econ;

import java.util.Arrays;

import com.fs.starfarer.api.impl.campaign.ids.Commodities;

public class LuddicMajority extends BaseMarketConditionPlugin {

	private static String [] luddicFactions = new String [] {
		"knights_of_ludd",
		"luddic_church",
		"luddic_path",
	};
	public void apply(String id) {
		if (Arrays.asList(luddicFactions).contains(market.getFactionId())) {
			market.getStability().modifyFlat(id, ConditionData.STABILITY_LUDDIC_MAJORITY_BONUS, "Luddic majority");
		} else {
			market.getStability().modifyFlat(id, ConditionData.STABILITY_LUDDIC_MAJORITY_PENALTY, "Luddic majority");
		}
		
		market.getDemand(Commodities.LUXURY_GOODS).getDemand().modifyMult(id, ConditionData.LUDDIC_MAJORITY_LUXURY_MULT);
	}

	public void unapply(String id) {
		market.getStability().unmodify(id);
		
		market.getDemand(Commodities.LUXURY_GOODS).getDemand().unmodify(id);
	}

}
