package com.fs.starfarer.api.impl.campaign.econ;

import com.fs.starfarer.api.campaign.econ.MarketDemandAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;

public class TradeCenter extends BaseMarketConditionPlugin {

	public void apply(String id) {
		//float pop = getPopulation(market);
		float mult = getBaseSizeMult();
		float credits = mult * ConditionData.TRADE_CENTER_STOCKPILE_CREDITS_PER_DEMAND_PER_SIZE;
		for (MarketDemandAPI demand: market.getDemandData().getDemandList()) {
			if (demand.getBaseCommodity().hasTag(Commodities.TAG_CREW) || 
					demand.getBaseCommodity().hasTag(Commodities.TAG_MARINES) ||
					demand.getBaseCommodity().hasTag(Commodities.TAG_NON_ECONOMIC)) {
				continue;
			}
			float basePrice = demand.getBaseCommodity().getBasePrice();
			float baseUtility = demand.getBaseCommodity().getUtility();
			if (basePrice <= 0 || baseUtility <= 0) continue;
			float baseDemand = credits / basePrice * baseUtility;
			demand.getDemand().modifyFlat(id, baseDemand);
			demand.getNonConsumingDemand().modifyFlat(id, baseDemand);
		}
		
		market.getStability().modifyFlat(id, ConditionData.STABILITY_TRADE_CENTER, "Trade center");
	}

	public void unapply(String id) {
		for (MarketDemandAPI demand: market.getDemandData().getDemandList()) {
			demand.getDemand().unmodify(id);
			demand.getNonConsumingDemand().unmodify(id);
		}
		
		market.getStability().unmodify(id);
	}

}
