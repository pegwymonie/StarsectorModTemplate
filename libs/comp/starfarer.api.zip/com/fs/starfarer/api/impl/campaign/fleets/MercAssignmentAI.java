package com.fs.starfarer.api.impl.campaign.fleets;

import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.FleetAssignment;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.events.CampaignEventManagerAPI;
import com.fs.starfarer.api.campaign.events.CampaignEventTarget;
import com.fs.starfarer.api.impl.campaign.ids.Events;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;

public class MercAssignmentAI implements EveryFrameScript {

	private CampaignFleetAPI fleet;
	private MarketAPI source;
	private int startingFP;
	//private IntervalUtil tracker = new IntervalUtil(0.5f, 1.5f);
	public MercAssignmentAI(CampaignFleetAPI fleet, MarketAPI source) {
		this.fleet = fleet;
		startingFP = fleet.getFleetPoints();
		this.source = source;
		giveInitialAssignment();
	}

	private void giveInitialAssignment() {
		float daysToOrbit = getDaysToOrbit();
		fleet.addAssignment(FleetAssignment.ORBIT_PASSIVE, source.getPrimaryEntity(), daysToOrbit,
							"resupplying at " + source.getName());
	}
	
	private StarSystemAPI pickNearbyStarSystemToDefend() {
		WeightedRandomPicker<MarketAPI> picker = new WeightedRandomPicker<MarketAPI>();
		
		CampaignEventManagerAPI eventManager = Global.getSector().getEventManager();
		
		for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
			//if (market.getFactionId().equals(Factions.PIRATES)) continue;
			if (fleet.getFaction().isHostileTo(market.getFaction())) continue;
			if (market.getStarSystem() == null) continue;
			
			float dist = Misc.getDistance(market.getLocationInHyperspace(), fleet.getLocationInHyperspace());
			if (dist < 1000) dist = 1000;
			float weight = 10000f / dist;
			
			if (eventManager.isOngoing(new CampaignEventTarget(market), Events.SYSTEM_BOUNTY)) {
				weight *= 5f;
			}
			
			picker.add(market, weight);
		}
		MarketAPI market = picker.pick();
		if (market == null) return null;
		return market.getStarSystem();
	}
	
	private boolean orderedReturn = false;
	private void giveReturnToSourceMarketOrders() {
		if (!orderedReturn) {
			orderedReturn = true;
			
			fleet.clearAssignments();
			fleet.addAssignment(FleetAssignment.GO_TO_LOCATION, source.getPrimaryEntity(), 1000,
								"travelling to " + source.getName());
			fleet.addAssignment(FleetAssignment.ORBIT_PASSIVE, source.getPrimaryEntity(), getDaysToOrbit(),
								"orbiting " + source.getName());
			fleet.addAssignment(FleetAssignment.GO_TO_LOCATION_AND_DESPAWN, source.getPrimaryEntity(), 1000);
		}
	}
	
	private float daysTotal = 0f;
	public void advance(float amount) {
		float days = Global.getSector().getClock().convertToDays(amount);
		daysTotal += days;
		
		if (daysTotal > 90f) {
			giveReturnToSourceMarketOrders();
			return;
		}
		
		if (fleet.getAI().getCurrentAssignment() != null) {
			float fp = fleet.getFleetPoints();
			if (fp < startingFP * .67f) {
				giveReturnToSourceMarketOrders();
			}
		} else {
			float daysToOrbit = getDaysToOrbit();
			StarSystemAPI system = pickNearbyStarSystemToDefend();
			if (system != null) {
				Vector2f dest = Misc.getPointAtRadius(system.getLocation(), 1500);
				LocationAPI loc = Global.getSector().getHyperspace();
				SectorEntityToken token = loc.createToken(dest.x, dest.y);
				
				if (system != fleet.getContainingLocation()) {
					fleet.addAssignment(FleetAssignment.GO_TO_LOCATION, token, 1000,
										"travelling to the " + system.getBaseName() + " star system");
				}
				
				if ((float) Math.random() > 0.75f) {
					fleet.addAssignment(FleetAssignment.PATROL_SYSTEM, system.getHyperspaceAnchor(), 20,
							"patrolling around the " + system.getBaseName() + " star system");
				} else {
					fleet.addAssignment(FleetAssignment.PATROL_SYSTEM, system.getStar(), 20,
							"patrolling the " + system.getBaseName() + " star system");
					
				}
				
				fleet.addAssignment(FleetAssignment.GO_TO_LOCATION, source.getPrimaryEntity(), 1000,
									"returning to " + source.getName());
				fleet.addAssignment(FleetAssignment.ORBIT_PASSIVE, source.getPrimaryEntity(), daysToOrbit,
									"resupplying at " + source.getName());
			}
		}
	}

	
	private float getDaysToOrbit() {
		return 2f + (float) Math.random() * 2f;
	}
	
	public boolean isDone() {
		return false;
	}
	public boolean runWhilePaused() {
		return false;
	}

}





