package com.fs.starfarer.api.impl.campaign.econ;

import java.awt.Color;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketConditionAPI;
import com.fs.starfarer.api.campaign.econ.MarketConditionPlugin;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.util.Misc;

public class BaseMarketConditionPlugin implements MarketConditionPlugin {

	protected MarketAPI market;
	protected MarketConditionAPI condition;
	
	public void init(MarketAPI market, MarketConditionAPI condition) {
		this.market = market;
		this.condition = condition;
	}
	
	public void apply(String id) {
	}

	public void unapply(String id) {
	}
	
	
	public void applyBaseDemandForSuppliesIfNeeded(String id) {
		int size = market.getSize();
		if (size == 1) {
			market.getDemand(Commodities.SUPPLIES).getDemand().modifyFlat(id, ConditionData.BASE_SUPPLIES_1);
		} else if (size == 2) {
			market.getDemand(Commodities.SUPPLIES).getDemand().modifyFlat(id, ConditionData.BASE_SUPPLIES_2);
		} else if (size == 3) {
			market.getDemand(Commodities.SUPPLIES).getDemand().modifyFlat(id, ConditionData.BASE_SUPPLIES_3);
		}
	}
	
	public void unapplyBaseDemandForSupplies(String id) {
		market.getDemand(Commodities.SUPPLIES).getDemand().unmodify(id);
	}

	
	public float getBaseSizeMult() {
		float size = market.getSize();
		if (size <= 1) return 0.125f;
		if (size == 2) return 0.25f;
		if (size == 3) return 0.5f;
		
		return (float) Math.pow(2, size - 4);
	}
	
	public float getPopulation(MarketAPI market) {
		return (float) Math.pow(10, market.getSize());
//		float mult = 10f;
//		int size = market.getSize();
//		switch (size) {
//		case 1: return 60 * mult;
//		case 2: return 125 * mult;
//		case 3: return 250 * mult;
//		case 4: return 500 * mult;
//		case 5: return 1000 * mult;
//		case 6: return 2000 * mult;
//		case 7: return 4000 * mult;
//		case 8: return 8000 * mult;
//		case 9: return 16000 * mult;
//		case 10: return 32000 * mult;
//		}
//		return 10f;
	}
	
	
	
	public static float getProductionMult(MarketAPI market, String ... demandClasses) {
		float min = 1f;
		float total = 0f;
		for (String demandClass : demandClasses) {
			float f = market.getDemand(demandClass).getClampedFractionMet();
			if (f < min) min = f;
			total += f;
		}
		float range = 1f - min;
		if (range <= 0) return 1f;
		
		float num = (float) demandClasses.length;
		
		float extra = (total - min * num) / (range * num);
		extra *= extra;
		
		return min + extra * range;
	}
	
	public static float getCrewDemandMet(MarketAPI market) {
		float crewDemandMet = market.getDemand(Commodities.CREW).getClampedFractionMet();
		return crewDemandMet;
	}
	
	public static float getLowStabilityBonusMult(MarketAPI market) {
		float s = market.getStabilityValue();
		//if (true) return 1f + (10f - s) * 0.2f;
		if (true) return 1f + (10f - s) * 0.1f;
		
		switch ((int)market.getStabilityValue()) {
		case 0:
			return 3f;
		case 1:
			return 2.5f;
		case 2:
			return 2f;
		case 3:
			return 1.5f;
		case 4:
		case 5:
		case 6:
		case 7:
		case 8:
		case 9:
		case 10:
			return 1f;
		default:
			return 1f;
		}
	}
	
	public static float getLowStabilityPenaltyMult(MarketAPI market) {
		float s = market.getStabilityValue();
		//if (true) return 0.1f + s * 0.09f;
		if (true) return 0.5f + s * 0.05f;
		
		switch ((int)market.getStabilityValue()) {
		case 0:
			return 0.1f;
		case 1:
			return 0.25f;
		case 2:
			return 0.5f;
		case 3:
			return .75f;
		case 4:
		case 5:
		case 6:
		case 7:
		case 8:
		case 9:
		case 10:
			return 1f;
		default:
			return 1f;
		}
	}
	
	public static float getHighStabilityBonusMult(MarketAPI market) {
		float s = market.getStabilityValue();
		//if (true) return 1f + s * 0.2f;
		if (true) return 1f + s * 0.1f;
		
		switch ((int)market.getStabilityValue()) {
		case 0:
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:
		case 6:
			return 1f;
		case 7:
			return 1.5f;
		case 8:
			return 2f;
		case 9:
			return 2.5f;
		case 10:
			return 3f;
		default:
			return 1f;
		}
	}
	
	public static float getHighStabilityPenaltyMult(MarketAPI market) {
		float s = market.getStabilityValue();
		//if (true) return 0.1f + (10f - s) * 0.09f;
		if (true) return 0.5f + (10f - s) * 0.05f;
		
		switch ((int)market.getStabilityValue()) {
		case 0:
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:
		case 6:
			return 1f;
		case 7:
			return .75f;
		case 8:
			return 0.5f;
		case 9:
			return 0.25f;
		case 10:
			return 0.1f;
		default:
			return 1f;
		}		
	}
	
	public static float getProductionMult(float ... demandMet) {
		float min = 1f;
		float total = 0f;
		for (float f : demandMet) {
			if (f < min) min = f;
			total += f;
		}
		float range = 1f - min;
		if (range <= 0) return 1f;
		
		float num = (float) demandMet.length;
		
		float extra = (total - min * num) / (range * num);
		extra *= extra;
		
		return min + extra * range;
	}
	
	public static void main(String[] args) {
		System.out.println(getProductionMult(1f));
		System.out.println(getProductionMult(1f, 1f, 1f));
		System.out.println(getProductionMult(1f, 0f));
		System.out.println(getProductionMult(1f, 1f, 0f));
		System.out.println(0.3333f * 0.33333f);
		System.out.println(getProductionMult(1f, 0.5f, 0f));
		System.out.println(getProductionMult(1f, 0.5f, 0.5f));
		System.out.println(2f/3f * 2f/3f);
	}


	public List<String> getRelatedCommodities() {
		return null;
	}

	public void setParam(Object param) {
		
	}

	public Map<String, String> getTokenReplacements() {
		HashMap<String, String> tokens = new LinkedHashMap<String, String>();
		
		tokens.put("$playerName", Global.getSector().getCharacterData().getName());
		if (market != null) {
			tokens.put("$market", market.getName());
			tokens.put("$marketFaction", market.getFaction().getDisplayName());
			tokens.put("$TheMarketFaction", Misc.ucFirst(market.getFaction().getDisplayNameWithArticle()));
			tokens.put("$theMarketFaction", market.getFaction().getDisplayNameWithArticle());
			
			if (market.getPrimaryEntity().getLocation() instanceof StarSystemAPI) {
				//tokens.put("$marketSystem", ((StarSystemAPI)eventTarget.getLocation()).getBaseName() + " star system");
				tokens.put("$marketSystem", ((StarSystemAPI)market.getPrimaryEntity().getLocation()).getBaseName());
			} else {
				tokens.put("$marketSystem", "hyperspace");
			}
		}
		
		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		if (playerFleet != null) {
			String fleetOrShip = "fleet";
			if (playerFleet.getFleetData().getMembersListCopy().size() == 1) {
				fleetOrShip = "ship";
				if (playerFleet.getFleetData().getMembersListCopy().get(0).isFighterWing()) {
					fleetOrShip = "fighter wing";
				}
			}
			tokens.put("$playerShipOrFleet", fleetOrShip);
		}
		
		return tokens;
	}

	public String[] getHighlights() {
		return null;
	}
	
	public Color[] getHighlightColors() {
		String [] highlights = getHighlights();
		if (highlights != null) {
			Color c = Global.getSettings().getColor("buttonShortcut");
			Color [] colors = new Color[highlights.length];
			Arrays.fill(colors, c);
			return colors;
		}
		return null;
	}
	
	
	public void addTokensToList(List<String> list, String ... keys) {
		Map<String, String> tokens = getTokenReplacements();
		for (String key : keys) {
			if (tokens.containsKey(key)) {
				list.add(tokens.get(key));
			}
		}
	}

	public boolean isTransient() {
		return true;
	}

	public boolean showIcon() {
		return true;
	}
}




