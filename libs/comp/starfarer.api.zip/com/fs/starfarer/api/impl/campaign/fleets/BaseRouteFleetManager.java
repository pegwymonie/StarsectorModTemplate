package com.fs.starfarer.api.impl.campaign.fleets;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.impl.campaign.fleets.RouteManager.RouteFleetSpawner;

public abstract class BaseRouteFleetManager implements EveryFrameScript, RouteFleetSpawner {

	
	
	public boolean isDone() {
		return false;
	}

	public boolean runWhilePaused() {
		return false;
	}

}
