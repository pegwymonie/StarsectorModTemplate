package com.fs.starfarer.api.impl.campaign.ids;

public class BattleObjectives {

	public static final String NAV_BUOY = "nav_buoy";
	public static final String COMM_RELAY = "comm_relay";
	public static final String SENSOR_JAMMER = "sensor_array";
}
