package com.fs.starfarer.api.impl.campaign.missions;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BaseOnMessageDeliveryScript;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.ReputationActionResponsePlugin.ReputationAdjustmentResult;
import com.fs.starfarer.api.campaign.comm.CommMessageAPI;
import com.fs.starfarer.api.campaign.comm.MessagePriority;
import com.fs.starfarer.api.campaign.econ.CommoditySpecAPI;
import com.fs.starfarer.api.campaign.events.CampaignEventTarget;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.RepActionEnvelope;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.RepActions;
import com.fs.starfarer.api.impl.campaign.events.BaseEventPlugin;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.impl.campaign.ids.Strings;
import com.fs.starfarer.api.impl.campaign.rulecmd.AddRemoveCommodity;
import com.fs.starfarer.api.plugins.SurveyPlugin;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.Misc.Token;

public class SurveyPlanetMissionEvent extends BaseEventPlugin {
	
	private SurveyPlanetMission mission = null;
	private float elapsedDays = 0;
	private boolean ended = false;
	
	public void init(String type, CampaignEventTarget eventTarget) {
		super.init(type, eventTarget, false);
	}
	
	@Override
	public void setParam(Object param) {
		mission = (SurveyPlanetMission) param;
	}

	public void startEvent() {
		super.startEvent();
		
		String stageId = "accept";
		Global.getSector().reportEventStage(this, stageId, mission.getAcceptLocation(), MessagePriority.DELIVER_IMMEDIATELY, 
				new BaseOnMessageDeliveryScript() {
					public void beforeDelivery(CommMessageAPI message) {
						message.setStarSystemId(mission.getPlanet().getContainingLocation().getId());
						message.setCenterMapOnEntity(mission.getPlanet());
					}
				});
		
		mission.getPlanet().getMemoryWithoutUpdate().set("$spm_target", true, mission.getDuration());
		mission.getPlanet().getMemoryWithoutUpdate().set("$spm_eventRef", this, mission.getDuration());
		Misc.setFlagWithReason(mission.getPlanet().getMemoryWithoutUpdate(), MemFlags.ENTITY_MISSION_IMPORTANT,
						       "spm", true, mission.getDuration());
	}
	
	private void endEvent() {
		ended = true;
		
		mission.getPlanet().getMemoryWithoutUpdate().unset("$spm_target");
		mission.getPlanet().getMemoryWithoutUpdate().unset("$spm_eventRef");
		
		Misc.setFlagWithReason(mission.getPlanet().getMemoryWithoutUpdate(), MemFlags.ENTITY_MISSION_IMPORTANT,
							  "spm", false, 0f);
	}
	
	public void advance(float amount) {
		if (!isEventStarted()) return;
		if (isDone()) return;
		
		float days = Global.getSector().getClock().convertToDays(amount);
		
		//memory.advance(days);
		elapsedDays += days;
		
		if (mission.getDuration() - elapsedDays <= 0) {
			Global.getSector().reportEventStage(this, "failure", Global.getSector().getPlayerFleet(), MessagePriority.DELIVER_IMMEDIATELY,
					new BaseOnMessageDeliveryScript() {
						public void beforeDelivery(CommMessageAPI message) {
							ReputationAdjustmentResult result = Global.getSector().adjustPlayerReputation(
									new RepActionEnvelope(RepActions.MISSION_FAILURE, mission.getRepChange(),
														  message, null, true),
														  mission.getFactionId());
						}
					});
			endEvent();
			return;
		}
	}
	

	@Override
	public boolean callEvent(String ruleId, final InteractionDialogAPI dialog, List<Token> params, Map<String, MemoryAPI> memoryMap) {
		String action = params.get(0).getString(memoryMap);
		
		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		CargoAPI cargo = playerFleet.getCargo();
		
		if (action.equals("finishedSurvey")) {
			int credits = mission.getReward();
			
			AddRemoveCommodity.addCreditsGainText(credits, dialog.getTextPanel());
			cargo.getCredits().add(credits);
			
			Global.getSector().reportEventStage(this, "success", Global.getSector().getPlayerFleet(), MessagePriority.DELIVER_IMMEDIATELY, 
					new BaseOnMessageDeliveryScript() {
						public void beforeDelivery(CommMessageAPI message) {
							ReputationAdjustmentResult result = Global.getSector().adjustPlayerReputation(
									new RepActionEnvelope(RepActions.MISSION_SUCCESS, mission.getRepChange(),
														  message, dialog.getTextPanel(), true), 
														  mission.getFactionId());
						}
					});
			endEvent();
		}
		
		return true;
	}
	

	protected transient List<String> extraHighlights = null;
	public Map<String, String> getTokenReplacements() {
		
		Map<String, String> map = super.getTokenReplacements();
		
		int daysLeft = (int) (mission.getDuration() - elapsedDays);
		if (daysLeft < 1) daysLeft = 1;
		String daysLeftStr = daysLeft + " days";
		if (daysLeft <= 1) {
			daysLeftStr = daysLeft + " day";
		}
		
		map.put("$sender", "Mission Board");
		map.put("$daysLeft", daysLeftStr);
		
		PlanetAPI planet = mission.getPlanet();
		map.put("$planetName", planet.getName());
		
		if (planet.getContainingLocation() != null) {
			map.put("$systemName", planet.getContainingLocation().getNameWithLowercaseType());
		}
		map.put("$rewardCredits", Misc.getWithDGS((int) mission.getReward()) + Strings.C);

		
		SurveyPlugin plugin = (SurveyPlugin) Global.getSettings().getNewPluginInstance("surveyPlugin");
		plugin.init(Global.getSector().getPlayerFleet(), planet);
		
		Map<String, Integer> required = plugin.getRequired();
		Map<String, Integer> consumed = plugin.getConsumed();
		
		extraHighlights = new ArrayList<String>();
		
		String planetHazardPercent = "" + (int) Math.round(planet.getMarket().getHazardValue() * 100f) + "%";
		extraHighlights.add(planetHazardPercent);
		
		List<String> reqList = new ArrayList<String>();
		for (String req : required.keySet()) {
			CommoditySpecAPI spec = Global.getSettings().getCommoditySpec(req);
			int qty = required.get(req);
			reqList.add("" + qty + " " + spec.getName().toLowerCase());
			extraHighlights.add("" + qty);
		}
		
		List<String> conList = new ArrayList<String>();
		for (String con : consumed.keySet()) {
			CommoditySpecAPI spec = Global.getSettings().getCommoditySpec(con);
			int qty = consumed.get(con);
			conList.add("" + qty + " " + spec.getName().toLowerCase());
			extraHighlights.add("" + qty);
		}
		
		
		String info = String.format("The planet is %s %s with a hazard rating of %s. " +
				"Factoring in any cost-reducing equipment in your fleet (if any), it requires %s " +
									"on hand to fully survey. " +
									"A survey will also consume %s.",
									planet.getSpec().getAOrAn(),
									planet.getTypeNameWithLowerCaseWorld().toLowerCase(),
									planetHazardPercent,
									Misc.getAndJoined(reqList),
									Misc.getAndJoined(conList));
		
		map.put("$surveyInfo", info);
		
		return map;
	}

	@Override
	public String[] getHighlights(String stageId) {
		int daysLeft = (int) (mission.getDuration() - elapsedDays);
		if (daysLeft < 1) daysLeft = 1;
		
		List<String> result = new ArrayList<String>();
		
		if ("posting".equals(stageId)) {
			result.add("" + daysLeft);
			addTokensToList(result, "$rewardCredits");
		} else if ("success".equals(stageId)) {
			addTokensToList(result, "$rewardCredits");
		} else {
			addTokensToList(result, "$rewardCredits");
			result.add("" + daysLeft);
		}
		
		if (extraHighlights != null && 
				("posting".equals(stageId) || "accept".equals(stageId))) {
			result.addAll(extraHighlights);
		}
		
		
		return result.toArray(new String[0]);
	}
	
	@Override
	public Color[] getHighlightColors(String stageId) {
		return super.getHighlightColors(stageId);
	}

	public boolean isDone() {
		return ended;
	}

	public String getEventName() {
		//return mission.getName();
		//return "Analyze derelict - " + daysLeftStr;
		
		PlanetAPI planet = mission.getPlanet();
		String name = planet.getName();
		
		int daysLeft = (int) (mission.getDuration() - elapsedDays);
		String days = "";
		if (daysLeft > 0) {
			//days = ", " + daysLeft + " days left";
			days = ", " + daysLeft + "d";
			//days = "" + daysLeft + " days";
		} else {
			days = ", <1d";
		}
		if (isDone()) {
			return "Survey " + name + " - done"; 
		}
		return "Survey " + name + days;
	}

	
	
	@Override
	public CampaignEventCategory getEventCategory() {
		return CampaignEventCategory.MISSION;
	}

	@Override
	public String getEventIcon() {
		return Global.getSettings().getSpriteName("campaignMissions", "survey_planet");
	}

	@Override
	public String getCurrentImage() {
		return Global.getSector().getFaction(mission.getFactionId()).getLogo();
	}

	
	
}



