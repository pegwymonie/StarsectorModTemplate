package com.fs.starfarer.api.impl.campaign.missions;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.MissionBoardAPI;
import com.fs.starfarer.api.campaign.MissionBoardAPI.MissionAvailabilityAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;

public class FactionCommissionMissionCreator implements EveryFrameScript {
	public static Logger log = Global.getLogger(FactionCommissionMissionCreator.class);
	
	private MissionBoardAPI board;
	private IntervalUtil tracker = new IntervalUtil(0.25f, .75f);
	
	public FactionCommissionMissionCreator() {
		board = Global.getSector().getMissionBoard();
	}
	
	
	public void advance(float amount) {
		Global.getSettings().profilerBegin(this.getClass().getSimpleName() + ".advance()");
		
		float days = Global.getSector().getClock().convertToDays(amount);
		tracker.advance(days);
		if (tracker.intervalElapsed() && Misc.getCommissionFactionId() == null) {
			// which factions need to have commissions on offer?
			List<FactionAPI> factions = new ArrayList<FactionAPI>();
			for (FactionAPI faction : Global.getSector().getAllFactions()) {
				if (faction.getCustomBoolean(Factions.CUSTOM_OFFERS_COMMISSIONS)) {
					factions.add(faction);
				}
			}
			
			// sync missions available with list of what needs to be on offer
			for (MissionAvailabilityAPI ma : board.getMissionsCopy()) {
				if (ma.getMission() instanceof FactionCommissionMission) {
					FactionCommissionMission fcm = (FactionCommissionMission) ma.getMission();
					if (!factions.contains(fcm.getFaction())) {
						board.removeMission(fcm, true);
					} else {
						fcm.setTimestamp(Global.getSector().getClock().getTimestamp());
						factions.remove(fcm.getFaction());
					}
				}
			}
			for (FactionAPI faction : factions) {
				createMission(faction);
			}

		}
		Global.getSettings().profilerEnd();
	}
	
	
	protected void createMission(FactionAPI faction) {
		FactionCommissionMission mission = new FactionCommissionMission(faction.getId());
		
		log.info("Created FactionCommissionMission: " + faction.getDisplayName());

		for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
			if (market.getFaction() == faction) {
				board.makeAvailableAt(mission, market);
			}
		}
	}
	
	

	public boolean isDone() {
		return false;
	}

	public boolean runWhilePaused() {
		return false;
	}

}
