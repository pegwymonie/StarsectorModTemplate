package com.fs.starfarer.api.impl.campaign.fleets;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

import org.apache.log4j.Logger;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.Script;
import com.fs.starfarer.api.campaign.BattleAPI;
import com.fs.starfarer.api.campaign.CampaignEventListener;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.FleetAssignment;
import com.fs.starfarer.api.campaign.FleetEncounterContextPlugin;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.PlayerMarketTransaction;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.CargoAPI.CargoItemType;
import com.fs.starfarer.api.campaign.JumpPointAPI.JumpDestination;
import com.fs.starfarer.api.campaign.econ.CommodityFlowAPI;
import com.fs.starfarer.api.campaign.econ.CommodityOnMarketAPI;
import com.fs.starfarer.api.campaign.econ.EconomyAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.TransferTotalAPI;
import com.fs.starfarer.api.campaign.events.CampaignEventManagerAPI;
import com.fs.starfarer.api.characters.AbilityPlugin;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.combat.EngagementResultAPI;
import com.fs.starfarer.api.impl.campaign.SmugglingFactionChangeScript;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.FleetTypes;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.impl.campaign.shared.MarketConnectionActivityData;
import com.fs.starfarer.api.impl.campaign.shared.SharedData;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;

public class EconomyFleetManager implements EveryFrameScript, CampaignEventListener {

	public static Logger log = Global.getLogger(EconomyFleetManager.class);
	//public static final String TRADE_SUMMARY = "core_TradeSummaryKey";
	
	public static class TradeSummary {
		//private Map<MarketAPI, TradeConnectionSummary> connections = new HashMap<MarketAPI, TradeConnectionSummary>();
		public Map<String, Map<String, TradeConnectionData>> connections = new HashMap<String, Map<String,TradeConnectionData>>();
		
		public TradeConnectionData getConnectionSummary(String from, String to) {
			MarketAPI marketFrom = Global.getSector().getEconomy().getMarket(from);
			MarketAPI marketTo = Global.getSector().getEconomy().getMarket(to);
			return getConnectionData(marketFrom, marketTo);
		}
			
		public TradeConnectionData getConnectionData(MarketAPI from, MarketAPI to) {
			Map<String, TradeConnectionData> fromMarket = connections.get(from.getId());
			if (fromMarket == null) {
				fromMarket = new HashMap<String, TradeConnectionData>();
				connections.put(from.getId(), fromMarket);
			}
			
			TradeConnectionData conn = fromMarket.get(to.getId());
			if (conn == null) {
				conn = new TradeConnectionData(from, to);
				fromMarket.put(to.getId(), conn);
			}
			return conn;
		}
	}
	
	public static class TradeConnectionCommodity {
		public float volume;
		public CommodityOnMarketAPI commodity;
		public TradeConnectionCommodity(CommodityOnMarketAPI commodity) {
			this.commodity = commodity;
		}
	}
	
	public static class TradeConnectionData {
		public MarketAPI from;
		public MarketAPI to;
		
		public float totalBoughtVolume;
		public float totalSoldVolume;
		public float totalBoughtSmuggled;
		public float totalSoldSmuggled;
		public float fuelBought, fuelSold;
		public float personnelBought, personnelSold;
		public float cargoBought, cargoSold;
		public List<TradeConnectionCommodity> bought = new ArrayList<TradeConnectionCommodity>();
		public List<TradeConnectionCommodity> sold = new ArrayList<TradeConnectionCommodity>();
		public TradeConnectionData(MarketAPI from, MarketAPI to) {
			this.from = from;
			this.to = to;
		}
		
		public void populateCargoFromBought(CampaignFleetAPI fleet, boolean includeIllegal, boolean onlyIllegal) {
			populateCargoFromList(fleet, bought, includeIllegal, onlyIllegal);
		}
		
		public void populateCargoFromSold(CampaignFleetAPI fleet, boolean includeIllegal, boolean onlyIllegal) {
			populateCargoFromList(fleet, sold, includeIllegal, onlyIllegal);
		}
			
		public void populateCargoFromList(CampaignFleetAPI fleet, List<TradeConnectionCommodity> list,
										  boolean includeIllegal, boolean mostlyIllegal) {
			float maxCargo = fleet.getCargo().getMaxCapacity();
			float maxFuel = fleet.getCargo().getMaxFuel();

			fleet.getCargo().clear();
			float max = 0;
			for (TradeConnectionCommodity tcc : list) {
				if (tcc.commodity.isPersonnel()) continue;
				if (tcc.commodity.isFuel()) continue;
				boolean illegal = from.isIllegal(tcc.commodity) || to.isIllegal(tcc.commodity);
				if (illegal && !includeIllegal) continue;
				if (!illegal && mostlyIllegal) continue; //&& !firstLegal) continue;
				
//				if (firstLegal && mostlyIllegal) {
//					max += Math.min(tcc.volume, (totalBoughtSmuggled + totalSoldSmuggled) * 0.25f);
//				} else {
//					max += tcc.volume;
//				}
				max += tcc.volume;
			}
			
			if (max < 1) max = 1;
			
			float total = 0;
			float cargoFraction = 1f - FleetFactory.SUPPLIES_FRACTION;
			float fuelFraction = 1f - FleetFactory.FUEL_FRACTION;
			for (TradeConnectionCommodity tcc : list) {
				if (tcc.commodity.isPersonnel()) continue;
				//if (tcc.commodity.isFuel()) continue;
				boolean illegal = from.isIllegal(tcc.commodity) || to.isIllegal(tcc.commodity);
				if (illegal && !includeIllegal) continue;
				if (!illegal && mostlyIllegal) continue; //&& !firstLegal) continue;
				//if (!illegal) firstLegal = false;
				
				if (tcc.commodity.isFuel()) {
					float q = maxFuel * fuelFraction;
					fleet.getCargo().addItems(CargoItemType.RESOURCES, tcc.commodity.getId(), q);
					total += q;
				} else {	
					float q = maxCargo * cargoFraction * tcc.volume / max;
					fleet.getCargo().addItems(CargoItemType.RESOURCES, tcc.commodity.getId(), q);
					total += q;
					//if (total >= maxCargo * cargoFraction) break;
				}
			}
//			fleet.getCargo().addItems(CargoItemType.RESOURCES, Commodities.SUPPLIES, maxCargo * 0.25f);
//			fleet.getCargo().addItems(CargoItemType.RESOURCES, Commodities.FUEL, maxFuel * 0.5f);
			
			//System.out.println("Fuel: " + fleet.getCargo().getFuel());
		}
		
		
		public String getCommodityListText(List<TradeConnectionCommodity> orig, boolean withIllegal) {
			List<TradeConnectionCommodity> list = orig;
			if (!withIllegal) {
				list = new ArrayList<TradeConnectionCommodity>();
				for (TradeConnectionCommodity tcc : orig) {
					boolean illegal = from.isIllegal(tcc.commodity) || to.isIllegal(tcc.commodity);
					if (!illegal) {
						list.add(tcc);
					}
				}
			}
			
			String text = "";
			if (list.size() == 1) {
				text = list.get(0).commodity.getCommodity().getName();
			}
			if (list.size() == 2) {
				text = list.get(0).commodity.getCommodity().getName() + " and " + 
								list.get(1).commodity.getCommodity().getName();
			}
			if (list.size() >= 3) {
				text = list.get(0).commodity.getCommodity().getName() + ", " + 
								list.get(1).commodity.getCommodity().getName() + ", and other commodities";
			}
			if (text.isEmpty())  text = "goods";
			return text.toLowerCase();
		}
		public void reset() {
			totalBoughtVolume = 0;
			totalSoldVolume = 0;
			fuelBought = personnelBought = cargoBought = 0;
			fuelSold = personnelSold = cargoSold = 0;
			bought.clear();
			sold.clear();
		}
		public TradeConnectionCommodity getBoughtCommodity(String commodityId) {
			for (TradeConnectionCommodity tcc : bought) {
				if (tcc.commodity.getId().equals(commodityId)) return tcc;
			}
			TradeConnectionCommodity tcc = new TradeConnectionCommodity(from.getCommodityData(commodityId));
			bought.add(tcc);
			return tcc;
		}
		public TradeConnectionCommodity getSoldCommodity(String commodityId) {
			for (TradeConnectionCommodity tcc : sold) {
				if (tcc.commodity.getId().equals(commodityId)) return tcc;
			}
			TradeConnectionCommodity tcc = new TradeConnectionCommodity(from.getCommodityData(commodityId));
			sold.add(tcc);
			return tcc;
		}
		public void addBoughtTransaction(TransferTotalAPI td) {
			TradeConnectionCommodity tcc = getBoughtCommodity(td.getCommodityId());
			tcc.volume += td.getQuantity();
			//totalBoughtVolume += td.getAverage();
		}
		public void addSoldTransaction(TransferTotalAPI td) {
			TradeConnectionCommodity tcc = getSoldCommodity(td.getCommodityId());
			tcc.volume += td.getQuantity();
			//totalSoldVolume += td.getAverage();
		}
		
		public void prune() {
			dedupe();
			prune(bought, 5);
			prune(sold, 5);
			updateTotalVolume();
		}
		
		public void dedupe() {
			for (TradeConnectionCommodity b : bought) {
				for (TradeConnectionCommodity s : sold) {
					if (b.commodity == s.commodity) {
						if (b.volume > s.volume) {
							b.volume -= s.volume;
							s.volume = 0;
						} else if (s.volume > b.volume) {
							s.volume -= b.volume;
							b.volume = 0;
						}
					}
				}
			}
		}
		
		public void updateTotalVolume() {
			totalBoughtVolume = 0f;
			fuelBought = personnelBought = cargoBought = 0;
			totalBoughtSmuggled = 0f;
			for (TradeConnectionCommodity tcc : bought) {
				totalBoughtVolume += tcc.volume;
				if (tcc.commodity.isPersonnel()) {
					personnelBought += tcc.volume;
				} else if (tcc.commodity.isFuel()) {
					fuelBought += tcc.volume;
				} else {
					cargoBought += tcc.volume;
				}
				if (from.isIllegal(tcc.commodity) || to.isIllegal(tcc.commodity) ||
						//from.getFaction().isHostileTo(to.getFaction())) {
						from.getFaction().isAtBest(to.getFaction(), RepLevel.HOSTILE)) {
					totalBoughtSmuggled += tcc.volume;
				}
			}
			totalSoldVolume = 0f;
			fuelSold = personnelSold = cargoSold = 0;
			totalSoldSmuggled = 0;
			for (TradeConnectionCommodity tcc : sold) {
				totalSoldVolume += tcc.volume;
				if (tcc.commodity.isPersonnel()) {
					personnelSold += tcc.volume;
				} else if (tcc.commodity.isFuel()) {
					fuelSold += tcc.volume;
				} else {
					cargoSold += tcc.volume;
				}
				if (from.isIllegal(tcc.commodity) || to.isIllegal(tcc.commodity) || 
						//from.getFaction().isHostileTo(to.getFaction())) {
						from.getFaction().isAtBest(to.getFaction(), RepLevel.HOSTILE)) {
					totalSoldSmuggled += tcc.volume;
				}
			}
		}
		
		public void prune(List<TradeConnectionCommodity> list, int numToKeep) {
			if (list.size() <= 0) return;
		    PriorityQueue<TradeConnectionCommodity> queue = new PriorityQueue<TradeConnectionCommodity>(list.size(),
	    		new Comparator<TradeConnectionCommodity>() {
					public int compare(TradeConnectionCommodity o1, TradeConnectionCommodity o2) {
						return (int) (o1.volume - o2.volume);
					}
			});
		    
		    float minTradeVolume = Global.getSettings().getFloat("minTradeVolumeToSpawnFleets");
		    for (TradeConnectionCommodity tcc : list) { 
		    	if (tcc.volume < minTradeVolume) continue;
		        if (queue.size() < numToKeep) queue.add(tcc);
		        else if (queue.peek().volume < tcc.volume) {
		            queue.poll();
		            queue.add(tcc);
		        }
		    }
		    list.clear();
		    while (!queue.isEmpty()) {
		    	list.add(0, queue.poll());
		    }
		}
	}
	
	public static class TradeFleetData {
		public CampaignFleetAPI fleet;
		public TradeConnectionData conn;
		public boolean isSmuggler;
		public boolean isLiner;
		public TradeFleetData(CampaignFleetAPI fleet, TradeConnectionData conn, boolean isSmuggler, boolean isLiner) {
			this.fleet = fleet;
			this.conn = conn;
			this.isSmuggler = isSmuggler;
			this.isLiner = isLiner;
		}
		
		public void setLinerAssignment() {
			float loadUnloadDays = Math.min(10f, fleet.getFleetData().getMembersListCopy().size());
			loadUnloadDays = 1f + loadUnloadDays * (0.5f + (float) Math.random() * 0.5f);
			
			fleet.addAssignment(FleetAssignment.ORBIT_PASSIVE, conn.from.getPrimaryEntity(), loadUnloadDays,
							    "loading passengers at " + conn.from.getName(), new Script() {
					public void run() {
					}
				});
			fleet.addAssignment(FleetAssignment.DELIVER_RESOURCES, conn.to.getPrimaryEntity(), 1000, 
								    "carrying passengers to " + conn.to.getName());
			fleet.addAssignment(FleetAssignment.ORBIT_PASSIVE, conn.to.getPrimaryEntity(), loadUnloadDays,
									"offloading passengers at " + conn.to.getName());
			
			fleet.addAssignment(FleetAssignment.ORBIT_PASSIVE, conn.to.getPrimaryEntity(), loadUnloadDays,
								"loading passengers at " + conn.to.getName(), new Script() {
				public void run() {
				}
			});
			fleet.addAssignment(FleetAssignment.DELIVER_RESOURCES, conn.from.getPrimaryEntity(), 1000, 
								"returning to " + conn.from.getName() + " with passengers");
			fleet.addAssignment(FleetAssignment.ORBIT_PASSIVE, conn.from.getPrimaryEntity(), loadUnloadDays,
								"offloading passengers at " + conn.from.getName());
			
			fleet.addAssignment(FleetAssignment.GO_TO_LOCATION_AND_DESPAWN, conn.from.getPrimaryEntity(), 1000);
		}
		
		
		public void setAssignment(final boolean includeIllegal, final boolean mostlyIllegal) {
			final String listSell = conn.getCommodityListText(conn.sold, false);
			final String listBuy = conn.getCommodityListText(conn.bought, false);
			
			if (conn.sold.size() <= 0 && conn.bought.size() <= 0) {
				// ??? why are we even here?
				fleet.addAssignment(FleetAssignment.GO_TO_LOCATION_AND_DESPAWN, conn.from.getPrimaryEntity(), 1000);
				return;
			}
			
			float loadUnloadDays = Math.min(10f, fleet.getFleetData().getMembersListCopy().size());
			loadUnloadDays = 1f + loadUnloadDays * (0.5f + (float) Math.random() * 0.5f);
			
			//if (conn.sold.size() > 0) {
			if (conn.sold.size() > 0) {
				fleet.addAssignment(FleetAssignment.ORBIT_PASSIVE, conn.from.getPrimaryEntity(), loadUnloadDays,
								    "loading " + listSell + " from " + conn.from.getName(), new Script() {
					public void run() {
						conn.populateCargoFromSold(fleet, includeIllegal, mostlyIllegal);
					}
				});
				fleet.addAssignment(FleetAssignment.DELIVER_RESOURCES, conn.to.getPrimaryEntity(), 1000, 
								    "delivering " + listSell + " to " + conn.to.getName());
				fleet.addAssignment(FleetAssignment.ORBIT_PASSIVE, conn.to.getPrimaryEntity(), loadUnloadDays,
									"offloading " + listSell + " at " + conn.to.getName());
			} else {
				fleet.addAssignment(FleetAssignment.ORBIT_PASSIVE, conn.from.getPrimaryEntity(), loadUnloadDays,
									"preparing for a voyage to " + conn.to.getName());
				fleet.addAssignment(FleetAssignment.DELIVER_RESOURCES, conn.to.getPrimaryEntity(), 1000,
									"heading to " + conn.to.getName());
			}
			
			if (conn.bought.size() > 0) {
				fleet.addAssignment(FleetAssignment.ORBIT_PASSIVE, conn.to.getPrimaryEntity(), loadUnloadDays,
									"loading " + listBuy + " from " + conn.to.getName(), new Script() {
					public void run() {
						conn.populateCargoFromBought(fleet, includeIllegal, mostlyIllegal);
					}
				});
				fleet.addAssignment(FleetAssignment.DELIVER_RESOURCES, conn.from.getPrimaryEntity(), 1000, 
									"returning to " + conn.from.getName() + " with " + listBuy);
				fleet.addAssignment(FleetAssignment.ORBIT_PASSIVE, conn.from.getPrimaryEntity(), loadUnloadDays,
									"offloading " + listBuy + " at " + conn.from.getName());
			} else {
				fleet.addAssignment(FleetAssignment.ORBIT_PASSIVE, conn.to.getPrimaryEntity(), loadUnloadDays,
									"preparing for a return voyage to " + conn.from.getName());
				fleet.addAssignment(FleetAssignment.DELIVER_RESOURCES, conn.from.getPrimaryEntity(), 1000,
									"returning to " + conn.from.getName());
				fleet.addAssignment(FleetAssignment.ORBIT_PASSIVE, conn.from.getPrimaryEntity(), loadUnloadDays,
									"orbiting " + conn.from.getName());
			}
			
			fleet.addAssignment(FleetAssignment.GO_TO_LOCATION_AND_DESPAWN, conn.from.getPrimaryEntity(), 1000);
		}
		
	}
	

	
	private IntervalUtil tracker;
	
	private CampaignEventManagerAPI eventManager;
	private EconomyAPI economy;
	
	private List<TradeFleetData> activeFleets = new ArrayList<TradeFleetData>();
	//private TradeSummary summary;
	
	public EconomyFleetManager() {
		//tracker = new IntervalUtil(0.75f, 1.25f);
		float interval = Global.getSettings().getFloat("averageEconSpawnInterval");
		tracker = new IntervalUtil(interval * 0.75f, interval * 1.25f);
		
		economy = Global.getSector().getEconomy();
		eventManager = Global.getSector().getEventManager();
		
		//summary = new TradeSummary();
		//Global.getSector().getPersistentData().put(TRADE_SUMMARY, summary);
		
		Global.getSector().addListener(this);
	}
	
	public void advance(float amount) {
		//if (true) return;
		
		if (eventManager == null) eventManager = Global.getSector().getEventManager();
		
		//System.out.println("Active trade fleets: " + activeFleets.size());
		
		float days = Global.getSector().getClock().convertToDays(amount);
		tracker.advance(days);
		if (!tracker.intervalElapsed()) return;
		
		List<TradeFleetData> remove = new ArrayList<TradeFleetData>();
		for (TradeFleetData data : activeFleets) {
			if (data.fleet.getContainingLocation() == null ||
				!data.fleet.getContainingLocation().getFleets().contains(data.fleet)) {
				remove.add(data);
				log.info("Cleaning up orphaned trade fleet: " + data.fleet.getNameWithFaction());
			}
		}
		activeFleets.removeAll(remove);

		int maxFleets = (int) Global.getSettings().getFloat("maxEconFleets");
		log.debug("");
		log.debug("Checking whether to spawn trade fleet");
		if (activeFleets.size() < maxFleets) {
			log.info(activeFleets.size() + " out of a maximum " + maxFleets + " trade fleets in play");
			MarketAPI market = pickMarketToSpawnFleetFrom();
			if (market != null) {
				float spawnInterval = Global.getSettings().getFloat("minEconSpawnIntervalPerMarket");
				SharedData.getData().getMarketsThatSentTradeFleet().set(market.getId(), spawnInterval);
				
				log.info("Picked market [" + market.getName() + "] to spawn trade fleet from");
				TradeSummary summary = computeTradeSummaryForMarket(market);
				TradeConnectionData conn = pickConnectionFromMarket(market, summary);
				boolean liner = false;
				boolean includeIllegal = false;
				boolean mostlyIllegal = false;
				if (conn != null) {
					CampaignFleetAPI fleet = null;
					if ((float) Math.random() > 0.85f && !conn.from.getFaction().isAtBest(conn.to.getFaction(), RepLevel.HOSTILE)) {
						log.info("Will send liner fleet to market [" + conn.to.getName() + "]");
						fleet = createLinerFleet(market, conn.to);
						liner = true;
					} else {
						log.info("Will send trade fleet to market [" + conn.to.getName() + "]");
						String cargoSell = "";
						for (TradeConnectionCommodity tcc : conn.sold) {
							cargoSell += tcc.commodity.getCommodity().getName() + ",";
						}
						if (cargoSell.length() > 0) {
							cargoSell = cargoSell.substring(0, cargoSell.length() - 1);
						}
						String cargoBuy = "";
						for (TradeConnectionCommodity tcc : conn.bought) {
							cargoBuy += tcc.commodity.getCommodity().getName() + ",";
						}
						if (cargoBuy.length() > 0) {
							cargoBuy = cargoBuy.substring(0, cargoBuy.length() - 1);
						}
						float volume = Math.max(conn.totalBoughtVolume, conn.totalSoldVolume);
						log.info("Delivering: [" + cargoSell + "], bringing back [" + cargoBuy + "]; volume: " + (int) volume);
	
						//if (conn.from.getFaction().isHostileTo(conn.to.getFaction())) {
						if (conn.from.getFaction().isAtBest(conn.to.getFaction(), RepLevel.HOSTILE)) {
							//fleet = FleetFactory.createSmugglerFleet(market, conn);
							fleet = createSmugglerFleet(market, conn);
							includeIllegal = true;
							mostlyIllegal = false;
						} else {
							float totalVolume = conn.totalBoughtVolume + conn.totalSoldVolume;
							float totalSmuggled = conn.totalBoughtSmuggled + conn.totalSoldSmuggled;
							
							float smuggleChance = Math.max(0.1f, totalSmuggled / totalVolume);
							if (totalSmuggled <= 0) {
								smuggleChance = 0f;
							}
							if ((float) Math.random() < smuggleChance) { // || smuggleChance > 0) {
								//fleet = FleetFactory.createSmugglerFleet(market, conn);
								fleet = createSmugglerFleet(market, conn);
								includeIllegal = true;
								mostlyIllegal = true;
							} else {
								//fleet = FleetFactory.createTradeFleet(market, conn);
								fleet = createTradeFleet(market, conn);
							}
						}
					}
					if (fleet == null) {
						log.info("Failed to spawn fleet");
						return;
					}
					
					if (fleet.getFaction().getId().equals(Factions.PIRATES)) {
						fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_PIRATE, true);
					}
					
					SectorEntityToken entity = market.getPrimaryEntity();
					market.getPrimaryEntity().getContainingLocation().addEntity(fleet);
					fleet.setLocation(entity.getLocation().x, entity.getLocation().y);
					
					boolean smuggler = includeIllegal;
					TradeFleetData data = new TradeFleetData(fleet, conn, smuggler, liner);
					
					if (liner) {
						data.setLinerAssignment();
						fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_TRADE_FLEET, true);
					} else {
						data.setAssignment(includeIllegal, mostlyIllegal);
						MarketConnectionActivityData activity = SharedData.getData().getActivityTracker().getConnectionData(conn.from, conn.to);
						if (smuggler) {
							activity.getSmugglingPointsSent().add(fleet.getFleetPoints());
							fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_SMUGGLER, true);
						} else {
							activity.getTradePointsSent().add(fleet.getFleetPoints());
							fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_TRADE_FLEET, true);
						}
					}
					
					activeFleets.add(data);
					
					log.info("Spawned " + fleet.getFleetPoints() + " point economy fleet from [" + conn.from.getName() + "] to [" + conn.to.getName() + "]");
				} else {
					log.info("No worthwhile trade connections found from market [" + market.getName() + "]");
				}
			}
		} else {
			log.debug("Maximum number of trade fleets already in play (" + maxFleets + ")");
		}

	}
	
	public static CampaignFleetAPI createLinerFleet(MarketAPI market, MarketAPI to) {
		
		int tier = Math.min(market.getSize(), to.getSize()) - 3;
		if (tier > 10) tier = 10;
		if (tier < 1) tier = 1;
		
		String factionId = market.getFactionId();
		if (!market.getFaction().isHostileTo(Factions.INDEPENDENT) && 
				!to.getFaction().isHostileTo(Factions.INDEPENDENT)) {
			if ((float) Math.random() * 10f > market.getStabilityValue() + tier) {
				factionId = Factions.INDEPENDENT;
			}
		}
		
		log.info("Creating liner fleet of tier " + tier + " for market [" + market.getName() + "], going to [" + to.getName() + "]");
		
		float stabilityFactor = 1f + market.getStabilityValue() / 20f;
		
		float combat = tier * stabilityFactor;
		float liner = tier * 2f * stabilityFactor;
		float utility = 1f;
		
		CampaignFleetAPI fleet = FleetFactoryV2.createFleet(new FleetParams(
				null,
				market, 
				factionId,
				null, // fleet's faction, if different from above, which is also used for source market picking
				FleetTypes.TRADE_LINER,
				combat, // combatPts
				0f, // freighterPts 
				0f, // tankerPts
				0f, // transportPts
				liner, // linerPts
				0f, // civilianPts 
				utility, // utilityPts
				-0.25f, // qualityBonus
				-1f, // qualityOverride
				0.5f, // officer num mult
				-5 // officer level bonus
				));
		if (fleet == null) return null;
		
		if (market.getFaction().isHostileTo(Factions.INDEPENDENT)) {
			fleet.setFaction(market.getFactionId());
		}
		
		return fleet;
	}
	
	public static CampaignFleetAPI createSmugglerFleet(MarketAPI market, TradeConnectionData conn) {
		float maxVolume = Global.getSettings().getFloat("maxTradeVolume");
		//float volume = Math.max(conn.totalBoughtSmuggled, conn.totalSoldSmuggled);
		float volume = Math.max(conn.totalBoughtVolume, conn.totalSoldVolume);
		
		String factionId = Factions.INDEPENDENT;

		float fuelFraction = Math.max(conn.fuelBought, conn.fuelSold) / volume;
		float personnelFraction = Math.max(conn.personnelBought, conn.personnelSold) / volume;
		float cargoFraction = Math.max(conn.cargoBought, conn.cargoSold) / volume;
		
		if (fuelFraction + personnelFraction + cargoFraction > 0) {
			float mult = 1f / (fuelFraction + personnelFraction + cargoFraction);
			fuelFraction *= mult;
			personnelFraction *= mult;
			cargoFraction *= mult;
		}
		
//		float fv = volume * fuelFraction;
//		float pv = volume * personnelFraction;
//		float cv = volume * cargoFraction;
//
//		boolean fuelPrimary = fv > pv && fv > cv;
//		boolean personnelPrimary = pv > fv && pv > cv;
//		boolean cargoPrimary = !fuelPrimary && !personnelPrimary;
		
		//int tier = Math.round(volume / maxVolume * 10f);
		//int tier = Math.round(Misc.logOfBase(10f, volume) / Misc.logOfBase(10f, maxVolume) * 10f);
		int tier = Math.round((float) Math.pow(volume / maxVolume, 0.4f) * 5f);
		
		if (tier > 3) tier = 3;
		if (tier < 1) tier = 1;
		
		log.info("Creating smuggling fleet of tier " + tier + " for market [" + market.getName() + "] (volume: " + (int) volume + ")");
		
		float stabilityFactor = 1f + market.getStabilityValue() / 20f;
		
		float combat = tier * stabilityFactor;
		float freighter = tier * 2f * stabilityFactor * cargoFraction;
		float tanker = tier * 2f * stabilityFactor * fuelFraction;
		float transport = tier * 2f * stabilityFactor * personnelFraction;
		
		float utility = 1f;
		
//		if (!cargoPrimary) freighter *= 0.2f;
//		if (!fuelPrimary) tanker *= 0.2f;
//		if (!personnelPrimary) transport *= 0.2f;
		
		CampaignFleetAPI fleet = FleetFactoryV2.createFleet(new FleetParams(
				null,
				market, 
				factionId,
				null, // fleet's faction, if different from above, which is also used for source market picking
				FleetTypes.TRADE_SMUGGLER,
				combat, // combatPts
				freighter, // freighterPts 
				tanker, // tankerPts
				transport, // transportPts
				0f, // linerPts
				0f, // civilianPts 
				utility, // utilityPts
				-0.25f, // qualityBonus
				-1f, // qualityOverride
				0.5f, // officer num mult
				-5 // officer level bonus
				));
		if (fleet == null) return null;
		
		fleet.addScript(new SmugglingFactionChangeScript(fleet));
		
		if (market.getFaction().isHostileTo(Factions.INDEPENDENT)) {
			fleet.setFaction(market.getFactionId(), true);
		}
		
		return fleet;
	}
	
	public static CampaignFleetAPI createTradeFleet(MarketAPI market, TradeConnectionData conn) {
		float maxVolume = Global.getSettings().getFloat("maxTradeVolume");
		float volume = Math.max(conn.totalBoughtVolume, conn.totalSoldVolume);
		float stability = market.getStabilityValue();
		
		//int tier = Math.round(volume / maxVolume * 10f);
		//int tier = Math.round(Misc.logOfBase(10f, volume) / Misc.logOfBase(10f, maxVolume) * 10f);
		int tier = Math.round((float) Math.pow(volume / maxVolume, 0.4f) * 10f);
		if (tier > 10) tier = 10;
		if (tier < 1) tier = 1;
		
		String factionId = market.getFactionId();
		if (!market.getFaction().isHostileTo(Factions.INDEPENDENT) && 
				!conn.to.getFaction().isHostileTo(Factions.INDEPENDENT)) {
			if ((float) Math.random() * 10f > stability + tier) {
				factionId = Factions.INDEPENDENT;
			}
		}

		float fuelFraction = Math.max(conn.fuelBought, conn.fuelSold) / volume;
		float personnelFraction = Math.max(conn.personnelBought, conn.personnelSold) / volume;
		float cargoFraction = Math.max(conn.cargoBought, conn.cargoSold) / volume;
		
		if (fuelFraction + personnelFraction + cargoFraction > 0) {
			float mult = 1f / (fuelFraction + personnelFraction + cargoFraction);
			fuelFraction *= mult;
			personnelFraction *= mult;
			cargoFraction *= mult;
		}
		
//		float fv = volume * fuelFraction;
//		float pv = volume * personnelFraction;
//		float cv = volume * cargoFraction;
//
//		boolean fuelPrimary = fv > pv && fv > cv;
//		boolean personnelPrimary = pv > fv && pv > cv;
//		boolean cargoPrimary = !fuelPrimary && !personnelPrimary;
		
		log.info("Creating trade fleet of tier " + tier + " for market [" + market.getName() + "] (volume: " + (int) volume + ")");
		
		float stabilityFactor = 1f + market.getStabilityValue() / 20f;
		
		float combat = tier * stabilityFactor;
		float freighter = tier * 2f * stabilityFactor * cargoFraction;
		float tanker = tier * 2f * stabilityFactor * fuelFraction;
		float transport = tier * 2f * stabilityFactor * personnelFraction;
		float liner = 0f;
//		if ((float) Math.random() > 0.5f && transport >= 4f) {
//			transport *= 0.5f;
//			liner = transport;
//		}
		
		float utility = 1f;
		
//		if (!cargoPrimary) freighter *= 0.2f;
//		if (!fuelPrimary) tanker *= 0.2f;
//		if (!personnelPrimary) transport *= 0.2f;
		
		CampaignFleetAPI fleet = FleetFactoryV2.createFleet(new FleetParams(
				null,
				market, 
				factionId,
				null, // fleet's faction, if different from above, which is also used for source market picking
				FleetTypes.TRADE,
				combat, // combatPts
				freighter, // freighterPts 
				tanker, // tankerPts
				transport, // transportPts
				liner, // linerPts
				0f, // civilianPts 
				utility, // utilityPts
				-0.25f, // qualityBonus
				-1f, // qualityOverride
				0.5f, // officer num mult
				-5 // officer level bonus
				));
		
		return fleet;
	}
	
	
	
	
	public static TradeSummary computeTradeSummaryForMarket(MarketAPI market) {
		if (market == null) return null;
		
		TradeSummary summary = new TradeSummary();
		summary.connections.clear();
//		for (MarketAPI to : economy.getMarketsCopy()) {
//			if (to == market) continue;
//			TradeConnectionData conn = summary.getConnectionData(market, to);
//			conn.reset();
//		}
			
		for (CommodityOnMarketAPI com : market.getAllCommodities()) {
			if (com.isNonEcon()) continue;
			if (!com.getCommodity().isPrimary()) continue;
			
			CommodityFlowAPI tx = com.getFlow();
			List<TransferTotalAPI> bought = tx.getTopImports(10);
			for (TransferTotalAPI td : bought) {
				MarketAPI to = Global.getSector().getEconomy().getMarket(td.getMarketId());
				TradeConnectionData conn = summary.getConnectionData(market, to);
				conn.addBoughtTransaction(td);
			}
			
			List<TransferTotalAPI> sold = tx.getTopExports(10);
			for (TransferTotalAPI td : sold) {
				MarketAPI to = Global.getSector().getEconomy().getMarket(td.getMarketId());
				TradeConnectionData conn = summary.getConnectionData(market, to);
				conn.addSoldTransaction(td);
			}
		}
		
		return summary;
	}
	
	public MarketAPI pickMarketToSpawnFleetFrom() {
		WeightedRandomPicker<MarketAPI> picker = new WeightedRandomPicker<MarketAPI>();
		
		for (MarketAPI market : economy.getMarketsCopy()) {
			if (SharedData.getData().getMarketsThatSentTradeFleet().contains(market.getId())) continue;
			if (SharedData.getData().getMarketsWithoutTradeFleetSpawn().contains(market.getId())) continue;
			float mult = Misc.getSpawnChanceMult(market.getLocationInHyperspace());
			picker.add(market, market.getSize() * mult);
		}
		
		return picker.pick();
		//return economy.getMarket("tartessus");
	}
	
	
	public TradeConnectionData pickConnectionFromMarket(MarketAPI market, TradeSummary summary) {
		WeightedRandomPicker<TradeConnectionData> picker = new WeightedRandomPicker<TradeConnectionData>();
		
		float maxWeight = 0;
		float minMult = Global.getSettings().getFloat("minMinorTradeRouteChanceMult");
		float minTradeVolume = Global.getSettings().getFloat("minTradeVolumeToSpawnFleets");

		for (MarketAPI to : economy.getMarketsCopy()) {
			if (to == market) continue;

			TradeConnectionData conn = summary.getConnectionData(market, to);
			conn.prune();
			
			float weight = conn.totalBoughtVolume + conn.totalSoldVolume;
			if (weight > maxWeight) maxWeight = weight;
		}
		
		float minWeight = maxWeight * minMult;
		for (MarketAPI to : economy.getMarketsCopy()) {
			if (to == market) continue;
			
			//if (!to.getId().equals("umbra")) continue;
			TradeConnectionData conn = summary.getConnectionData(market, to);
			float weight = conn.totalBoughtVolume + conn.totalSoldVolume;
			
			if (weight < minTradeVolume) continue;
			
			if (weight < minWeight) weight = minWeight;
			picker.add(conn, weight);
		}
		
		return picker.pick();
	}
	
	
	public boolean isDone() {
		return false;
	}

	public boolean runWhilePaused() {
		return false;
	}
	
	private void applyTradeFPLost(TradeFleetData data) {
		float fpLost = Misc.getSnapshotFPLost(data.fleet);
		if (fpLost > 0 && !data.isLiner) {
			MarketConnectionActivityData activity = SharedData.getData().getActivityTracker().getConnectionData(
									data.conn.from, data.conn.to);
			if (data.isSmuggler) {
				activity.getSmugglingPointsLost().add(fpLost);
			} else {
				activity.getTradePointsLost().add(fpLost);
			}
		}
	}
	
	public void reportFleetDespawned(CampaignFleetAPI fleet, FleetDespawnReason reason, Object param) {
//		if (reason == FleetDespawnReason.DESTROYED_BY_FLEET) {
//			System.out.println(fleet.getNameWithFaction() + " destroyed by " + ((CampaignFleetAPI)param).getNameWithFaction());
//		}
		for (TradeFleetData data : activeFleets) {
			if (data.fleet == fleet) {
				activeFleets.remove(data);
				//SharedData.getData().getFleetLossTracker().reportTradeFleetLost(data, reason, param);
				if (reason == FleetDespawnReason.DESTROYED_BY_BATTLE) {
					applyTradeFPLost(data);
				}
				
				break;
			}
		}
	}

	public void reportFleetJumped(CampaignFleetAPI fleet, SectorEntityToken from, JumpDestination to) {
		
	}

	public void reportFleetReachedEntity(CampaignFleetAPI fleet, SectorEntityToken entity) {
		
	}

	public void reportPlayerMarketTransaction(PlayerMarketTransaction transaction) {
		
	}

	public void reportBattleFinished(CampaignFleetAPI primaryWinner, BattleAPI battle) {
		
	}
	
	public void reportBattleOccurred(CampaignFleetAPI primaryWinner, BattleAPI battle) {
		//System.out.println(winner.getNameWithFaction() + " defeated " + loser.getNameWithFaction());
		
		for (TradeFleetData data : activeFleets) {
			//if (data.fleet == winner || data.fleet == loser) {
			if (battle.getSideFor(data.fleet) != null) {
				applyTradeFPLost(data);
				if (data.fleet.getFleetPoints() <= 0) {
					activeFleets.remove(data);
				}
				break;
			}
		}
	}

	public void reportShownInteractionDialog(InteractionDialogAPI dialog) {
		
	}

	public void reportPlayerOpenedMarket(MarketAPI market) {
		
	}

	public void reportPlayerReputationChange(String faction, float delta) {
		
	}

	public void reportPlayerEngagement(EngagementResultAPI result) {
		
	}

	public void reportFleetSpawned(CampaignFleetAPI fleet) {
		
	}

	public void reportPlayerOpenedMarketAndCargoUpdated(MarketAPI market) {
		
	}

	public void reportEncounterLootGenerated(FleetEncounterContextPlugin plugin, CargoAPI loot) {
		
	}

	public void reportPlayerClosedMarket(MarketAPI market) {
		
	}

	public void reportPlayerReputationChange(PersonAPI person, float delta) {
		
	}
	
	public void reportPlayerActivatedAbility(AbilityPlugin ability, Object param) {
		
	}

	public void reportPlayerDeactivatedAbility(AbilityPlugin ability, Object param) {
		
	}
	
	public void reportPlayerDumpedCargo(CargoAPI cargo) {
		
	}
	
	public void reportPlayerDidNotTakeCargo(CargoAPI cargo) {
		
	}
}




