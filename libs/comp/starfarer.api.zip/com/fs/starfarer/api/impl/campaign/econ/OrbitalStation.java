package com.fs.starfarer.api.impl.campaign.econ;

import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Stats;

public class OrbitalStation extends BaseMarketConditionPlugin {

//	public static final float ORBITAL_STATION_FUEL_BASE = 500f;
//	public static final float ORBITAL_STATION_FUEL_MAX = 10000f;
//	public static final float ORBITAL_STATION_FUEL_MULT = 0.001f;
	public void apply(String id) {
		float pop = getPopulation(market);
		
		float fuelDemand = ConditionData.ORBITAL_STATION_FUEL_BASE + pop * ConditionData.ORBITAL_STATION_FUEL_MULT;
		if (fuelDemand > ConditionData.ORBITAL_STATION_FUEL_MAX) {
			fuelDemand = ConditionData.ORBITAL_STATION_FUEL_MAX;
		}
		
		market.getCommodityData(Commodities.CREW).getSupply().modifyFlat(id, ConditionData.ORBITAL_STATION_REGULAR_CREW_SUPPLY);
		
		market.getDemand(Commodities.CREW).getDemand().modifyFlat(id, ConditionData.ORBITAL_STATION_CREW);
		market.getDemand(Commodities.CREW).getNonConsumingDemand().modifyFlat(id, ConditionData.ORBITAL_STATION_CREW * ConditionData.CREW_MARINES_NON_CONSUMING_FRACTION);
		
		market.getDemand(Commodities.SUPPLIES).getDemand().modifyFlat(id, ConditionData.ORBITAL_STATION_SUPPLIES);
		market.getDemand(Commodities.FUEL).getDemand().modifyFlat(id, fuelDemand);
		
		market.getDemand(Commodities.SUPPLIES).getNonConsumingDemand().modifyFlat(id, ConditionData.ORBITAL_STATION_SUPPLIES * 0.5f);
		market.getDemand(Commodities.FUEL).getNonConsumingDemand().modifyFlat(id, fuelDemand * 0.5f);
		
		market.getStability().modifyFlat(id, ConditionData.STABILITY_ORBITAL_STATION, "Orbital station");
		
		//market.getStats().getDynamic().getStat(Stats.OFFICER_LEVEL_MULT).modifyFlat(id, ConditionData.ORBITAL_STATION_OFFICER_LEVEL_MULT_BONUS);
		market.getStats().getDynamic().getStat(Stats.OFFICER_NUM_MULT).modifyFlat(id, ConditionData.ORBITAL_STATION_OFFICER_NUM_MULT_BONUS);
	}

	public void unapply(String id) {
		market.getCommodityData(Commodities.CREW).getSupply().unmodify(id);
		
		market.getDemand(Commodities.CREW).getDemand().unmodify(id);
		market.getDemand(Commodities.CREW).getNonConsumingDemand().unmodify(id);
		
		market.getDemand(Commodities.SUPPLIES).getDemand().unmodify(id);
		market.getDemand(Commodities.FUEL).getDemand().unmodify(id);
		
		market.getDemand(Commodities.SUPPLIES).getNonConsumingDemand().unmodify(id);
		market.getDemand(Commodities.FUEL).getNonConsumingDemand().unmodify(id);
		
		market.getStability().unmodify(id);
		
		//market.getStats().getDynamic().getStat(Stats.OFFICER_LEVEL_MULT).unmodify(id);
		market.getStats().getDynamic().getStat(Stats.OFFICER_NUM_MULT).unmodify(id);
	}

}
