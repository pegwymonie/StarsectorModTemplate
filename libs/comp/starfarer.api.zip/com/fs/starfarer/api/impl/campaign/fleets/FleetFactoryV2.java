package com.fs.starfarer.api.impl.campaign.fleets;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.apache.log4j.Logger;
import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.FleetOrStubAPI;
import com.fs.starfarer.api.campaign.FleetStubAPI;
import com.fs.starfarer.api.campaign.FleetStubConverterPlugin;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.characters.MutableCharacterStatsAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.characters.SkillSpecAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.fleet.ShipRolePick;
import com.fs.starfarer.api.impl.campaign.events.OfficerManagerEvent;
import com.fs.starfarer.api.impl.campaign.events.OfficerManagerEvent.SkillPickPreference;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.impl.campaign.ids.Personalities;
import com.fs.starfarer.api.impl.campaign.ids.Ranks;
import com.fs.starfarer.api.impl.campaign.ids.ShipRoles;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.loading.AbilitySpecAPI;
import com.fs.starfarer.api.loading.FleetCompositionDoctrineAPI;
import com.fs.starfarer.api.plugins.OfficerLevelupPlugin;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;

public class FleetFactoryV2 {

	public static Logger log = Global.getLogger(FleetFactoryV2.class);
	
	public static FleetStubAPI createStub(Object params, LocationAPI containingLocation, Vector2f location) {
		FleetStubAPI stub = Global.getFactory().createStub();
		stub.getLocation().set(location);
		stub.setParams(params);
		//stub.setContainingLocation(containingLocation);
		containingLocation.addFleetStub(stub);
		return stub;
	}
	
	public static FleetOrStubAPI createFleetOrStub(Object params, LocationAPI containingLocation, Vector2f location) {
		FleetOrStubAPI result = null;
		
		FleetStubAPI stub = Global.getFactory().createStub();
		stub.getLocation().set(location);
		stub.setParams(params);
		//stub.setContainingLocation(containingLocation);
		containingLocation.addFleetStub(stub);
		result = stub;
		
		//boolean asStub = Misc.shouldConvertFromStub(containingLocation, location);
		//FleetStubConverterPlugin converter = Global.getSector().getPluginPicker().pickFleetStubConverter(stub);
		FleetStubConverterPlugin converter = stub.getConverter();
		boolean asFleet = converter.shouldConvertFromStub(stub);
		
		if (asFleet) {
			CampaignFleetAPI fleet = converter.convertToFleet(stub);
			result = fleet;
		}
		
		return result;
	}
	
	
	//protected static FleetCompositionDoctrineAPI doctrine;
	
	public static CampaignFleetAPI createFleet(FleetParams params) {
		Global.getSettings().profilerBegin("FleetFactoryV2.createFleet()");
		try {
			
		MarketAPI market = pickMarket(params);
		if (market == null) {
			market = Global.getFactory().createMarket("fake", "fake", 9);
			market.getStability().modifyFlat("fake", 10000);
			market.setFactionId(params.factionId);
			SectorEntityToken token = Global.getSector().getHyperspace().createToken(0, 0);
			market.setPrimaryEntity(token);
			//return null;
		}
		
//		if (market.getName().equals("Jangala")) {
//			System.out.println("wfwdfwef");
//		}
		
		String factionId = params.factionId;
		if (params.factionIdForShipPicking != null) {
			factionId = params.factionIdForShipPicking;
		}
		CampaignFleetAPI fleet = createEmptyFleet(factionId, params.fleetType, market);
		
//		if (true) {
//			FleetMemberAPI member = Global.getFactory().createFleetMember(FleetMemberType.SHIP, "tempest_Attack");
//			fleet.getFleetData().addFleetMember(member);
//			return fleet;
//		}
		
		FleetCompositionDoctrineAPI doctrine = fleet.getFaction().getCompositionDoctrine();
		
		float qf = market.getShipQualityFactor();
		qf += params.qualityBonus;
		if (params.qualityOverride >= 0) {
			qf = params.qualityOverride;
		}
		
		Random random = new Random();
		if (params.random != null) random = params.random;
		
		
		float combatPts = params.combatPts;
		float freighterPts = params.freighterPts;
		float tankerPts = params.tankerPts;
		float transportPts = params.transportPts;
		float linerPts = params.linerPts;
		float civilianPts = params.civilianPts;
		float utilityPts = params.utilityPts;
		
		boolean capitalOk = combatPts >= doctrine.getMinPointsForCombatCapital(); 
		boolean largeCarrierOk = combatPts >= doctrine.getMinPointsForLargeCarrier(); 

		boolean cfFail = false;
		while (combatPts > 0) {
			if (!cfFail && freighterPts > 0 && random.nextFloat() < doctrine.getCombatFreighterProbability()) {
				float pts = Math.min(freighterPts, combatPts);
				if (pts > 8) pts = 8;
				float added = addRandomCombatFreighters(pts, qf, fleet, random, market);
				combatPts -= added/2f;
				freighterPts -= added/2f;
				cfFail |= added < pts/2f;
				continue;
			}
			if (combatPts >= 16f) {
				float pts = add16PointGroup(qf, fleet, random, market, capitalOk, largeCarrierOk, combatPts - 16f, params);
				combatPts -= pts;
			} else if (combatPts >= 12f) {
				float pts = add12PointGroup(qf, fleet, random, market, capitalOk, combatPts - 12f, params);
				combatPts -= pts;
			} else if (combatPts >= 8f) {
				float pts = add8PointGroup(qf, fleet, random, market, capitalOk, combatPts - 8f, params);
				combatPts -= pts;
			} else {
				float pts = addRandomCombatShips(combatPts, qf, fleet, random, market, capitalOk, 0f, params);
				combatPts -= pts;
			}
		}
		
		addRandomShips(freighterPts, qf, fleet, random, market, 
				ShipRoles.FREIGHTER_SMALL,
				ShipRoles.FREIGHTER_MEDIUM,
				ShipRoles.FREIGHTER_LARGE);
		
		addRandomShips(tankerPts, qf, fleet, random, market, 
				ShipRoles.TANKER_SMALL,
				ShipRoles.TANKER_MEDIUM,
				ShipRoles.TANKER_LARGE);
		
		addRandomShips(transportPts, qf, fleet, random, market, 
				ShipRoles.PERSONNEL_SMALL,
				ShipRoles.PERSONNEL_MEDIUM,
				ShipRoles.PERSONNEL_LARGE);
		
		addRandomShips(linerPts, qf, fleet, random, market, 
				ShipRoles.LINER_SMALL,
				ShipRoles.LINER_MEDIUM,
				ShipRoles.LINER_LARGE);

		
		addRandomShips(civilianPts, qf, fleet, random, market, ShipRoles.CIV_RANDOM);
		addRandomShips(utilityPts, qf, fleet, random, market, ShipRoles.UTILITY);

		//if (market.getFaction().getCustom())
		//fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_PIRATE, true);
		
		
		//fleet.getFleetData().setFlagship(fleet.getFleetData().getMembersListCopy().get(0));
		
		fleet.getFleetData().sort();
		
		float minLevel = doctrine.getOfficerLevelBase() + 
						 doctrine.getOfficerLevelPerPoint() * params.getTotalPts();
		minLevel *= market.getStats().getDynamic().getValue(Stats.OFFICER_LEVEL_MULT);
		minLevel += params.officerLevelBonus;
		minLevel -= minLevel * doctrine.getOfficerLevelVariance() * 0.5f;
		minLevel = (int) minLevel;
		if (minLevel < 1) minLevel = 1;
		
		float maxLevel = minLevel + minLevel * doctrine.getOfficerLevelVariance();
		maxLevel = (int) maxLevel;
		if (maxLevel < minLevel) maxLevel = minLevel;
		if (maxLevel > params.levelLimit) maxLevel = params.levelLimit;
		if (minLevel > params.levelLimit) minLevel = params.levelLimit;
		
		float count = (doctrine.getOfficersPerPoint() * params.getTotalPts()) * params.officerNumMult;
		count *= market.getStats().getDynamic().getValue(Stats.OFFICER_NUM_MULT);
		if (params.officerNumMult > 1 && count < 1) count = 1;
		if (count > 0 && count < 1) count = 1;
		int max = (int) Global.getSettings().getFloat("officerAIMax");
		//int max = (int) fleet.getCommander().getStats().getOfficerNumber().getModifiedValue();
		if (count > max) count = max;
		
		if (params.maxShipSize < 4) {
			pruneToShipSize(fleet, random, market, qf, params.maxShipSize);
		}
		prune(fleet, (int) (params.getTotalPts() * 6), random);
		
		List<FleetMemberAPI> members = fleet.getFleetData().getMembersListCopy();
		boolean hasShip = false;
		for (FleetMemberAPI member : members) {
			if (!member.isFighterWing()) {
				hasShip = true;
				break;
			}
		}
		if (!hasShip) {
			addRandomShips(1f, qf, fleet, random, market, ShipRoles.COMBAT_SMALL);
		}
		
		if (params.withOfficers) {
			addCommanderAndOfficers((int) count, minLevel, maxLevel, fleet,  params.commander, random);
		}
		
		
		fleet.forceSync();
		
		//FleetFactoryV2.doctrine = null;
		
		if (fleet.getFleetData().getNumMembers() <= 0 || 
				fleet.getFleetData().getNumMembers() == fleet.getNumFighters()) {
			return null;
		}
		
		for (FleetMemberAPI member : members) {
			member.getRepairTracker().setCR(member.getRepairTracker().getMaxCR());
		}
		
		return fleet;
		
		} finally {
			Global.getSettings().profilerEnd();
		}
	}
	
	public static void prune(CampaignFleetAPI fleet, int maxFP, Random random) {
		List<FleetMemberAPI> members = fleet.getFleetData().getMembersListCopy();
		WeightedRandomPicker<FleetMemberAPI> picker = new WeightedRandomPicker<FleetMemberAPI>(random);
		for (FleetMemberAPI member : members) {
			picker.add(member, 1f);
		}
		int fails = 0;
		while (fleet.getFleetPoints() > maxFP && fleet.getFleetData().getNumMembers() > 1) {
			int diff = fleet.getFleetPoints() - maxFP;
			FleetMemberAPI member = picker.pickAndRemove();
			if (member != null && member.getFleetPointCost() < diff * 2f) {
				fleet.getFleetData().removeFleetMember(member);
			} else {
				fails++;
			}
			if (fails >= 5) break;
		}
	}
	
	/**
	 * Only works on combat ships. Bit of a hack for automated defender fleets.
	 * @param fleet
	 * @param qf 
	 * @param maxShipSize
	 */
	public static void pruneToShipSize(CampaignFleetAPI fleet, 
									   Random random, 
									   MarketAPI market, float qf, int maxShipSize) {
		
		String role = "";
		float ptsPerReplacementPick = 1;
		if (maxShipSize == 3) {
			role = ShipRoles.COMBAT_LARGE;
			ptsPerReplacementPick = 4;
		} else if (maxShipSize == 2) {
			role = ShipRoles.COMBAT_MEDIUM;
			ptsPerReplacementPick = 2;
		} else if (maxShipSize == 1) {
			role = ShipRoles.COMBAT_SMALL;
			ptsPerReplacementPick = 1;
		}
		
		for (FleetMemberAPI member : fleet.getFleetData().getMembersListCopy()) {
			int size = member.getHullSpec().getHullSize().ordinal() - 1;
			if (size <= maxShipSize) continue;

			fleet.getFleetData().removeFleetMember(member);
			
			float pts = getPointsForVariant(member.getVariant().getHullVariantId());
			int numIter = (int) (pts / ptsPerReplacementPick);
			
			for (int i = 0; i < numIter; i++) {
				List<ShipRolePick> picks = market.pickShipsForRole(role, fleet.getFaction().getId(), qf, random, null);
				if (picks.isEmpty()) {
					continue;
				}
				for (ShipRolePick pick : picks) {
					addToFleet(pick, fleet);
				}
			}
		}
	}
	
	
	public static void addCommanderAndOfficers(int total, float minLevel, float maxLevel, CampaignFleetAPI fleet, PersonAPI commanderPerson, Random random) {
		OfficerLevelupPlugin plugin = (OfficerLevelupPlugin) Global.getSettings().getPlugin("officerLevelUp");
		int max = plugin.getMaxLevel(null);
		
		List<FleetMemberAPI> members = fleet.getFleetData().getMembersListCopy();
		
//		int level = (int) Math.min(max, Math.round(minLevel + random.nextFloat() * (maxLevel - minLevel)));
//		PersonAPI person = OfficerManagerEvent.createOfficer(fleet.getFaction(), level);
//		person.setRankId(Ranks.SPACE_COMMANDER);
//		person.setPostId(Ranks.POST_FLEET_COMMANDER);
//		fleet.setCommander(person);
		//fleet.getFleetData().setFlagship(members.get(0));
		
		
		WeightedRandomPicker<FleetMemberAPI> picker = new WeightedRandomPicker<FleetMemberAPI>(random);
		WeightedRandomPicker<FleetMemberAPI> flagshipPicker = new WeightedRandomPicker<FleetMemberAPI>(random);
		
		int maxSize = 0;
		for (FleetMemberAPI member : members) {
			if (member.isFighterWing()) continue;
			if (member.isFlagship()) continue;
			if (!member.getCaptain().isDefault()) continue;
			int size = member.getHullSpec().getHullSize().ordinal();
			if (size > maxSize) {
				maxSize = size;
			}
		}
		
		for (FleetMemberAPI member : members) {
			//if (member.isCivilian()) continue;
			if (member.isFighterWing()) continue;
			if (member.isFlagship()) continue;
			if (!member.getCaptain().isDefault()) continue;
			
			float q = member.getVariant().getQuality();
			if (member.isCivilian()) q *= 0.0001f;
			float weight = (float) member.getFleetPointCost() * 0.5f + (float) member.getFleetPointCost() * q;
			picker.add(member, weight);
			
			int size = member.getHullSpec().getHullSize().ordinal();
			if (size >= maxSize) {
				flagshipPicker.add(member, weight);
			}
		}
		
		boolean commander = true;
		for (int i = 0; i < total + 1; i++) {
			FleetMemberAPI member = null;
			
			if (commander) {
				member = flagshipPicker.pickAndRemove();
			}
			if (member == null) {
				member = picker.pickAndRemove();
			} else {
				picker.remove(member);
			}
			
			if (member == null) {
				break; // out of ships that need officers
			}
			
			int level = (int) Math.min(max, Math.round(minLevel + random.nextFloat() * (maxLevel - minLevel)));
			if (Misc.isEasy()) {
				 level = (int) Math.ceil((float) level * Global.getSettings().getFloat("easyOfficerLevelMult"));
			}
			
			if (level <= 0) continue;
			
			float weight = getMemberWeight(member);
			float fighters = member.getVariant().getFittedWings().size();
			boolean wantCarrierSkills = weight > 0 && fighters / weight >= 0.5f;
			SkillPickPreference pref = SkillPickPreference.NON_CARRIER;
			if (wantCarrierSkills) pref = SkillPickPreference.CARRIER;
			
			PersonAPI person = OfficerManagerEvent.createOfficer(fleet.getFaction(), level, true, pref, random);
			if (person.getPersonalityAPI().getId().equals(Personalities.TIMID)) {
				person.setPersonality(Personalities.CAUTIOUS);
			}
			
			if (commander) {
				if (commanderPerson != null) {
					person = commanderPerson;
				} else {
					addCommanderSkills(person, fleet, random);
				}
				person.setRankId(Ranks.SPACE_COMMANDER);
				person.setPostId(Ranks.POST_FLEET_COMMANDER);
				fleet.setCommander(person);
				fleet.getFleetData().setFlagship(member);
				commander = false;
				
				total = (int) Math.min(total, person.getStats().getOfficerNumber().getModifiedValue());
				
			} else {
				member.setCaptain(person);
			}
		}
	}
	
	public static void addCommanderSkills(PersonAPI commander, CampaignFleetAPI fleet, Random random) {
		if (random == null) random = new Random();
		
		FleetCompositionDoctrineAPI doctrine = fleet.getFaction().getCompositionDoctrine();

		float total = 0f;
		float fighters = 0f;
		for (FleetMemberAPI member : fleet.getFleetData().getMembersListCopy()) {
			total += getMemberWeight(member);
			fighters += member.getVariant().getFittedWings().size();
		}
		boolean allowCarrierSkills = total > 0 && fighters / total >= 0.33f;
		
		float numSkills = doctrine.getCommanderSkillsPerLevel() * commander.getStats().getLevel();
		float skillChance = doctrine.getCommanderSkillChance();
		float skillLevel = doctrine.getCommanderSkillLevelPerLevel() * commander.getStats().getLevel();
		if (skillLevel < 1) skillLevel = 1;
		if (skillLevel > 3) skillLevel = 3;
		skillLevel = (int) skillLevel;
		
		WeightedRandomPicker<String> skills = new WeightedRandomPicker<String>(random);
		for (String skillId : doctrine.getCommanderSkills().keySet()) {
			SkillSpecAPI spec = Global.getSettings().getSkillSpec(skillId);
			if (!allowCarrierSkills && spec.hasTag(Tags.SKILL_CARRIER)) continue;
			skills.add(skillId, doctrine.getCommanderSkills().get(skillId));
		}
		
		
		MutableCharacterStatsAPI stats = commander.getStats();
		stats.setSkipRefresh(true);

		boolean debug = true;
		debug = false;
		
		if (debug) System.out.println("Generating commander skills, person level " + stats.getLevel() + ", allowCarriers: " + allowCarrierSkills);
		//skillLevel = 3f;
		if (debug) System.out.println("Num skills: " + numSkills);
		while (numSkills > 0 && !skills.isEmpty()) {
			float currChance = Math.min(1f, numSkills) * skillChance;
			if (random.nextFloat() < currChance) {
				String skillId = skills.pickAndRemove();
				if (debug) System.out.println("Added commander skill: " + skillId + ", level " + skillLevel);
				stats.setSkillLevel(skillId, skillLevel);
			} else {
				if (debug) System.out.println("Skipped adding commander skill");
			}
			numSkills--;
		}
		
		if (debug) System.out.println("Done\n");
	
		stats.setSkipRefresh(false);
		stats.refreshCharacterStatsEffects();
	}
	
	
	public static float getMemberWeight(FleetMemberAPI member) {
		boolean nonCombat = member.getVariant().isCivilian();
		float weight = 0;
		switch (member.getVariant().getHullSize()) {
		case CAPITAL_SHIP: weight += 8; break;
		case CRUISER: weight += 4; break;
		case DESTROYER: weight += 2; break;
		case FRIGATE: weight += 1; break;
		case FIGHTER: weight += 1; break;
		}
		if (nonCombat) weight *= 0.1f;
		return weight;
	}

	public static float add8PointGroup(float qf, 
			CampaignFleetAPI fleet, 
			Random random, 
			MarketAPI market,
			boolean capitalOk,
			float allowedOverflow,
			FleetParams params) {
		
		FleetCompositionDoctrineAPI doctrine = fleet.getFaction().getCompositionDoctrine();
		
		float r = random.nextFloat();
		
		if (r < doctrine.getSmallCarrierProbability()) {
			float cost = addToFleet(ShipRoles.CARRIER_SMALL, market, qf, random, fleet);
			return cost + addRandomCombatShips(8f - cost, qf, fleet, random, market, capitalOk, allowedOverflow, params);
		} else {
			return addRandomCombatShips(8f, qf, fleet, random, market, capitalOk, allowedOverflow, params);
		}
	}
	
	public static float add12PointGroup(float qf, 
			CampaignFleetAPI fleet, 
			Random random, 
			MarketAPI market,
			boolean capitalOk,
			float allowedOverflow,
			FleetParams params) {
		
		FleetCompositionDoctrineAPI doctrine = fleet.getFaction().getCompositionDoctrine();
		
		float r = random.nextFloat();
		
		if (r < doctrine.getMediumCarrierProbability()) {
			WeightedRandomPicker<Integer> carrierSize = new WeightedRandomPicker<Integer>(random);
			carrierSize.add(new Integer(1), doctrine.getSmallCarrierProbability() * .33f);
			carrierSize.add(new Integer(2), doctrine.getMediumCarrierProbability());
			Integer size = carrierSize.pick();
			
			float cost = 0;
			if (size >= 2) {
				cost += addToFleet(ShipRoles.CARRIER_MEDIUM, market, qf, random, fleet);
			} else {
				float added = 0;
				int attempts = 0;
				while (added < 4 && attempts < 4) {
					added += addToFleet(ShipRoles.CARRIER_SMALL, market, qf, random, fleet);
					attempts++;
				}
				cost += added;
			}
			//return cost + addRandomFighters(12f - cost, qf, fleet, random, market, params);
			return cost + addRandomCombatShips(12f - cost, qf, fleet, random, market, capitalOk, allowedOverflow, params);
		} else {
			return addRandomCombatShips(12f, qf, fleet, random, market, capitalOk, allowedOverflow, params);
		}
	}
	
	public static float add16PointGroup(float qf, 
			CampaignFleetAPI fleet, 
			Random random, 
			MarketAPI market,
			boolean capitalOk,
			boolean largeCarrierOk,
			float allowedOverflow,
			FleetParams params) {
		
		FleetCompositionDoctrineAPI doctrine = fleet.getFaction().getCompositionDoctrine();
		
		float r = random.nextFloat();
		boolean carrier = r < doctrine.getLargeCarrierProbability();
		WeightedRandomPicker<Integer> carrierSize = new WeightedRandomPicker<Integer>(random);
		if (doctrine.getSmallCarrierProbability() > 0) {
			carrierSize.add(new Integer(1), doctrine.getSmallCarrierProbability() * .17f);
		}
		if (doctrine.getMediumCarrierProbability() > 0) {
			carrierSize.add(new Integer(2), doctrine.getMediumCarrierProbability() * .33f);
		}
		if (largeCarrierOk && doctrine.getLargeCarrierProbability() > 0) {
			carrierSize.add(new Integer(3), doctrine.getLargeCarrierProbability());
		}
		
		if (carrier && !carrierSize.isEmpty()) {
			Integer size = carrierSize.pick();
			float cost = 0f;
			if (size >= 3 && largeCarrierOk) {
				cost += addToFleet(ShipRoles.CARRIER_LARGE, market, qf, random, fleet);
			} else {
				if (size >= 2) {
					float added = 0;
					int attempts = 0;
					while (added < 8 && attempts < 4) {
						added += addToFleet(ShipRoles.CARRIER_MEDIUM, market, qf, random, fleet);
						attempts++;
					}
					cost += added;
				} else {
					float added = 0;
					int attempts = 0;
					added += addToFleet(ShipRoles.CARRIER_MEDIUM, market, qf, random, fleet);
					while (added < 8 && attempts < 4) {
						added += addToFleet(ShipRoles.CARRIER_SMALL, market, qf, random, fleet);
						attempts++;
					}
					cost += added;
				}
			}
			//return cost + addRandomFighters(16f - cost, qf, fleet, random, market, params);
			return cost + addRandomCombatShips(16f - cost, qf, fleet, random, market, capitalOk, allowedOverflow, params);
		} else {
			return addRandomCombatShips(16f, qf, fleet, random, market, capitalOk, allowedOverflow, params);
		}
	}
	
	
	public static float addToFleet(String role, MarketAPI market, float qf, Random random, CampaignFleetAPI fleet) {
		float total = 0f;
		List<ShipRolePick> picks = market.pickShipsForRole(role, fleet.getFaction().getId(), qf, random, null);
		for (ShipRolePick pick : picks) {
			total += addToFleet(pick, fleet);
		}
		return total;
	}
	
	public static float addRandomCombatShips(float pts, float qf, 
											CampaignFleetAPI fleet, 
											Random random, 
											MarketAPI market,
											boolean capitalOk,
											float allowedOverflow,
											FleetParams params) {
		
		FleetCompositionDoctrineAPI doctrine = fleet.getFaction().getCompositionDoctrine();
		
		float picked = 0;
		int numEmpty = 0;
		while (picked < pts) {
			WeightedRandomPicker<String> roles = new WeightedRandomPicker<String>(random);
			roles.add(ShipRoles.COMBAT_SMALL, doctrine.getSmall());
			roles.add(ShipRoles.FAST_ATTACK, doctrine.getFast());
			
			if (pts - picked + allowedOverflow >= 4) {
				roles.add(ShipRoles.COMBAT_MEDIUM, doctrine.getMedium());
				roles.add(ShipRoles.ESCORT_SMALL, doctrine.getSmall() * doctrine.getEscortSmallFraction());
			}
			
			if (pts - picked + allowedOverflow >= 7) {
				roles.add(ShipRoles.COMBAT_LARGE, doctrine.getLarge());
				roles.add(ShipRoles.ESCORT_MEDIUM, doctrine.getMedium() * doctrine.getEscortMediumFraction());
			}
			
			if (pts - picked + allowedOverflow >= 10 && capitalOk) {
				roles.add(ShipRoles.COMBAT_CAPITAL, doctrine.getCapital());
			}
		
			List<ShipRolePick> picks = market.pickShipsForRole(roles.pick(), fleet.getFaction().getId(), qf, random, null);
			if (picks.isEmpty()) {
				numEmpty++;
				if (numEmpty > 5) break;
				continue;
			}
			numEmpty = 0;
			
			for (ShipRolePick pick : picks) {
				picked += addToFleet(pick, fleet);
			}
		}
		return picked;
	}
	
	
//	public static float addRandomFighters(float pts, float qf, 
//							CampaignFleetAPI fleet, 
//							Random random, 
//							MarketAPI market,
//							FleetParams params) {
//
//		FleetCompositionDoctrineAPI doctrine = fleet.getFaction().getCompositionDoctrine();
//		
//		float picked = 0;
//		int numEmpty = 0;
//		while (picked < pts) {
//			WeightedRandomPicker<String> roles = new WeightedRandomPicker<String>(random);
//			roles.add(ShipRoles.INTERCEPTOR, doctrine.getInterceptors());
//			roles.add(ShipRoles.FIGHTER, doctrine.getFighters());
//			roles.add(ShipRoles.BOMBER, doctrine.getBombers());
//			
//			List<ShipRolePick> picks = market.pickShipsForRole(roles.pick(), fleet.getFaction().getId(), qf, random, null);
//			if (picks.isEmpty()) {
//				numEmpty++;
//				if (numEmpty > 5) break;
//				continue;
//			}
//			numEmpty = 0;
//
//			for (ShipRolePick pick : picks) {
//				picked += addToFleet(pick, fleet);
//			}
//		}
//		return picked;
//	}
	
	public static float addRandomCombatFreighters(float pts, float qf, 
			CampaignFleetAPI fleet, 
			Random random, 
			MarketAPI market) {

		FleetCompositionDoctrineAPI doctrine = fleet.getFaction().getCompositionDoctrine();
		
		float picked = 0;
		int numEmpty = 0;
		while (picked < pts) {
			WeightedRandomPicker<String> roles = new WeightedRandomPicker<String>(random);
			roles.add(ShipRoles.COMBAT_FREIGHTER_SMALL, doctrine.getSmall());
			if (pts - picked >= 2) {
				roles.add(ShipRoles.COMBAT_FREIGHTER_MEDIUM, doctrine.getMedium());
			}
			if (pts - picked >= 4) {
				roles.add(ShipRoles.COMBAT_FREIGHTER_LARGE, doctrine.getLarge());
			}

			List<ShipRolePick> picks = market.pickShipsForRole(roles.pick(), fleet.getFaction().getId(), qf, random, null);
			if (picks.isEmpty()) {
				numEmpty++;
				if (numEmpty > 5) break;
				continue;
			}
			numEmpty = 0;

			for (ShipRolePick pick : picks) {
				picked += addToFleet(pick, fleet);
			}
		}
		return picked;
	}
	
	public static float addRandomShips(float pts, float qf, 
			CampaignFleetAPI fleet, 
			Random random, 
			MarketAPI market,
			String smallRole, String mediumRole, String largeRole) {
		if (random == null) random = new Random();
		FleetCompositionDoctrineAPI doctrine = fleet.getFaction().getCompositionDoctrine();
		
		if (pts <= 0) return 0f;
		
		float picked = 0;
		int numEmpty = 0;
		while (picked < pts) {
			WeightedRandomPicker<String> roles = new WeightedRandomPicker<String>(random);
			if (smallRole != null) {
				roles.add(smallRole, doctrine.getSmall());
			}

			if (pts - picked >= 2 && mediumRole != null) {
				roles.add(mediumRole, doctrine.getMedium());
			}

			if (pts - picked >= 6 && largeRole != null) {
				roles.add(largeRole, doctrine.getLarge());
			}

			List<ShipRolePick> picks = market.pickShipsForRole(roles.pick(), fleet.getFaction().getId(), qf, random, null);
			if (picks.isEmpty()) {
				numEmpty++;
				if (numEmpty > 5) break;
				continue;
			}
			numEmpty = 0;

			for (ShipRolePick pick : picks) {
				picked += addToFleet(pick, fleet);
			}
		}
		return picked;
	}
	
	public static float addRandomShips(float pts, float qf, 
			CampaignFleetAPI fleet, 
			Random random, 
			MarketAPI market,
			String role) {

		if (pts <= 0) return 0f;
		
		float picked = 0;
		int numEmpty = 0;
		while (picked < pts) {

			List<ShipRolePick> picks = market.pickShipsForRole(role, fleet.getFaction().getId(), qf, random, null);
			if (picks.isEmpty()) {
				numEmpty++;
				if (numEmpty > 5) break;
				continue;
			}
			numEmpty = 0;

			for (ShipRolePick pick : picks) {
				picked += addToFleet(pick, fleet);
			}
		}
		return picked;
	}
	
	
	protected static float addToFleet(ShipRolePick pick, CampaignFleetAPI fleet) {
		FleetMemberType type = FleetMemberType.SHIP;
		if (pick.isFighterWing()) {
			type = FleetMemberType.FIGHTER_WING;
		}
		FleetMemberAPI member = Global.getFactory().createFleetMember(type, pick.variantId);
		//if (member.getHullSpec().getHullSize().ordinal() + 1 >= params.) 
		fleet.getFleetData().addFleetMember(member);
		return getPointsForVariant(pick.variantId);
	}
	
	public static float getPointsForVariant(String variantId) {
		if (variantId.endsWith("_wing")) return 1;
		
		HullSize size = Global.getSettings().getVariant(variantId).getHullSize();
		switch (size) {
		case CAPITAL_SHIP: return 8;
		case CRUISER: return 4;
		case DESTROYER: return 2;
		case FIGHTER:
		case FRIGATE:
			return 1;
		
		}
		return 1;
	}
	
	
	
	
	
	public static MarketAPI pickMarket(FleetParams params) {
		if (params.market != null) return params.market;
		
		if (params.hyperspaceLocation == null) return null;
		
		List<MarketAPI> allMarkets = Global.getSector().getEconomy().getMarketsCopy();
		
		int size = getMinPreferredMarketSize(params);
		float distToClosest = Float.MAX_VALUE;
		MarketAPI closest = null;
		float distToClosestMatchingSize = Float.MAX_VALUE;
		MarketAPI closestMatchingSize = null;
		
		
		for (MarketAPI market : allMarkets) {
			if (market.getPrimaryEntity() == null) continue;
			
			boolean independent = Factions.INDEPENDENT.equals(params.factionId);
			if (independent) {
				boolean hostileToIndependent = market.getFaction().isHostileTo(Factions.INDEPENDENT);
				if (hostileToIndependent) continue;
			} else {
				if (!market.getFactionId().equals(params.factionId)) continue;
			}
			
			float currDist = Misc.getDistance(market.getPrimaryEntity().getLocationInHyperspace(),
											  params.hyperspaceLocation);
			if (currDist < distToClosest) {
				distToClosest = currDist;
				closest = market;
			}
			
			if (market.getSize() >= size && currDist < distToClosestMatchingSize) {
				distToClosestMatchingSize = currDist;
				closestMatchingSize = market;
			}
		}
		
		if (closestMatchingSize != null) {
			return closestMatchingSize;
		}
		
		if (closest != null) {
			return closest;
		}
		
//		MarketAPI temp = Global.getFactory().createMarket("temp", "Temp", size);
//		temp.setFactionId(params.factionId);
//		return temp;
		return null;
	}
	
	public static int getMinPreferredMarketSize(FleetParams params) {
		float fp = params.getTotalPts();
		
		if (fp <= 20) return 1;
		if (fp <= 50) return 3;
		if (fp <= 100) return 5;
		if (fp <= 150) return 7;
		
		return 8;
	}
	
	
	
	
	private static List<String> startingAbilities = null;
	public static CampaignFleetAPI createEmptyFleet(String factionId, String fleetType, MarketAPI market) {
		FactionAPI faction = Global.getSector().getFaction(factionId);
		String fleetName = faction.getFleetTypeName(fleetType); 
		CampaignFleetAPI fleet = Global.getFactory().createEmptyFleet(factionId, fleetName, true);
		fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_FLEET_TYPE, fleetType);
		
		if (market != null && !market.getId().equals("fake")) {
			fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_SOURCE_MARKET, market.getId());
		}
		
		if (startingAbilities == null) {
			startingAbilities = new ArrayList<String>();
			for (String id : Global.getSettings().getSortedAbilityIds()) {
				AbilitySpecAPI spec = Global.getSettings().getAbilitySpec(id);
				if (spec.isAIDefault()) {
					startingAbilities.add(id);
				}
			}
		}
		
		for (String id : startingAbilities) {
			fleet.addAbility(id);
		}
		
		return fleet;
	}
	
}
