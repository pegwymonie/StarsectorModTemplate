package com.fs.starfarer.api.impl.campaign.econ;

import com.fs.starfarer.api.impl.campaign.ids.Commodities;

public class VolatilesDepot extends BaseMarketConditionPlugin {

	public void apply(String id) {
		market.getDemand(Commodities.VOLATILES).getDemand().modifyFlat(id, ConditionData.VOLATILES_DEPOT_STOCKPILE);
		market.getDemand(Commodities.VOLATILES).getNonConsumingDemand().modifyFlat(id, ConditionData.VOLATILES_DEPOT_STOCKPILE);
	}

	public void unapply(String id) {
		market.getDemand(Commodities.VOLATILES).getDemand().unmodify(id);
		market.getDemand(Commodities.VOLATILES).getNonConsumingDemand().unmodify(id);
	}

}
