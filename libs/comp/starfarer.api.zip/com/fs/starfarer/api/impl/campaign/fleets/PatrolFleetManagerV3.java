package com.fs.starfarer.api.impl.campaign.fleets;

import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.MarketAPI;

public class PatrolFleetManagerV3 extends SourceBasedFleetManager {

	protected MarketAPI market;
	
	public PatrolFleetManagerV3(SectorEntityToken source, MarketAPI market) {
		super(source, 3f, 0, 0, 10f);
		this.market = market;
	}

	@Override
	protected CampaignFleetAPI spawnFleet() {
		return null;
	}

}
