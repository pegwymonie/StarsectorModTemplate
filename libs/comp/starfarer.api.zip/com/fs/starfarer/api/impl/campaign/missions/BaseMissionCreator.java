package com.fs.starfarer.api.impl.campaign.missions;

import org.apache.log4j.Logger;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignMissionPlugin;
import com.fs.starfarer.api.campaign.MissionBoardAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;

public abstract class BaseMissionCreator implements EveryFrameScript {
	public static Logger log = Global.getLogger(BaseMissionCreator.class);
	
	private MissionBoardAPI board;
	private IntervalUtil tracker = new IntervalUtil(0.25f, .75f);
	
	public BaseMissionCreator() {
		board = Global.getSector().getMissionBoard();
	}
	
	
	public static class MissionCreationData {
		public CampaignMissionPlugin mission;
		public MarketAPI market;
		public MissionCreationData(CampaignMissionPlugin mission, MarketAPI market) {
			this.mission = mission;
			this.market = market;
		}
		
		
	}
	
	
	protected abstract Class<?> getMissionClass();
	protected abstract int getMaxConcurrent();
	protected abstract MissionCreationData createMission();
	
	public void advance(float amount) {
		float days = Global.getSector().getClock().convertToDays(amount);
		tracker.advance(days);
		if (tracker.intervalElapsed()) {
			Global.getSettings().profilerBegin(getClass().getSimpleName() + ".advance()");
			int maxConcurrent = getMaxConcurrent();
			int num = board.getNumMissions(getMissionClass());
			if (num < maxConcurrent) {
				for (int i = 0; i < 3; i++) {
					MissionCreationData data = createMission();
					if (data != null && data.mission != null && data.market != null) {
						CampaignMissionPlugin mission = data.mission;
						MarketAPI market = data.market;
						
						makeMissionAvailableNearby(market, mission);
						
//						float minRange = Global.getSettings().getFloat("missionPostingRangeMin");
//						float maxRange = Global.getSettings().getFloat("missionPostingRangeMax");
//						
//						float range = minRange + (maxRange - minRange) * (float) Math.random();
//						
//						if (market.getContainingLocation() == null || market.getContainingLocation().isHyperspace()) {
//							board.makeAvailableAt(mission, market);
//						} else {
//							for (MarketAPI curr : Misc.getMarketsInLocation(market.getContainingLocation())) {
//								if (!curr.getFaction().isHostileTo(market.getFaction())) {
//									board.makeAvailableAt(mission, curr);
//								}
//							}
//						}
//						
//						for (MarketAPI curr : Misc.getNearbyMarkets(market.getLocationInHyperspace(), range)) {
//							if (!curr.getFaction().isHostileTo(market.getFaction())) {
//								board.makeAvailableAt(mission, curr);
//							}
//						}
						
						break;
					}
				}
			}
			Global.getSettings().profilerEnd();
		}
	}
	
	
	public static void makeMissionAvailableNearby(MarketAPI market, CampaignMissionPlugin mission) {
		MissionBoardAPI board = Global.getSector().getMissionBoard();
		
		float range = Global.getSettings().getFloat("missionPostingRange");
		float hostileProbMult = Global.getSettings().getFloat("missionPostingHostileProbMult");
		float probInc = Global.getSettings().getFloat("missionPostingProbPerMarketSize");
		float probBonus = Global.getSettings().getFloat("missionPostingProbBonusSameFaction");
		
		
		board.makeAvailableAt(mission, market);
		
		for (MarketAPI curr : Misc.getNearbyMarkets(market.getLocationInHyperspace(), range)) {
			float prob = (float) curr.getSize() * probInc;
			
			if (curr.getFaction().isHostileTo(market.getFaction())) {
				prob *= hostileProbMult;
			} else if (curr.getFaction() == market.getFaction()) {
				prob += probBonus;
			}
			
			if (Math.random() < prob) {
				board.makeAvailableAt(mission, curr);
			}
		}
	}

	
	public boolean isDone() {
		return false;
	}

	public boolean runWhilePaused() {
		return false;
	}

}
