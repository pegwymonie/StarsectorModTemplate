package com.fs.starfarer.api.impl.campaign.econ;


public class Outpost extends BaseMarketConditionPlugin {

	public void apply(String id) {
//		switch (market.getSize()) {
//		case 1:
//			market.getDemand(Commodities.MARINES).getDemand().modifyFlat(id, ConditionData.OUTPOST_MARINES_SIZE_1);
//			//market.getDemand(Commodities.MARINES).getNonConsumingDemand().modifyFlat(id, ConditionData.OUTPOST_MARINES_SIZE_1 * ConditionData.CREW_MARINES_NON_CONSUMING_FRACTION);
//		case 2:
//			market.getDemand(Commodities.MARINES).getDemand().modifyFlat(id, ConditionData.OUTPOST_MARINES_SIZE_2);
//			//market.getDemand(Commodities.MARINES).getNonConsumingDemand().modifyFlat(id, ConditionData.OUTPOST_MARINES_SIZE_2 * ConditionData.CREW_MARINES_NON_CONSUMING_FRACTION);
//		case 3:
//			market.getDemand(Commodities.MARINES).getDemand().modifyFlat(id, ConditionData.OUTPOST_MARINES_SIZE_3);
//			//market.getDemand(Commodities.MARINES).getNonConsumingDemand().modifyFlat(id, ConditionData.OUTPOST_MARINES_SIZE_3 * ConditionData.CREW_MARINES_NON_CONSUMING_FRACTION);
//		default:
//			market.getDemand(Commodities.MARINES).getDemand().modifyFlat(id, ConditionData.OUTPOST_MARINES_MAX);
//			//market.getDemand(Commodities.MARINES).getNonConsumingDemand().modifyFlat(id, ConditionData.OUTPOST_MARINES_MAX * ConditionData.CREW_MARINES_NON_CONSUMING_FRACTION);
//		}
		
		
//		market.getDemand(Commodities.FUEL).getDemand().modifyFlat(id, ConditionData.OUTPOST_FUEL);
//		market.getDemand(Commodities.FUEL).getNonConsumingDemand().modifyFlat(id, ConditionData.OUTPOST_FUEL * 0.75f);
		
		market.getStability().modifyFlat(id, ConditionData.STABILITY_OUTPOST, "Outpost");
	}

	public void unapply(String id) {
		market.getStability().unmodify(id);
		
//		market.getDemand(Commodities.MARINES).getDemand().unmodify(id);
		
//		market.getDemand(Commodities.FUEL).getDemand().unmodify(id);
//		market.getDemand(Commodities.FUEL).getNonConsumingDemand().unmodify(id);
	}

}
