package com.fs.starfarer.api.impl.campaign.econ;

import com.fs.starfarer.api.campaign.econ.CommodityOnMarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;

public class LargeRefugeePopulation extends BaseMarketConditionPlugin {

	private static String [] tags = new String [] {
			Commodities.FOOD, 
//			"heavy_industry_out",
			Commodities.TAG_LIGHT_INDUSTRY_OUT,
//			"light_industry_in",
//			"refining_in", 
//			"heavy_industry_in"
	};
	public void apply(String id) {
		float pop = getPopulation(market);

		for (CommodityOnMarketAPI com : market.getCommoditiesWithTags(tags)) {
			if (market.isIllegal(com)) continue;
			com.getSupply().modifyMult(id, ConditionData.REFUGEE_POPULATION_PENALTY);
		}

		market.getCommodityData(Commodities.CREW).getSupply().modifyMult(id, ConditionData.REFUGEE_GREEN_CREW_MULT);
		market.getCommodityData(Commodities.CREW).getSupply().modifyFlat(id, ConditionData.REFUGEE_GREEN_CREW_MIN);
		
		market.getCommodityData(Commodities.ORGANS).getSupply().modifyFlat(id, pop * 0.00001f);
		
		market.getStability().modifyFlat(id, ConditionData.STABILITY_REFUGEE_POPULATION, "Refugee population");
	}

	public void unapply(String id) {
		for (CommodityOnMarketAPI com : market.getCommoditiesWithTags(tags)) {
			com.getSupply().unmodify(id);
		}
		
		market.getCommodityData(Commodities.CREW).getSupply().unmodify(id);
		market.getCommodityData(Commodities.ORGANS).getSupply().unmodify(id);
		
		market.getStability().unmodify(id);
	}

}
