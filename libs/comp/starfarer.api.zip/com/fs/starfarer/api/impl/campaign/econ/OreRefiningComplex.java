package com.fs.starfarer.api.impl.campaign.econ;

import com.fs.starfarer.api.impl.campaign.ids.Commodities;

public class OreRefiningComplex extends BaseMarketConditionPlugin {

	public void apply(String id) {
		
//		market.getDemand(Commodities.REGULAR_CREW).getDemand().modifyFlat(id, ConditionData.ORE_REFINING_CREW);
//		market.getDemand(Commodities.REGULAR_CREW).getNonConsumingDemand().modifyFlat(id, ConditionData.ORE_REFINING_CREW * ConditionData.CREW_MARINES_NON_CONSUMING_FRACTION);
//		float crewDemandMet = market.getDemand(Commodities.REGULAR_CREW).getClampedFractionMet();
		
		market.getDemand(Commodities.ORE).getDemand().modifyFlat(id, ConditionData.ORE_REFINING_ORE);
		market.getDemand(Commodities.RARE_ORE).getDemand().modifyFlat(id, ConditionData.ORE_REFINING_RARE_ORE);
		
		int size = market.getSize();
		if (size >= 4) {
			market.getDemand(Commodities.HEAVY_MACHINERY).getDemand().modifyFlat(id, ConditionData.ORE_REFINING_MACHINERY);
		}
		
		applyBaseDemandForSuppliesIfNeeded(id);
		
		//getProductionMult(market, Commodities.ORE);
		float oreDemandMet = market.getDemand(Commodities.ORE).getClampedFractionMet();
		float rareOreDemandMet = market.getDemand(Commodities.RARE_ORE).getClampedFractionMet();
		
		market.getCommodityData(Commodities.METALS).getSupply().modifyFlat(id, 
				ConditionData.ORE_REFINING_ORE * ConditionData.ORE_REFINING_METAL_PER_ORE * oreDemandMet);
		market.getCommodityData(Commodities.RARE_METALS).getSupply().modifyFlat(id, 
				ConditionData.ORE_REFINING_RARE_ORE * ConditionData.ORE_REFINING_METAL_PER_ORE * rareOreDemandMet);
	}

	public void unapply(String id) {
		market.getDemand(Commodities.ORE).getDemand().unmodify(id);
		market.getDemand(Commodities.RARE_ORE).getDemand().unmodify(id);
		
		int size = market.getSize();
		if (size >= 4) {
			market.getDemand(Commodities.HEAVY_MACHINERY).getDemand().unmodify(id);
		}
		
		unapplyBaseDemandForSupplies(id);
		
//		market.getDemand(Commodities.REGULAR_CREW).getDemand().unmodify(id);
//		market.getDemand(Commodities.REGULAR_CREW).getNonConsumingDemand().unmodify(id);
		
		market.getCommodityData(Commodities.METALS).getSupply().unmodify(id);
		market.getCommodityData(Commodities.RARE_METALS).getSupply().unmodify(id);
	}

}
