package com.fs.starfarer.api.impl.campaign.econ;

import com.fs.starfarer.api.impl.campaign.ids.Commodities;

public class CottageIndustry extends BaseMarketConditionPlugin {

	public void apply(String id) {
		
		float mult = getBaseSizeMult();
		
		market.getDemand(Commodities.ORGANICS).getDemand().modifyFlat(id, mult * ConditionData.COTTAGE_INDUSTRY_ORGANICS);
		
		float productionMult = getProductionMult(market, Commodities.ORGANICS);
		
		market.getCommodityData(Commodities.DOMESTIC_GOODS).getSupply().modifyFlat(id, mult * ConditionData.COTTAGE_INDUSTRY_DOMESTIC_GOODS * productionMult);
	}

	public void unapply(String id) {
		market.getDemand(Commodities.ORGANICS).getDemand().unmodify(id);
		
		market.getCommodityData(Commodities.DOMESTIC_GOODS).getSupply().unmodify(id);
	}

}
