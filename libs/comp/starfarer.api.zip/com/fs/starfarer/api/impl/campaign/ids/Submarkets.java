package com.fs.starfarer.api.impl.campaign.ids;

public class Submarkets {

	public static final String GENERIC_MILITARY = "generic_military";
	
	public static final String SUBMARKET_STORAGE = "storage";
	public static final String SUBMARKET_OPEN = "open_market";
	public static final String SUBMARKET_BLACK = "black_market";
}
