package com.fs.starfarer.api.impl.campaign.procgen.themes;

import java.util.List;
import java.util.Random;

import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.Script;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.FleetAssignment;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.fleets.RouteManager.RouteData;
import com.fs.starfarer.api.impl.campaign.fleets.RouteManager.RouteSegment;
import com.fs.starfarer.api.util.Misc;

public class RouteFleetAssignmentAI extends BaseAssignmentAI {

	protected RouteData route;


	public RouteFleetAssignmentAI(CampaignFleetAPI fleet, RouteData route) {
		super();
		this.fleet = fleet;
		this.route = route;
		giveInitialAssignments();
	}
	
	protected void giveInitialAssignments() {
		LocationAPI conLoc = route.getCurrentContainingLocation();
		if (fleet.getContainingLocation() != null) {
			fleet.getContainingLocation().removeEntity(fleet);
		}
		conLoc.addEntity(fleet);
		
//		Vector2f loc = route.getInterpolatedLocation();
//		fleet.setLocation(loc.x, loc.y);
		fleet.setFacing((float) Math.random() * 360f);
		
		pickNext(true);
	}
	
	@Override
	public void advance(float amount) {
		if (route.isExpired()) {
			Misc.giveStandardReturnToSourceAssignments(fleet);
			return;
		}
		super.advance(amount);
	}

	protected String getTravelActionText(RouteSegment segment) {
		return "travelling";
	}
	
	protected String getInSystemActionText(RouteSegment segment) {
		return "patrolling";
	}
	
	protected String getStartingActionText(RouteSegment segment) {
		return "orbiting " + route.getMarket().getName();
	}
	
	protected String getEndingActionText(RouteSegment segment) {
		return "orbiting " + route.getMarket().getName();
	}
	
	protected void pickNext() {
		pickNext(false);
	}
	
	protected void pickNext(boolean justSpawned) {
		List<RouteSegment> segments = route.getSegments();
		int index = route.getSegments().indexOf(route.getCurrent());
//		RouteSegment current = segments.get(index);
		RouteSegment current = route.getCurrent();
		
		if (index == 0 && route.getMarket() != null && !current.isTravel()) {
			addStartingAssignment(current, justSpawned);
			return;
		}
		
		if (index == segments.size() - 1 && route.getMarket() != null && !current.isTravel()) {
			addEndingAssignment(current, justSpawned);
			return;
		}
		
		// transiting from current to next; they're not the same star system
		if (current.isTravel()) {
			addTravelAssignment(current, justSpawned);
			return;
		}
		
		// in a system or in a hyperspace location for some time
		if (!current.isTravel()) {
			addLocalAssignment(current, justSpawned);
		}
	}
	
	protected void addStartingAssignment(final RouteSegment current, boolean justSpawned) {
		if (justSpawned) {
			Vector2f loc = route.getMarket().getPrimaryEntity().getLocation();
			fleet.setLocation(loc.x, loc.y);
		}
		fleet.addAssignment(FleetAssignment.ORBIT_PASSIVE, route.getMarket().getPrimaryEntity(), 
						    current.daysMax - current.elapsed, getStartingActionText(current),
				new Script() {
					public void run() {
						route.goToAtLeastNext(current);
					}
				});
	}
	
	protected void addEndingAssignment(final RouteSegment current, boolean justSpawned) {
		if (justSpawned) {
			Vector2f loc = route.getMarket().getPrimaryEntity().getLocation();
			fleet.setLocation(loc.x, loc.y);
		}
		
		fleet.addAssignment(FleetAssignment.GO_TO_LOCATION, route.getMarket().getPrimaryEntity(), 1000f,
							"returning to " + route.getMarket().getName());
		fleet.addAssignment(FleetAssignment.ORBIT_PASSIVE, route.getMarket().getPrimaryEntity(), 
							current.daysMax - current.elapsed, getEndingActionText(current));
		fleet.addAssignment(FleetAssignment.GO_TO_LOCATION_AND_DESPAWN, route.getMarket().getPrimaryEntity(), 
				1000f, getEndingActionText(current),
				new Script() {
			public void run() {
				route.goToAtLeastNext(current);
			}
		});
	}
	
	protected void addLocalAssignment(RouteSegment current, boolean justSpawned) {
		if (justSpawned) {
			Vector2f loc = Misc.getPointAtRadius(new Vector2f(), 8000);
			fleet.setLocation(loc.x, loc.y);
		}
		
		SectorEntityToken target = null;
		if (current.systemFrom instanceof StarSystemAPI) {
			target = ((StarSystemAPI)current.systemFrom).getCenter();
		} else {
			target = Global.getSector().getHyperspace().createToken(current.from.x, current.from.y);
		}
		
		fleet.addAssignment(FleetAssignment.PATROL_SYSTEM, target, 
						    current.daysMax - current.elapsed, getInSystemActionText(current));
	}

	
	protected void addTravelAssignment(final RouteSegment current, boolean justSpawned) {
		if (justSpawned) {
			Vector2f loc = route.getInterpolatedLocation();
			Random random = new Random();
			if (route.getSeed() != null) {
				random = Misc.getRandom(route.getSeed(), 1);
			}
			loc = Misc.getPointWithinRadius(loc, 2000f, random);
			fleet.setLocation(loc.x, loc.y);
		}
		
		SectorEntityToken target = null;
		if (current.systemTo instanceof StarSystemAPI) {
			target = ((StarSystemAPI)current.systemTo).getCenter();
		} else {
			target = Global.getSector().getHyperspace().createToken(current.to.x, current.to.y);
		}
		
		fleet.addAssignment(FleetAssignment.GO_TO_LOCATION, target, 10000f, getTravelActionText(current), 
				new Script() {
					public void run() {
						route.goToAtLeastNext(current);
					}
				});
	}

	
	
}










