package com.fs.starfarer.api.impl.campaign.abilities;

import java.awt.Color;
import java.util.Random;

import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken.VisibilityLevel;
import com.fs.starfarer.api.characters.FullName;
import com.fs.starfarer.api.impl.campaign.fleets.PatrolFleetManager;
import com.fs.starfarer.api.impl.campaign.fleets.PirateFleetManager;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactory.PatrolType;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.FleetTypes;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.impl.campaign.ids.Pings;
import com.fs.starfarer.api.impl.campaign.procgen.themes.RuinsFleetRouteManager;
import com.fs.starfarer.api.impl.campaign.procgen.themes.SalvageSpecialAssigner;
import com.fs.starfarer.api.ui.LabelAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.DelayedActionScript;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.TimeoutTracker;
import com.fs.starfarer.api.util.WeightedRandomPicker;

public class DistressCallAbility extends BaseDurationAbility {

	public static final float NEARBY_USE_TIMEOUT_DAYS = 20f;
	public static final float NEARBY_USE_RADIUS_LY = 5f;
	
	public static final float DAYS_TO_TRACK_USAGE = 365f;
	
	public static enum DistressCallOutcome {
		NOTHING,
		HELP,
		PIRATES,
	}
	
	public static class AbilityUseData {
		public long timestamp;
		public Vector2f location;
		public AbilityUseData(long timestamp, Vector2f location) {
			this.timestamp = timestamp;
			this.location = location;
		}
		
	}
	
	protected boolean performed = false;
	protected int numTimesUsed = 0;
	protected long lastUsed = 0;
	
	protected TimeoutTracker<AbilityUseData> uses = new TimeoutTracker<AbilityUseData>();
	
	protected Object readResolve() {
		super.readResolve();
		if (uses == null) {
			uses = new TimeoutTracker<AbilityUseData>();
		}
		return this;
	}
	
	@Override
	protected void activateImpl() {
		if (entity.isInCurrentLocation()) {
			VisibilityLevel level = entity.getVisibilityLevelToPlayerFleet();
			if (level != VisibilityLevel.NONE) {
				Global.getSector().addPing(entity, Pings.DISTRESS_CALL);
			}
			
			performed = false;
		}
		
	}

	@Override
	protected void applyEffect(float amount, float level) {
		CampaignFleetAPI fleet = getFleet();
		if (fleet == null) return;
		
		if (!performed) {
			if (wasUsedNearby(NEARBY_USE_TIMEOUT_DAYS, fleet.getLocationInHyperspace(), NEARBY_USE_RADIUS_LY)) {
				performed = true;
				return;
			}
			
			WeightedRandomPicker<DistressCallOutcome> picker = new WeightedRandomPicker<DistressCallOutcome>();
			picker.add(DistressCallOutcome.HELP, 10f);
			if (numTimesUsed > 2) {
				float uses = getNumUsesInLastPeriod();
				float pirates = 10f + uses * 2f;
				picker.add(DistressCallOutcome.PIRATES, pirates);
				
				float nothing = 10f + uses * 2f;
				picker.add(DistressCallOutcome.NOTHING, nothing);
			}
			
			DistressCallOutcome outcome = picker.pick();
			//outcome = DistressCallOutcome.HELP;
			
			if (outcome != DistressCallOutcome.NOTHING) {
				float delay = 10f + 10f * (float) Math.random();
				if (numTimesUsed == 0) {
					delay = 1f + 2f * (float) Math.random();
				}
				//delay = 0f;
				addResponseScript(delay, outcome);
			}
			
			numTimesUsed++;
			lastUsed = Global.getSector().getClock().getTimestamp();
			performed = true;
			
			AbilityUseData data = new AbilityUseData(lastUsed, fleet.getLocationInHyperspace());
			uses.add(data, DAYS_TO_TRACK_USAGE);
		}
	}
	
	public boolean wasUsedNearby(float withinDays, Vector2f locInHyper, float withinRangeLY) {
		for (AbilityUseData data : uses.getItems()) {
			float daysSinceUse = Global.getSector().getClock().getElapsedDaysSince(data.timestamp);
			if (daysSinceUse <= withinDays) {
				float range = Misc.getDistanceLY(locInHyper, data.location);
				if (range <= withinRangeLY) return true;
			}
		}
		return false;
	}
	
	
	@Override
	public void advance(float amount) {
		super.advance(amount);

		float days = Global.getSector().getClock().convertToDays(amount);
		uses.advance(days);
	}

	public TimeoutTracker<AbilityUseData> getUses() {
		return uses;
	}
	
	public int getNumUsesInLastPeriod() {
		return uses.getItems().size();
	}

	protected void addResponseScript(float delayDays, DistressCallOutcome outcome) {
		final CampaignFleetAPI player = getFleet();
		if (player == null) return;
		if (!(player.getContainingLocation() instanceof StarSystemAPI)) return;
		
		final StarSystemAPI system = (StarSystemAPI) player.getContainingLocation();
		
		final JumpPointAPI inner = Misc.getDistressJumpPoint(system);
		if (inner == null) return;
		
		JumpPointAPI outerTemp = null;
		if (inner.getDestinations().size() >= 1) {
			SectorEntityToken test = inner.getDestinations().get(0).getDestination();
			if (test instanceof JumpPointAPI) {
				outerTemp = (JumpPointAPI) test;
			}
		}
		final JumpPointAPI outer = outerTemp;
		if (outer == null) return;
		
		
		if (outcome == DistressCallOutcome.HELP) {
			addHelpScript(delayDays, system, inner, outer);
		} else if (outcome == DistressCallOutcome.PIRATES) {
			addPiratesScript(delayDays, system, inner, outer);
		}
		
	}
	
	protected void addPiratesScript(float delayDays,
								 final StarSystemAPI system, 
								 final JumpPointAPI inner, 
								 final JumpPointAPI outer) {
		Global.getSector().addScript(new DelayedActionScript(delayDays) {
			@Override
			public void doAction() {
				CampaignFleetAPI player = Global.getSector().getPlayerFleet();
				if (player == null) return;
				
				int numPirates = new Random().nextInt(3) + 1;
				for (int i = 0; i < numPirates; i++) {
					int points = 5 + new Random().nextInt(20);
					
					CampaignFleetAPI fleet = PirateFleetManager.createPirateFleet(points, system.getLocation());
					if (fleet == null) continue;
					if (Misc.getSourceMarket(fleet) == null) continue;
					
					Global.getSector().getHyperspace().addEntity(fleet);
				
					if (!player.isInHyperspace() && 
							(Global.getSector().getHyperspace().getDaysSinceLastPlayerVisit() > 5 ||
									player.getCargo().getFuel() <= 0)) {
						
						Vector2f loc = outer.getLocation();
						fleet.setLocation(loc.x, loc.y + fleet.getRadius() + 100f);
					} else {
						float dir = (float) Math.random() * 360f;
						if (player.isInHyperspace()) {
							dir = Misc.getAngleInDegrees(player.getLocation(), system.getLocation());
							dir += (float) Math.random() * 120f - 60f;
						}
						Vector2f loc = Misc.getUnitVectorAtDegreeAngle(dir);
						loc.scale(3000f + 1000f * (float) Math.random());
						Vector2f.add(system.getLocation(), loc, loc);
						fleet.setLocation(loc.x, loc.y + fleet.getRadius() + 100f);
					}
				
					fleet.addScript(new DistressCallResponsePirateAssignmentAI(fleet, system, inner, outer));
				}
			}
		});
	}
	
	protected void addHelpScript(float delayDays,
									final StarSystemAPI system, 
									final JumpPointAPI inner, 
									final JumpPointAPI outer) {
		Global.getSector().addScript(new DelayedActionScript(delayDays) {
			@Override
			public void doAction() {
				CampaignFleetAPI player = Global.getSector().getPlayerFleet();
				if (player == null) return;

				WeightedRandomPicker<String> factions = SalvageSpecialAssigner.getNearbyFactions(
												null, system.getCenter(),
												10f, 10f, 0f);
				
				String faction = factions.pick();
				//faction = Factions.HEGEMONY;
				if (faction == null) return;
				
				CampaignFleetAPI fleet = null;
				if (Factions.INDEPENDENT.equals(faction)) {
					WeightedRandomPicker<String> typePicker = new WeightedRandomPicker<String>();
					typePicker.add(FleetTypes.SCAVENGER_SMALL, 5f);
					typePicker.add(FleetTypes.SCAVENGER_MEDIUM, 10f);
					typePicker.add(FleetTypes.SCAVENGER_LARGE, 5f);
					String type = typePicker.pick();
	
					fleet = RuinsFleetRouteManager.createScavenger(
							type, system.getLocation(),
							null, false, null);
				} else {
					WeightedRandomPicker<PatrolType> picker = new WeightedRandomPicker<PatrolType>();
					picker.add(PatrolType.FAST, 5f); 
					picker.add(PatrolType.COMBAT, 10f); 
					picker.add(PatrolType.HEAVY, 5f);
					PatrolType type = picker.pick();
					fleet = PatrolFleetManager.createPatrolFleet(type, null, faction, system.getLocation(), 0f);
				}
				if (fleet == null) return;

				if (Misc.getSourceMarket(fleet) == null) return;


				if (numTimesUsed == 1) {
					FullName name = new FullName("Mel", "Greenish", fleet.getCommander().getGender());
					fleet.getCommander().setName(name);
					fleet.getFlagship().setShipName("IS In All Circumstances");
				}

				Misc.setFlagWithReason(fleet.getMemoryWithoutUpdate(), MemFlags.ENTITY_MISSION_IMPORTANT,
						"distressResponse", true, 30f);
				fleet.getMemoryWithoutUpdate().set("$distressResponse", true);

				Global.getSector().getHyperspace().addEntity(fleet);

				if (!player.isInHyperspace() && 
						(Global.getSector().getHyperspace().getDaysSinceLastPlayerVisit() > 5 ||
								player.getCargo().getFuel() <= 0)) {

					Vector2f loc = outer.getLocation();
					fleet.setLocation(loc.x, loc.y + fleet.getRadius() + 100f);
				} else {
					float dir = (float) Math.random() * 360f;
					if (player.isInHyperspace()) {
						dir = Misc.getAngleInDegrees(player.getLocation(), system.getLocation());
						dir += (float) Math.random() * 120f - 60f;
					}
					Vector2f loc = Misc.getUnitVectorAtDegreeAngle(dir);
					loc.scale(3000f + 1000f * (float) Math.random());
					Vector2f.add(system.getLocation(), loc, loc);
					fleet.setLocation(loc.x, loc.y + fleet.getRadius() + 100f);
				}

				fleet.addScript(new DistressCallResponseAssignmentAI(fleet, system, inner, outer));
			}
		});
	}
	
	
	
	
	public boolean isUsable() {
		if (!super.isUsable()) return false;
		if (getFleet() == null) return false;
		
		CampaignFleetAPI fleet = getFleet();
		if (fleet.isInHyperspace() || fleet.isInHyperspaceTransition()) return false;
		
		return true;
	}
	

	@Override
	protected void deactivateImpl() {
		cleanupImpl();
	}
	
	@Override
	protected void cleanupImpl() {
		CampaignFleetAPI fleet = getFleet();
		if (fleet == null) return;
	}

	
	@Override
	public void createTooltip(TooltipMakerAPI tooltip, boolean expanded) {
		
		CampaignFleetAPI fleet = getFleet();
		if (fleet == null) return;
		
		Color gray = Misc.getGrayColor();
		Color highlight = Misc.getHighlightColor();
		Color bad = Misc.getNegativeHighlightColor();
		
		LabelAPI title = tooltip.addTitle(spec.getName());

		float pad = 10f;
		
		tooltip.addPara("May be used by a stranded fleet to punch a distress signal through to hyperspace, " +
						"signaling nearby fleets to bring aid in the form of fuel and supplies. " +
						"Help may take many days to arrive, if it arrives at all, and taking advantage " +
						"of it will result in a progressively higher reduction in standing with the responders.", pad);
		
		tooltip.addPara("By long-standing convention, the fleet in distress is expected to meet any responders at the " +
						"innermost jump-point inside a star system.", pad);
		
		tooltip.addPara("The signal is non-directional and carries no data, and is therefore not useful for " +
						"calling for help in a tactical situation.", pad);
		
		if (fleet.isInHyperspace()) {
			tooltip.addPara("Can not be used in hyperspace.", bad, pad);
		}
		
		addIncompatibleToTooltip(tooltip, expanded);
		
	}

	public boolean hasTooltip() {
		return true;
	}
	
}





