package com.fs.starfarer.api.impl.campaign.missions;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BaseOnMessageDeliveryScript;
import com.fs.starfarer.api.campaign.BattleAPI;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.comm.CommMessageAPI;
import com.fs.starfarer.api.campaign.comm.MessagePriority;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.events.CampaignEventManagerAPI;
import com.fs.starfarer.api.campaign.events.CampaignEventTarget;
import com.fs.starfarer.api.campaign.events.EventProbabilityAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.RepActionEnvelope;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.RepActions;
import com.fs.starfarer.api.impl.campaign.events.BaseEventPlugin;
import com.fs.starfarer.api.impl.campaign.events.FactionHostilityEvent.FactionHostilityPairKey;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Events;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import com.fs.starfarer.api.util.Misc.Token;

public class FactionCommissionMissionEvent extends BaseEventPlugin {
	public static final float DOES_NOT_KNOW_HOSTILITY_PROB_MULT = 0.5f;
	
	public static Logger log = Global.getLogger(FactionCommissionMissionEvent.class);
	
	private FactionCommissionMission mission = null;
	//private IntervalUtil monthly = new IntervalUtil(25f, 35f);
	
	public void init(String type, CampaignEventTarget eventTarget) {
		super.init(type, eventTarget, false);
	}
	
	protected Object readResolve() {
//		if (monthly == null) {
//			monthly = new IntervalUtil(25f, 35f);
//		}
		return this;
	}
	
	@Override
	public void setParam(Object param) {
		mission = (FactionCommissionMission) param;
		faction = mission.getFaction();
		getEventTarget().getEntity().setFaction(mission.getFaction().getId());
	}

	protected FactionAPI otherFaction = null;
	public void startEvent() {
		super.startEvent(true);
		
		log.info("Accepted commission with " + faction.getDisplayName());
		Global.getSector().reportEventStage(this, "accept", mission.getAcceptLocation(), MessagePriority.DELIVER_IMMEDIATELY, 
				new BaseOnMessageDeliveryScript() {
					public void beforeDelivery(CommMessageAPI message) {
						Global.getSector().adjustPlayerReputation(
								new RepActionEnvelope(RepActions.COMMISSION_ACCEPT, null, message, true), 
								faction.getId());
					}
				});
		Global.getSector().getCharacterData().getMemoryWithoutUpdate().set(MemFlags.FCM_FACTION, mission.getFactionId());
		Global.getSector().getCharacterData().getMemoryWithoutUpdate().set(MemFlags.FCM_EVENT, this);
		
		FactionAPI player = Global.getSector().getPlayerFaction();
		for (FactionAPI faction : Global.getSector().getAllFactions()) {
			otherFaction = faction;
			if (this.faction.isHostileTo(otherFaction) && !player.isHostileTo(otherFaction) && otherFaction.isShowInIntelTab()) {
				log.info("Making hostile with " + otherFaction.getDisplayName());
				Global.getSector().reportEventStage(this, "become_hostile", mission.getAcceptLocation(), MessagePriority.DELIVER_IMMEDIATELY,
						new BaseOnMessageDeliveryScript() {
							public void beforeDelivery(CommMessageAPI message) {
								Global.getSector().adjustPlayerReputation(
										new RepActionEnvelope(RepActions.MAKE_HOSTILE_AT_BEST, null, message, true), 
										otherFaction.getId());
							}
						});
			}
		}
		
	}
	
	private boolean ended = false;
	private void endEvent() {
		ended = true;
		
		Global.getSector().getCharacterData().getMemoryWithoutUpdate().unset(MemFlags.FCM_FACTION);
		Global.getSector().getCharacterData().getMemoryWithoutUpdate().unset(MemFlags.FCM_EVENT);
	}
	
	
	public void advance(float amount) {
		if (!isEventStarted()) return;
		if (isDone()) return;
		
		//System.out.println("Registered: " + Global.getSector().getAllListeners().contains(this));
		float days = Global.getSector().getClock().convertToDays(amount);
		RepLevel level = faction.getRelToPlayer().getLevel();
		if (!level.isAtWorst(RepLevel.NEUTRAL)) {
			endEvent();
			Global.getSector().reportEventStage(this, "annul", findMessageSender(),
					MessagePriority.ENSURE_DELIVERY,
					new BaseOnMessageDeliveryScript() {
				public void beforeDelivery(CommMessageAPI message) {
					
				}
			});
		}
	}
	
	protected SectorEntityToken findMessageSender() {
		WeightedRandomPicker<MarketAPI> military = new WeightedRandomPicker<MarketAPI>();
		WeightedRandomPicker<MarketAPI> nonMilitary = new WeightedRandomPicker<MarketAPI>();
		
		for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
			if (market.getFaction() != faction) continue;
			if (market.getPrimaryEntity() == null) continue;
			
			float dist = Misc.getDistanceToPlayerLY(market.getPrimaryEntity());
			float weight = Math.max(1f, 10f - dist);
			if (market.hasCondition(Conditions.HEADQUARTERS) ||
					market.hasCondition(Conditions.REGIONAL_CAPITAL) ||
					market.hasCondition(Conditions.MILITARY_BASE)) {
				military.add(market, weight);
			} else {
				nonMilitary.add(market, weight);
			}
		}
		
		MarketAPI pick = military.pick();
		if (pick == null) pick = nonMilitary.pick();
		
		if (pick != null) return pick.getPrimaryEntity();
		return Global.getSector().getPlayerFleet();
	}
	
	
	

	@Override
	public boolean callEvent(String ruleId, final InteractionDialogAPI dialog, List<Token> params, Map<String, MemoryAPI> memoryMap) {
		String action = params.get(0).getString(memoryMap);
		
		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		CargoAPI cargo = playerFleet.getCargo();
		
		if (action.equals("TODO")) {
			
		}
		
		return true;
	}
	
	private int lastBounty = 0;
	private String enemyDesc = "an unknown enemy";
	public Map<String, String> getTokenReplacements() {
		Map<String, String> map = super.getTokenReplacements();
		
		map.put("$sender", faction.getDisplayName());
		
		map.put("$bountyCredits", "" + Misc.getWithDGS(lastBounty));
		map.put("$enemyDesc", "" + enemyDesc);
		map.put("$baseBounty", "" + Misc.getWithDGS(mission.getBaseBounty()));
		
		addFactionNameTokens(map, "other", otherFaction);
		
		return map;
	}

	@Override
	public String[] getHighlights(String stageId) {
		List<String> result = new ArrayList<String>();
		
		if ("posting".equals(stageId)) {
			addTokensToList(result, "$baseBounty");
		} else if ("accept".equals(stageId)) {
			addTokensToList(result, "$baseBounty");
		} else if ("bounty_payment".equals(stageId)) {
			addTokensToList(result, "$bountyCredits");
		}
		
		return result.toArray(new String[0]);
	}
	
	@Override
	public Color[] getHighlightColors(String stageId) {
		return super.getHighlightColors(stageId);
	}

	public boolean isDone() {
		return ended;
	}

	public String getEventName() {
		//return mission.getName();
		if (isDone()) {
			return Misc.ucFirst(faction.getDisplayName()) + " Commission - annulled";
		}
		return Misc.ucFirst(faction.getDisplayName()) + " Commission";
	}

	@Override
	public CampaignEventCategory getEventCategory() {
		return CampaignEventCategory.MISSION;
	}

	@Override
	public String getEventIcon() {
		return faction.getCrest();
	}

	@Override
	public void reportBattleOccurred(CampaignFleetAPI primaryWinner, BattleAPI battle) {
		if (!isEventStarted()) return;
		if (!battle.isPlayerInvolved()) return;
		
//		CampaignEventManagerAPI eventManager = Global.getSector().getEventManager();
		boolean otherKnows = battle.knowsWhoPlayerIs(battle.getNonPlayerSide());
		lastBounty = 0;
		float fpDestroyed = 0;
		
		for (CampaignFleetAPI otherFleet : battle.getNonPlayerSideSnapshot()) {
			if (faction == otherFleet.getFaction()) continue;
			
			float bounty = 0;
			if (!faction.isHostileTo(otherFleet.getFaction())) {
				if (otherFleet.getFaction().getCustomBoolean(Factions.CUSTOM_ENGAGES_IN_HOSTILITIES)) {
					float nonHostileFpDestroyed = 0;
					for (FleetMemberAPI loss : Misc.getSnapshotMembersLost(otherFleet)) {
						float fp = loss.getFleetPointCost();
						if (!otherKnows) fp *= DOES_NOT_KNOW_HOSTILITY_PROB_MULT;
						nonHostileFpDestroyed += fp;
					}
					if (nonHostileFpDestroyed <= 0) continue;
					
					otherFaction = otherFleet.getFaction();
					log.info("Rep drop for fighting against " + otherFaction.getDisplayName());
					final float repFP = (int)(nonHostileFpDestroyed * battle.getPlayerInvolvementFraction());
					Global.getSector().reportEventStage(this, "rep_drop_hostile", findMessageSender(), MessagePriority.ENSURE_DELIVERY,
						new BaseOnMessageDeliveryScript() {
							private final FactionAPI nonHostileFaction = FactionCommissionMissionEvent.this.otherFaction;
							public void beforeDelivery(CommMessageAPI message) {
								Global.getSector().adjustPlayerReputation(
										new RepActionEnvelope(RepActions.COMMISSION_PENALTY_HOSTILE_TO_NON_ENEMY, 
															  new Float(repFP), message, true), 
										FactionCommissionMissionEvent.this.faction.getId());


								// increase faction hostility probability
								CampaignEventManagerAPI eventManager = Global.getSector().getEventManager();
								FactionHostilityPairKey key = new FactionHostilityPairKey(
																FactionCommissionMissionEvent.this.faction,
																nonHostileFaction);
								EventProbabilityAPI ep = eventManager.getProbability(Events.FACTION_HOSTILITY, key);
								float increase = Math.min(0.1f, repFP * 0.1f * 0.01f);
								if (increase > 0) {
									ep.increaseProbability(increase);
									log.info(String.format("Increasing faction hostility probability %s -> %s, by %s, is now %s",
														FactionCommissionMissionEvent.this.faction.getDisplayName(),
														nonHostileFaction.getDisplayName(), "" + increase,
														"" + ep.getProbability()));
								}
							}
						});
				}
				continue;
			}
			
			for (FleetMemberAPI loss : Misc.getSnapshotMembersLost(otherFleet)) {
				float mult = Misc.getSizeNum(loss.getHullSpec().getHullSize());
				bounty += mult * mission.getBaseBounty();
				fpDestroyed += loss.getFleetPointCost();
			}
			
			lastBounty += (int) (bounty * battle.getPlayerInvolvementFraction());
		}
		
		
		CampaignFleetAPI primaryEnemy = battle.getPrimary(battle.getNonPlayerSide());
		boolean withAllies = battle.getNonPlayerSideSnapshot().size() > 1;
		if (primaryEnemy != null) {
			enemyDesc = primaryEnemy.getNameWithFaction();
			if (withAllies) enemyDesc += " and their allies";
		} else {
			enemyDesc = "an unknown enemy";
		}
	
		if (lastBounty > 0) {
			final int payment = lastBounty;
			final float repFP = (int)(fpDestroyed * battle.getPlayerInvolvementFraction());
			
			log.info(String.format("Paying commission bounty of %d from [%s]", (int) lastBounty, faction.getDisplayName()));
			Global.getSector().reportEventStage(this, "bounty_payment", findMessageSender(),
										MessagePriority.ENSURE_DELIVERY,
						new BaseOnMessageDeliveryScript() {
				public void beforeDelivery(CommMessageAPI message) {
					CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
					playerFleet.getCargo().getCredits().add(payment);
					
					if (repFP > 0) {
						Global.getSector().adjustPlayerReputation(
								new RepActionEnvelope(RepActions.COMMISSION_BOUNTY_REWARD, new Float(repFP), message, true), 
								faction.getId());
					}
				}
			});
		}
	}
	
}



