package com.fs.starfarer.api.impl.campaign.missions;

import java.util.ArrayList;

import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.MissionBoardAPI;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.MissionBoardAPI.MissionAvailabilityAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.MissionCompletionRep;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.RepRewards;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;

public class AnalyzeEntityMissionCreator extends BaseMissionCreator {
	
	protected transient WeightedRandomPicker<SectorEntityToken> entityPicker = new WeightedRandomPicker<SectorEntityToken>();
	
	protected Object readResolve() {
		return this;
	}
	
	@Override
	public void advance(float amount) {
		super.advance(amount);
	}


	protected void initPicker() {
		entityPicker = new WeightedRandomPicker<SectorEntityToken>();
		for (StarSystemAPI system : Global.getSector().getStarSystems()) {
			if (system.hasTag(Tags.THEME_DERELICT_PROBES) || 
					system.hasTag(Tags.THEME_RUINS) ||
					system.hasTag(Tags.THEME_REMNANT_DESTROYED)) {
				
				float w = 1f;
				if (system.hasTag(Tags.THEME_DERELICT_PROBES)) {
					w = 3f;
					if (Global.getSector().isInNewGameAdvance()) {
						w = 5f;
					}
				}
				for (SectorEntityToken entity : system.getEntitiesWithTag(Tags.SALVAGEABLE)) {
					// skip derelict ships etc that will expire
					if (entity.hasTag(Tags.EXPIRES)) continue;
					if (entity.getCircularOrbitRadius() > 10000f) continue;
					entityPicker.add(entity, w);
				}
				
			}
		}
	}
	
	protected void prunePicker() {
		for (SectorEntityToken item : new ArrayList<SectorEntityToken>(entityPicker.getItems())) {
			if (!item.isAlive()) {
				entityPicker.remove(item);
			}
		}
		
		MissionBoardAPI board = Global.getSector().getMissionBoard();
		for (MissionAvailabilityAPI mission : board.getMissionsCopy()) {
			if (!(mission.getMission() instanceof AnalyzeEntityMission)) continue;
			
			AnalyzeEntityMission aem = (AnalyzeEntityMission) mission.getMission(); 
			entityPicker.remove(aem.getEntity());
		}
	}
	

	@Override
	protected MissionCreationData createMission() {
		
		initPicker();
		prunePicker();
		
		SectorEntityToken target = entityPicker.pick();
		if (target == null) return null;
		
		WeightedRandomPicker<MarketAPI> marketPicker = new WeightedRandomPicker<MarketAPI>();
		for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
			marketPicker.add(market, market.getSize());
		}
		MarketAPI market = marketPicker.pick();
		if (market == null) return null;
		
		String faction = market.getFactionId();
		if (!market.getFaction().isHostileTo(Factions.INDEPENDENT) && (float) Math.random() > 0.67f) {
			faction = Factions.INDEPENDENT;
		}
		
		MissionCompletionRep rep = new MissionCompletionRep(RepRewards.HIGH, RepLevel.WELCOMING,
														   -RepRewards.TINY, RepLevel.INHOSPITABLE);
		
		int days = 120;
		//int reward = (int) Misc.getDistance(market.getLocationInHyperspace(), target.getLocationInHyperspace());
		//reward *= 1.5f;
		
		int reward = (int) Misc.getDistance(new Vector2f(), target.getLocationInHyperspace());
		//reward *= 0.75f;
		
		reward = (reward / 10000) * 10000;
		if (reward < 10000) reward = 10000;

		
		//AnalyzeEntityMission mission = new AnalyzeEntityMission("jangala", faction, target, reward, days, rep);
		AnalyzeEntityMission mission = new AnalyzeEntityMission(market.getId(), faction, target, reward, days, rep);
		
		MissionCreationData data = new MissionCreationData(mission, mission.getMarket());
		
		return data;
	}

	@Override
	protected int getMaxConcurrent() {
		return (int) Global.getSettings().getFloat("maxAnalyzeEntityConcurrent");
	}

	@Override
	protected Class<?> getMissionClass() {
		return AnalyzeEntityMission.class;
	}

	
}



