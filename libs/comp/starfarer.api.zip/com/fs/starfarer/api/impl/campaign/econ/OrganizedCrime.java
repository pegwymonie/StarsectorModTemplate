package com.fs.starfarer.api.impl.campaign.econ;

import com.fs.starfarer.api.impl.campaign.ids.Commodities;

public class OrganizedCrime extends BaseMarketConditionPlugin {

	public void apply(String id) {
		
		float mult = getBaseSizeMult();
		
		float stabilityMult = getLowStabilityBonusMult(market) * getHighStabilityPenaltyMult(market);
		mult *= stabilityMult;
		
		market.getDemand(Commodities.VOLATILES).getDemand().modifyFlat(id, mult * ConditionData.ORGANIZED_CRIME_VOLATILES);
		market.getDemand(Commodities.ORGANICS).getDemand().modifyFlat(id, mult * ConditionData.ORGANIZED_CRIME_ORGANICS);
		
		float productionMult = getProductionMult(market, Commodities.VOLATILES, Commodities.ORGANICS);
		market.getCommodityData(Commodities.DRUGS).getSupply().modifyFlat(id, mult * ConditionData.ORGANIZED_CRIME_DRUGS * productionMult);
		
		
		market.getCommodityData(Commodities.ORGANS).getSupply().modifyFlat(id, Math.max(10f, mult * ConditionData.ORGANIZED_CRIME_ORGANS));
		
		market.getDemand(Commodities.HAND_WEAPONS).getDemand().modifyFlat(id, Math.max(10f, mult * ConditionData.ORGANIZED_CRIME_WEAPONS));
		
		market.getDemand(Commodities.MARINES).getDemand().modifyFlat(id, ConditionData.ORGANIZED_CRIME_MARINES); 
		//market.getDemand(Commodities.MARINES).getNonConsumingDemand().modifyFlat(id, ConditionData.ORGANIZED_CRIME_MARINES * ConditionData.CREW_MARINES_NON_CONSUMING_FRACTION);
		
		market.getStability().modifyFlat(id, ConditionData.STABILITY_ORGANIZED_CRIME, "Organized crime");
	}

	public void unapply(String id) {
		market.getDemand(Commodities.VOLATILES).getDemand().unmodify(id);
		market.getDemand(Commodities.ORGANICS).getDemand().unmodify(id);
		
		market.getCommodityData(Commodities.DRUGS).getSupply().unmodify(id);
		market.getCommodityData(Commodities.ORGANS).getSupply().unmodify(id);
		market.getDemand(Commodities.HAND_WEAPONS).getDemand().unmodify(id);
		market.getDemand(Commodities.MARINES).getDemand().unmodify(id);
		//market.getDemand(Commodities.MARINES).getNonConsumingDemand().unmodify(id);
		
		market.getStability().unmodify(id);
	}

}
