package com.fs.starfarer.api.impl.campaign.fleets;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BaseCampaignEventListener;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.util.IntervalUtil;

public abstract class BaseLimitedFleetManager extends BaseCampaignEventListener implements EveryFrameScript {

	public static Logger log = Global.getLogger(BaseLimitedFleetManager.class);
	
	public static class ManagedFleetData {
		public float startingFleetPoints = 0;
		public CampaignFleetAPI fleet;
		public ManagedFleetData(CampaignFleetAPI fleet) {
			this.fleet = fleet;
		}
	}
	
	protected List<ManagedFleetData> active = new ArrayList<ManagedFleetData>();
	protected IntervalUtil tracker;

	public BaseLimitedFleetManager() {
		super(true);
		float interval = 0.5f;
		tracker = new IntervalUtil(interval * 0.75f, interval * 1.25f);
		readResolve();
	}
	
	protected Object readResolve() {
		return this;
	}
	
	protected abstract int getMaxFleets();
	protected abstract CampaignFleetAPI spawnFleet();
	
	public void advance(float amount) {
		float days = Global.getSector().getClock().convertToDays(amount);
		
		tracker.advance(days * 10f);
		if (!tracker.intervalElapsed()) return;
		
		Global.getSettings().profilerBegin(this.getClass().getSimpleName() + ".advance()");
		List<ManagedFleetData> remove = new ArrayList<ManagedFleetData>();
		for (ManagedFleetData data : active) {
			if (data.fleet.getContainingLocation() == null ||
				!data.fleet.getContainingLocation().getFleets().contains(data.fleet)) {
				remove.add(data);
				log.info("Cleaning up orphaned fleet [" + data.fleet.getNameWithFaction() + "]");
			}
		}
		active.removeAll(remove);
		
		int max = getMaxFleets();
		
		if (active.size() < max) {
			log.info(active.size() + " out of a maximum " + max + " fleets in play for [" + getClass().getName() + "]");
			CampaignFleetAPI fleet = spawnFleet();
			if (fleet != null) {
				ManagedFleetData data = new ManagedFleetData(fleet);
				active.add(data);
				log.info("Spawned fleet [" + fleet.getNameWithFaction() + "] at hyperloc " + fleet.getLocationInHyperspace());
			} else {
				log.info("Could not spawn fleet - returned null");
			}
		} else {
			log.debug("Maximum number of " + max + " fleets already in play for [" + getClass().getName() + "]");
		}
		Global.getSettings().profilerEnd();
	}
	
	public boolean isDone() {
		return false;
	}

	public boolean runWhilePaused() {
		return false;
	}
	
	@Override
	public void reportFleetDespawned(CampaignFleetAPI fleet, FleetDespawnReason reason, Object param) {
		super.reportFleetDespawned(fleet, reason, param);
		
		for (ManagedFleetData data : active) {
			if (data.fleet == fleet) {
				active.remove(data);
				break;
			}
		}
	}

}














