package com.fs.starfarer.api.impl.campaign.ids;

public class Difficulties {
	
	public static final String EASY = "easy";
	public static final String NORMAL = "normal";
}
