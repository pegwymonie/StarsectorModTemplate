package com.fs.starfarer.api.impl.campaign.econ;

import com.fs.starfarer.api.campaign.econ.CommodityOnMarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;

public class UrbanizedPolity extends BaseMarketConditionPlugin {

	public void apply(String id) {
		for (CommodityOnMarketAPI com : market.getCommoditiesWithTag(Commodities.FOOD)) {
			com.getSupply().modifyMult(id, ConditionData.URBANIZED_POLITY_FOOD_PENALTY);
		}

		market.getDemand(Commodities.DOMESTIC_GOODS).getDemand().modifyMult(id, ConditionData.URBANIZED_POLITY_DEMAND_MULT);
		market.getDemand(Commodities.LUXURY_GOODS).getDemand().modifyMult(id, ConditionData.URBANIZED_POLITY_DEMAND_MULT + 1f);
		market.getDemand(Commodities.ORGANS).getDemand().modifyMult(id, ConditionData.URBANIZED_POLITY_DEMAND_MULT);
		market.getDemand(Commodities.DRUGS).getDemand().modifyMult(id, ConditionData.URBANIZED_POLITY_DEMAND_MULT);
	}

	public void unapply(String id) {
		for (CommodityOnMarketAPI com : market.getCommoditiesWithTag(Commodities.FOOD)) {
			com.getSupply().unmodify(id);
		}
		market.getDemand(Commodities.DOMESTIC_GOODS).getDemand().unmodify(id);
		market.getDemand(Commodities.LUXURY_GOODS).getDemand().unmodify(id);
		market.getDemand(Commodities.ORGANS).getDemand().unmodify(id);
		market.getDemand(Commodities.DRUGS).getDemand().unmodify(id);
	}

}
