package com.fs.starfarer.api.impl.campaign.ids;

/**
 * Variable names for stuff stored in memory that:
 * 1) Generally is used more than once in code, so it's convenient to track from here.
 * 
 * These may or may not be used in rules.csv.
 * 
 * 
 * @author Alex Mosolov
 *
 * Copyright 2014 Fractal Softworks, LLC
 */
public class MemFlags {

	public static final String SALVAGE_SPECIAL_DATA = "$salvageSpecialData";
	public static final String SALVAGE_SEED = "$salvageSeed";
	public static final String SALVAGE_DEBRIS_FIELD = "$salvageDebrisField";
//	public static final String SALVAGE_DEFENDER_FACTION = "$salvageDefFaction";
//	public static final String SALVAGE_DEFENDER_PROB = "$salvageDefProb";
	//public static final String SALVAGE_SPEC_ID = "$salvageSpecId";
	public static final String SALVAGE_DEFENDER_OVERRIDE = "$salvageDOv";
	
	public static final String ENTITY_MISSION_IMPORTANT = "$missionImportant";
	
	//public static final String BATTLE_CREATION_CONTEXT_SCRIPT = "$bcc_script";
	//public static final String FLEET_INTERACTION_DIALOG_CONFIG_OVERRIDE = "$fidConifg";
	public static final String FLEET_INTERACTION_DIALOG_CONFIG_OVERRIDE_GEN = "$fidConifgGen";
	
	public static final String FCM_FACTION = "$fcm_faction";
	public static final String FCM_EVENT = "$fcm_eventRef";
	
	
	public static final String FLEET_BUSY = "$core_fleetBusy";
	
	public static final String MEMORY_KEY_PATROL_ALLOW_TOFF = "$patrolAllowTOff";
	public static final String COMM_RELAY_NON_FUNCTIONAL = "$commRelayNonFunctional";
	public static final String MEMORY_KEY_NO_SHIP_RECOVERY = "$noShipRecovery";
	
	public static final String MEMORY_KEY_SOURCE_MARKET = "$sourceMarket";
	public static final String MEMORY_KEY_PATROL_FLEET = "$isPatrol";
	public static final String MEMORY_KEY_CUSTOMS_INSPECTOR = "$isCustomsInspector";
	public static final String MEMORY_KEY_TRADE_FLEET = "$isTradeFleet";
	public static final String MEMORY_KEY_SCAVENGER = "$isScavenger";
	public static final String MEMORY_KEY_SMUGGLER = "$isSmuggler";
	public static final String MEMORY_KEY_PIRATE = "$isPirate";
	public static final String MEMORY_KEY_FLEET_TYPE = "$fleetType";
	
	public static final String MEMORY_KEY_SKIP_TRANSPONDER_STATUS_INFO = "$skipTInfo";
	
	
	
	public static final String MEMORY_KEY_MAKE_HOSTILE = "$cfai_makeHostile";
	public static final String MEMORY_KEY_MAKE_HOSTILE_WHILE_TOFF = "$cfai_makeHostileWhileTOff";
	public static final String MEMORY_KEY_MAKE_NON_HOSTILE = "$cfai_makeNonHostile";
	public static final String MEMORY_KEY_MAKE_PREVENT_DISENGAGE = "$cfai_makePreventDisengage";
	public static final String MEMORY_KEY_MAKE_ALLOW_DISENGAGE = "$cfai_makeAllowDisengage";
	public static final String MEMORY_KEY_MAKE_AGGRESSIVE = "$cfai_makeAggressive";
	public static final String MEMORY_KEY_MAKE_NON_AGGRESSIVE = "$cfai_makeNonAggressive";
	public static final String MEMORY_KEY_RECENTLY_DEFEATED_BY_PLAYER = "$cfai_recentlyDefeatedByPlayer";
	public static final String MEMORY_KEY_NO_JUMP = "$cfai_noJump";
	
	public static final String MEMORY_KEY_IGNORE_PLAYER_COMMS = "$ignorePlayerCommRequests";
	
	public static final String MEMORY_KEY_SAW_PLAYER_WITH_TRANSPONDER_OFF = "$sawPlayerTransponderOff";
	public static final String MEMORY_KEY_SAW_PLAYER_WITH_TRANSPONDER_ON = "$sawPlayerTransponderOn";
	
	
	public static final String MEMORY_KEY_PURSUE_PLAYER = "$pursuePlayer";
	public static final String MEMORY_KEY_STICK_WITH_PLAYER_IF_ALREADY_TARGET = "$keepPursuingPlayer";
	public static final String MEMORY_MARKET_SMUGGLING_SUSPICION_LEVEL = "$smugglingSuspicion";
	public static final String MEMORY_KEY_PLAYER_HOSTILE_ACTIVITY_NEAR_MARKET = "$playerHostileTimeout";
	
	public static final String MEMORY_KEY_LOW_REP_IMPACT = "$lowRepImpact";
	
	public static final String MEMORY_KEY_MISSION_IMPORTANT = "$missionImportant";
	
	
	public static final String MEMORY_KEY_NUM_GR_INVESTIGATIONS = "$numGRInvestigations";
	public static final String MEMORY_KEY_REQUIRES_DISCRETION = "$requiresDiscretionToDeal";
	
	
}










