package com.fs.starfarer.api.impl.campaign.ids;

public class Personalities {
	public static final String TIMID = "timid";
	public static final String CAUTIOUS = "cautious";
	public static final String STEADY = "steady";
	public static final String AGGRESSIVE = "aggressive";
	public static final String RECKLESS = "reckless";
}
