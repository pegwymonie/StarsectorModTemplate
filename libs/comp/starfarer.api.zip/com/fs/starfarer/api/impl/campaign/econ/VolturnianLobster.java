package com.fs.starfarer.api.impl.campaign.econ;

import com.fs.starfarer.api.impl.campaign.ids.Commodities;

public class VolturnianLobster extends BaseMarketConditionPlugin {

	public void apply(String id) {
		market.getCommodityData(Commodities.LOBSTER).getSupply().modifyFlat(id, ConditionData.VOLTURNIAN_LOBSTER_PENS_LOBSTER);
		//market.getCommodityData(Commodities.LUXURY_GOODS).getSupply().modifyFlat(id, ConditionData.VOLTURNIAN_LOBSTER_PENS_LOBSTER);
	}

	public void unapply(String id) {
		market.getCommodityData(Commodities.LOBSTER).getSupply().unmodify(id);
		//market.getCommodityData(Commodities.LUXURY_GOODS).getSupply().unmodify(id);
	}

}
