package com.fs.starfarer.api.impl.campaign.econ;

import com.fs.starfarer.api.impl.campaign.ids.Commodities;

public class OreMiningComplex extends BaseMarketConditionPlugin {

	public void apply(String id) {
//		market.getDemand(Commodities.REGULAR_CREW).getDemand().modifyFlat(id, ConditionData.ORE_MINING_CREW);
//		market.getDemand(Commodities.REGULAR_CREW).getNonConsumingDemand().modifyFlat(id, ConditionData.ORE_MINING_CREW * ConditionData.CREW_MARINES_NON_CONSUMING_FRACTION);
//		float crewDemandMet = market.getDemand(Commodities.REGULAR_CREW).getClampedFractionMet();
		
		float mult = getBaseSizeMult();

		int size = market.getSize();
		if (size >= 4) {
			market.getDemand(Commodities.HEAVY_MACHINERY).getDemand().modifyFlat(id, mult * ConditionData.ORE_MINING_MACHINERY);
		}
		
		applyBaseDemandForSuppliesIfNeeded(id);
		
		market.getCommodityData(Commodities.ORE).getSupply().modifyFlat(id, mult * ConditionData.ORE_MINING_ORE);
		market.getCommodityData(Commodities.RARE_ORE).getSupply().modifyFlat(id, mult * ConditionData.ORE_MINING_RARE_ORE);
	}

	public void unapply(String id) {
		int size = market.getSize();
		if (size >= 4) {
			market.getDemand(Commodities.HEAVY_MACHINERY).getDemand().unmodify(id);
		}
		
		unapplyBaseDemandForSupplies(id);
		
		market.getCommodityData(Commodities.ORE).getSupply().unmodify(id);
		market.getCommodityData(Commodities.RARE_ORE).getSupply().unmodify(id);
		
//		market.getDemand(Commodities.REGULAR_CREW).getDemand().unmodify(id);
//		market.getDemand(Commodities.REGULAR_CREW).getNonConsumingDemand().unmodify(id);
	}

}
