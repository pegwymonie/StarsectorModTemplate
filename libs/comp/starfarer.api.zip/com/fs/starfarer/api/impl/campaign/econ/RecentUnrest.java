package com.fs.starfarer.api.impl.campaign.econ;

import java.util.Map;

import com.fs.starfarer.api.impl.campaign.events.RecentUnrestEvent;

public class RecentUnrest extends BaseMarketConditionPlugin {
	
	private RecentUnrestEvent event = null;
	
	public RecentUnrest() {
	}

	public void apply(String id) {
		market.getStability().modifyFlat(id, -1 * event.getStabilityPenalty(), "Recent unrest");
	}

	public void unapply(String id) {
		market.getStability().unmodify(id);
	}
	
	@Override
	public void setParam(Object param) {
		event = (RecentUnrestEvent) param;
	}
	
	public Map<String, String> getTokenReplacements() {
		Map<String, String> tokens = super.getTokenReplacements();
		
		int penalty = event.getStabilityPenalty();
		tokens.put("$stabilityPenalty", "" + penalty);
		
		return tokens;
	}

	@Override
	public String[] getHighlights() {
		return new String[] {"" + event.getStabilityPenalty() };
	}

	@Override
	public boolean isTransient() {
		return false;
	}
}
