package com.fs.starfarer.api.impl.campaign.events;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BaseOnMessageDeliveryScript;
import com.fs.starfarer.api.campaign.BattleAPI;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.comm.CommMessageAPI;
import com.fs.starfarer.api.campaign.comm.MessagePriority;
import com.fs.starfarer.api.campaign.events.CampaignEventTarget;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.RepActionEnvelope;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.RepActions;
import com.fs.starfarer.api.impl.campaign.econ.BaseMarketConditionPlugin;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Strings;
import com.fs.starfarer.api.util.Misc;

public class SystemBountyEvent extends BaseEventPlugin {

	public static Logger log = Global.getLogger(SystemBountyEvent.class);
	
	private float elapsedDays = 0f;
	private float duration = 45f;
	
	private float baseBounty = 0;
	private int lastBounty = 0;
	private String conditionToken;
	private MessagePriority messagePriority;
	public void init(String type, CampaignEventTarget eventTarget) {
		super.init(type, eventTarget, false);
		//messagePriority = getDefaultPriority();
		messagePriority = MessagePriority.SECTOR;
	}

	
	public void startEvent() {
		super.startEvent(true);
		
		if (Global.getSector().isInNewGameAdvance() && market.getId().equals("jangala")) {
			endEvent(true);
			return;
		}
		
		baseBounty = Global.getSettings().getFloat("baseSystemBounty");
		float marketSize = market.getSize();
		
		baseBounty *= (marketSize + 5f) / 10f;
		
		//float lowStabilityMult = BaseMarketConditionPlugin.getLowStabilityPenaltyMult(market);
		float highStabilityMult = BaseMarketConditionPlugin.getHighStabilityBonusMult(market);
		highStabilityMult = 1f + (highStabilityMult - 1f) * 0.5f;
		
		//baseBounty *= lowStabilityMult;
		baseBounty *= highStabilityMult;
		
		baseBounty = (int) baseBounty;
		
		log.info(String.format("Starting bounty at market [%s], %d credits per frigate", market.getName(), (int) baseBounty));
		
		updateLikelyCauseFaction();
		if (enemyFaction == null) {
			Global.getSector().reportEventStage(this, "start", messagePriority);
		} else {
			Global.getSector().reportEventStage(this, "start_with_faction", messagePriority);
		}
		
		conditionToken = market.addCondition(Conditions.EVENT_SYSTEM_BOUNTY, true, this);
	}
	
	private String enemyFaction = null;
	private void updateLikelyCauseFaction() {
		List<CampaignFleetAPI> fleets = Misc.getFleetsInOrNearSystem(market.getStarSystem());
		final Map<String, Integer> strength = new HashMap<String, Integer>();
		for (CampaignFleetAPI fleet : fleets) {
			if (!fleet.getFaction().isHostileTo(market.getFaction())) continue;
			int str = fleet.getFleetPoints();
			String factionId = fleet.getFaction().getId();
			Integer curr = strength.get(factionId);
			if (curr == null) curr = new Integer(0);
			curr += str;
			strength.put(factionId, curr);
		}
		
		List<String> factions = new ArrayList<String>(strength.keySet());
		Collections.sort(factions, new Comparator<String>() {
			public int compare(String o1, String o2) {
				int s1 = strength.get(o1);
				int s2 = strength.get(o2);
				return s2 - s1;
			}
		});
		
		if (factions.isEmpty()) {
			enemyFaction = null;
		} else {
			String id = factions.get(0);
			FactionAPI faction = Global.getSector().getFaction(id);
			enemyFaction = faction.getEntityNamePrefix();
			if (faction.isPlayerFaction()) {
				enemyFaction = enemyFaction.toLowerCase();
			}
			if (enemyFaction.isEmpty()) {
				enemyFaction = null;
			}
		}
	}
	
	private int stage = 0;
	public void advance(float amount) {
		if (!isEventStarted()) return;
		if (isDone()) return;
		
		float days = Global.getSector().getClock().convertToDays(amount);
		elapsedDays += days;

		if (elapsedDays >= duration && !isDone()) {
			endEvent(true);
		}
	}
	
	private boolean ended = false;
	private void endEvent(boolean withReport) {
		log.info(String.format("Ending bounty at market [%s]", market.getName()));
		if (withReport) {
			Global.getSector().reportEventStage(this, "end", messagePriority);
		}
		
		market.removeSpecificCondition(conditionToken);
		ended = true;
	}
	

	public boolean isDone() {
		return ended;
	}

	

	public Map<String, String> getTokenReplacements() {
		Map<String, String> map = super.getTokenReplacements();
		// this is ok because the token replacement happens right as the message is sent, not when it's received
		// so the lastBounty is the correct value for the message
//		map.put("$bountyCredits", "" + lastBounty);
//		map.put("$baseBounty", "" + (int) baseBounty);
		map.put("$bountyCredits", "" + Misc.getWithDGS(lastBounty));
		map.put("$baseBounty", "" + Misc.getWithDGS(baseBounty));
		//map.put("$sender", map.get("$marketFaction") + " administration on " + market.getName());
		map.put("$sender", map.get("$marketFaction"));
		
		map.put("$daysLeft", "" + (int) + Math.max(1, duration - elapsedDays));
		
		if (enemyFaction != null) {
			map.put("$enemyFaction", enemyFaction);
		}
		
		return map;
	}

	@Override
	public String[] getHighlights(String stageId) {
		List<String> result = new ArrayList<String>();
		if (stageId != null && (stageId.equals("bounty_payment") || stageId.equals("bounty_payment_share"))) {
			addTokensToList(result, "$bountyCredits");
		}
		if (stageId != null && stageId.equals("start_with_faction") && enemyFaction != null) {
			addTokensToList(result, "$daysLeft");
			addTokensToList(result, "$enemyFaction");
			addTokensToList(result, "$baseBounty");
		}
		
		if (stageId != null && stageId.equals("start")) {
			addTokensToList(result, "$daysLeft");
			addTokensToList(result, "$baseBounty");
		}
		
		if (stageId != null && stageId.equals("condition")) {
			addTokensToList(result, "$baseBounty");
			addTokensToList(result, "$daysLeft");
		}
		
		if (stageId != null && (
				stageId.equals("bounty_payment") ||
				stageId.equals("bounty_payment_share") ||
				stageId.equals("bounty_no_payment") ||
				stageId.equals("bounty_no_rep"))
				) {
			addTokensToList(result, "$daysLeft");
		}
		return result.toArray(new String[0]);
	}

	@Override
	public String getEventName() {
		//String text = market.getName();
		String locName = market.getContainingLocation().getName();
		if (market.getContainingLocation() instanceof StarSystemAPI) {
			locName = ((StarSystemAPI)market.getContainingLocation()).getBaseName();
		}
		String factionName = market.getFaction().getDisplayName();
		String marketName = market.getName();
		//String text = marketName + " (" + locName + " system, " + factionName + ")";
		//String text = locName + " star system, " + factionName + "";
		String text = locName + ", " + factionName + "";
		if (isDone()) {
			return text + " - over";
		}
		int daysLeft = (int) (duration - elapsedDays);
		String days = "";
		if (daysLeft > 0) {
			days = ", " + daysLeft + "d";
		} else {
			days = ", <1d";
		}
		return text + " - " + Misc.getWithDGS(baseBounty) + Strings.C + days;
	}
	

	@Override
	public CampaignEventCategory getEventCategory() {
		return CampaignEventCategory.BOUNTY;
	}


	@Override
	public void reportBattleOccurred(CampaignFleetAPI primaryWinner, BattleAPI battle) {
		if (!isEventStarted()) return;
		
		if (!battle.isPlayerInvolved()) return;
		
		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		if (!primaryWinner.isInOrNearSystem(market.getStarSystem())) return;
		
		lastBounty = 0;
		float fpDestroyed = 0;
		for (CampaignFleetAPI otherFleet : battle.getNonPlayerSideSnapshot()) {
			if (!market.getFaction().isHostileTo(otherFleet.getFaction())) continue;
			
			float bounty = 0;
			for (FleetMemberAPI loss : Misc.getSnapshotMembersLost(otherFleet)) {
				float mult = Misc.getSizeNum(loss.getHullSpec().getHullSize());
				bounty += mult * baseBounty;
				fpDestroyed += loss.getFleetPointCost();
			}
			
			lastBounty += (int) (bounty * battle.getPlayerInvolvementFraction());
		}
	
		if (lastBounty > 0) {
			//bounty_no_payment bounty_no_rep
			//RepLevel level = playerFleet.getFaction().getRelationshipLevel(otherFleet.getFaction());
			RepLevel level = playerFleet.getFaction().getRelationshipLevel(market.getFaction());
			final int payment = lastBounty;
			final float repFP = (int)(fpDestroyed * battle.getPlayerInvolvementFraction());
			if (level.isAtWorst(RepLevel.SUSPICIOUS)) {
				String reportId = "bounty_payment";
				if (battle.getPlayerInvolvementFraction() < 1) {
					reportId = "bounty_payment_share";
				}
				log.info(String.format("Paying bounty of %d from market [%s]", (int) lastBounty, market.getName()));
				Global.getSector().reportEventStage(this, reportId, market.getPrimaryEntity(),
											MessagePriority.ENSURE_DELIVERY,
							new BaseOnMessageDeliveryScript() {
					public void beforeDelivery(CommMessageAPI message) {
						CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
						playerFleet.getCargo().getCredits().add(payment);
						
						if (repFP > 0) {
							Global.getSector().adjustPlayerReputation(
									new RepActionEnvelope(RepActions.SYSTEM_BOUNTY_REWARD, new Float(repFP), message, true), 
									market.getFaction().getId());
						}
					}
				});
			} else if (level.isAtWorst(RepLevel.HOSTILE)) {
				log.info(String.format("Not paying bounty, but improving rep with market [%s]", market.getName()));
				Global.getSector().reportEventStage(this, "bounty_no_payment", playerFleet,
											MessagePriority.ENSURE_DELIVERY,
							new BaseOnMessageDeliveryScript() {
					public void beforeDelivery(CommMessageAPI message) {
						if (repFP > 0) {
							Global.getSector().adjustPlayerReputation(
									new RepActionEnvelope(RepActions.SYSTEM_BOUNTY_REWARD, new Float(repFP), message, true), 
									market.getFaction().getId());
						}
					}
				});
			} else {
				log.info(String.format("Not paying bounty or improving rep with market [%s]", market.getName()));
				Global.getSector().reportEventStage(this, "bounty_no_rep", playerFleet,
											MessagePriority.ENSURE_DELIVERY);
			}
		}
	}

}






