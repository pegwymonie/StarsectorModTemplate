package com.fs.starfarer.api.impl.campaign.events;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.log4j.Logger;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.events.CampaignEventTarget;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.MutableCharacterStatsAPI;
import com.fs.starfarer.api.characters.OfficerDataAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.characters.SkillSpecAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Ranks;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.plugins.OfficerLevelupPlugin;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import com.fs.starfarer.api.util.Misc.Token;

/**
 * 
 * @author Alex Mosolov
 *
 * Copyright 2014 Fractal Softworks, LLC
 */
public class OfficerManagerEvent extends BaseEventPlugin {
	
	public static class AvailableOfficer {
		public PersonAPI person;
		public String marketId;
		public int hiringBonus;
		public AvailableOfficer(PersonAPI person, String marketId, int hiringBonus) {
			this.person = person;
			this.marketId = marketId;
			this.hiringBonus = hiringBonus;
		}
		
	}
	
	public static Logger log = Global.getLogger(OfficerManagerEvent.class);
	
	private IntervalUtil addTracker = new IntervalUtil(0.5f, 1.5f);
	private IntervalUtil removeTracker = new IntervalUtil(1f, 3f);
	
	private List<AvailableOfficer> available = new ArrayList<AvailableOfficer>();
	
	public void init(String type, CampaignEventTarget eventTarget) {
		super.init(type, eventTarget);
		readResolve();
	}
	
	Object readResolve() {
		return this;
	}
	
	public void startEvent() {
		super.startEvent();
	}
	
	public void advance(float amount) {
		//if (true) return;
		
		if (!isEventStarted()) return;
		if (isDone()) return;
		
		float days = Global.getSector().getClock().convertToDays(amount);
		
		addTracker.advance(days);
		if (addTracker.intervalElapsed()) {
			int maxOfficers = (int) Global.getSettings().getFloat("officerMaxHireable");
			if (available.size() < maxOfficers) {
				AvailableOfficer officer = createOfficer();
				if (Global.getSettings().isDevMode() && (float) Math.random() > 0.75f &&
						Global.getSector().isInNewGameAdvance() &&
						Global.getSector().getEconomy().getMarket("jangala") != null) {
					officer.marketId = "jangala";
				}
				addAvailable(officer);
				log.info("Added officer at " + officer.marketId + ", " + available.size() + " total available");
			}
		}
		
		removeTracker.advance(days);
		if (removeTracker.intervalElapsed()) {
			WeightedRandomPicker<AvailableOfficer> picker = new WeightedRandomPicker<AvailableOfficer>();
			picker.addAll(available);
			AvailableOfficer pick = picker.pick();
			if (pick != null) {
				removeAvailable(pick);
				log.info("Removed officer from " + pick.marketId + ", " + available.size() + " total available");
			}
		}
		
//		for (AvailableOfficer officer : available) {
//			System.out.println("Name: " + officer.person.getName().getFullName() + ", id: " + officer.person.getId());
//		}
	}
	
	public void addAvailable(AvailableOfficer officer) {
		if (officer == null) return;
		
		available.add(officer);
		
		MarketAPI market = Global.getSector().getEconomy().getMarket(officer.marketId);
		market.getCommDirectory().addPerson(officer.person);
		market.addPerson(officer.person);
		
		officer.person.getMemoryWithoutUpdate().set("$ome_hireable", true);
		officer.person.getMemoryWithoutUpdate().set("$ome_eventRef", this);
		officer.person.getMemoryWithoutUpdate().set("$ome_hiringBonus", Misc.getWithDGS(officer.hiringBonus));
	}
	
	public void removeAvailable(AvailableOfficer officer) {
		if (officer == null) return;
		
		available.remove(officer);
		
		MarketAPI market = Global.getSector().getEconomy().getMarket(officer.marketId);
		market.getCommDirectory().removePerson(officer.person);
		market.removePerson(officer.person);
		
		officer.person.getMemoryWithoutUpdate().unset("$ome_hireable");
		officer.person.getMemoryWithoutUpdate().unset("$ome_eventRef");
		officer.person.getMemoryWithoutUpdate().unset("$ome_hiringBonus");
	}
	
	
	private AvailableOfficer createOfficer() {
		WeightedRandomPicker<MarketAPI> marketPicker = new WeightedRandomPicker<MarketAPI>();
		for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
			marketPicker.add(market, market.getSize());
		}
		MarketAPI market = marketPicker.pick();
		if (market == null) return null;
		
		//FactionAPI faction = Global.getSector().getFaction(Factions.INDEPENDENT);

		int level = (int)(Math.random() * 5) + 1;
		
		PersonAPI person = createOfficer(market.getFaction(), level);
		person.setFaction(Factions.INDEPENDENT);
		
		AvailableOfficer result = new AvailableOfficer(person, market.getId(), person.getStats().getLevel() * 2000);
		return result;
	}
	
	public static PersonAPI createOfficer(FactionAPI faction, int level) {
		return createOfficer(faction, level, false);
	}
	
	
	public static enum SkillPickPreference {
		CARRIER,
		NON_CARRIER,
		EITHER,
	}
	public static PersonAPI createOfficer(FactionAPI faction, int level, boolean alwaysPickHigherSkill) {
		return createOfficer(faction, level, alwaysPickHigherSkill, SkillPickPreference.EITHER);
	}
	public static PersonAPI createOfficer(FactionAPI faction, int level, boolean alwaysPickHigherSkill, SkillPickPreference pref) {
		return createOfficer(faction, level, alwaysPickHigherSkill, pref, null);
	}
	public static PersonAPI createOfficer(FactionAPI faction, int level, boolean alwaysPickHigherSkill, 
										  SkillPickPreference pref, Random random) {
		if (random == null) random = new Random();
		
		PersonAPI person = faction.createRandomPerson(random);
		OfficerLevelupPlugin plugin = (OfficerLevelupPlugin) Global.getSettings().getPlugin("officerLevelUp");
		if (level > plugin.getMaxLevel(person)) level = plugin.getMaxLevel(person);
		
		person.getStats().setSkipRefresh(true);
		
		boolean debug = false;
		
		for (int i = 0; i < 2; i++) {
			List<String> skills = plugin.pickLevelupSkills(person, random);
			String skillId = pickSkill(person, skills, alwaysPickHigherSkill, pref, random);
			if (skillId != null) {
				if (debug) System.out.println("Picking initial skill: " + skillId);
				person.getStats().increaseSkill(skillId);
			}
		}
		
//		level = 20;
//		pref = SkillPickPreference.NON_CARRIER;

		if (debug) System.out.println("Generating officer\n");
		
		long xp = plugin.getXPForLevel(level);
		OfficerDataAPI officerData = Global.getFactory().createOfficerData(person);
		officerData.addXP(xp);
		while (officerData.canLevelUp()) {
			String skillId = pickSkill(officerData.getPerson(), officerData.getSkillPicks(), alwaysPickHigherSkill, pref, random);
			if (skillId != null) {
				if (debug) System.out.println("Leveling up " + skillId);
				officerData.levelUp(skillId);
			} else {
				break;
			}
		}
		
		if (debug) System.out.println("Done\n");
		
		person.setRankId(Ranks.SPACE_LIEUTENANT);
		person.setPostId(Ranks.POST_MERCENARY);
		
		
		String personality = faction.pickPersonality();
		person.setPersonality(personality);
		
		
		person.getStats().setSkipRefresh(false);
		person.getStats().refreshCharacterStatsEffects();
		
		return person;
	}
	
	public static String pickSkill(PersonAPI person, List<String> skills, boolean preferHigher, SkillPickPreference pref, Random random) {
		if (random == null) random = new Random();
		
		WeightedRandomPicker<String> picker = new WeightedRandomPicker<String>(random);
		
		if (preferHigher) {
			String highestId = null;
			float highestLevel = -1;
			boolean highestPreferred = false;
			for (String id : skills) {
				float curr = person.getStats().getSkillLevel(id);
				SkillSpecAPI spec = Global.getSettings().getSkillSpec(id);
				boolean carrierSkill = spec.hasTag(Tags.SKILL_CARRIER);
				boolean currPreferred = (pref == SkillPickPreference.CARRIER && carrierSkill) || 
										(pref == SkillPickPreference.NON_CARRIER && !carrierSkill);
				if (curr > highestLevel || (currPreferred && !highestPreferred)) {
					highestId = id;
					highestLevel = curr;
					highestPreferred = currPreferred;
				}
			}
			picker.add(highestId);
		} else {
			for (String id : skills) {
				float curr = person.getStats().getSkillLevel(id);
				SkillSpecAPI spec = Global.getSettings().getSkillSpec(id);
				boolean carrierSkill = spec.hasTag(Tags.SKILL_CARRIER);
				boolean currPreferred = (pref == SkillPickPreference.CARRIER && carrierSkill) || 
										(pref == SkillPickPreference.NON_CARRIER && !carrierSkill);
				if (currPreferred) {
					picker.add(id);
				}
			}
			if (picker.isEmpty()) {
				picker.addAll(skills);
			}
		}
		
		return picker.pick();
	}
	
	
	
	
	@Override
	public boolean callEvent(String ruleId, InteractionDialogAPI dialog, List<Token> params, Map<String, MemoryAPI> memoryMap) {
		String action = params.get(0).getString(memoryMap);
		
		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		CargoAPI cargo = playerFleet.getCargo();
		
		if (action.equals("printSkills")) {
			String personId = params.get(1).getString(memoryMap);
			AvailableOfficer officer = getOfficer(personId);
			if (officer != null) {
				MutableCharacterStatsAPI stats = officer.person.getStats();
				TextPanelAPI text = dialog.getTextPanel();
				
				text.setFontSmallInsignia();
				
				Color hl = Misc.getHighlightColor();
				Color red = Misc.getNegativeHighlightColor();
				
				text.addParagraph("-----------------------------------------------------------------------------");
				
				text.addParagraph("Level: " + (int) stats.getLevel());
				text.highlightInLastPara(hl, "" + (int) stats.getLevel());
				
				for (String skillId : Global.getSettings().getSortedSkillIds()) {
					int level = (int) stats.getSkillLevel(skillId);
					if (level > 0) {
						SkillSpecAPI spec = Global.getSettings().getSkillSpec(skillId);
						String skillName = spec.getName();
						if (spec.isAptitudeEffect()) {
							skillName += " Aptitude";
						}
						text.addParagraph(skillName + ", level " + level);
						text.highlightInLastPara(hl, "" + level);
					}
				}
				
				String personality = Misc.lcFirst(officer.person.getPersonalityAPI().getDisplayName());
				text.addParagraph("Personality: " + personality);
				text.highlightInLastPara(hl, personality);
				text.addParagraph(officer.person.getPersonalityAPI().getDescription());
				
				text.addParagraph("-----------------------------------------------------------------------------");
				
				text.setFontInsignia();
			}
		} else if (action.equals("hireOfficer")) {
			String personId = params.get(1).getString(memoryMap);
			AvailableOfficer officer = getOfficer(personId);
			if (officer != null) {
				removeAvailable(officer);
				playerFleet.getFleetData().addOfficer(officer.person);
				playerFleet.getCargo().getCredits().subtract(officer.hiringBonus);
				if (playerFleet.getCargo().getCredits().get() <= 0) {
					playerFleet.getCargo().getCredits().set(0);
				}
			}
		} else if (action.equals("atLimit")) {
			//int max = (int) Global.getSettings().getFloat("officerPlayerMax");
			int max = (int) playerFleet.getCommander().getStats().getOfficerNumber().getModifiedValue();
			return playerFleet.getFleetData().getOfficersCopy().size() >= max;
		} else if (action.equals("canAfford")) {
			String personId = params.get(1).getString(memoryMap);
			AvailableOfficer officer = getOfficer(personId);
			if (officer != null) {
				return playerFleet.getCargo().getCredits().get() >= officer.hiringBonus;
			} else {
				return false;
			}
		}
		
		return true;
	}
	
	private AvailableOfficer getOfficer(String personId) {
		for (AvailableOfficer officer: available) {
			if (officer.person.getId().equals(personId)) {
				return officer;
			}
		}
		return null;
	}

	public Map<String, String> getTokenReplacements() {
		Map<String, String> map = super.getTokenReplacements();
		return map;
	}

	@Override
	public String[] getHighlights(String stageId) {
		return null;
	}
	
	@Override
	public Color[] getHighlightColors(String stageId) {
		return super.getHighlightColors(stageId);
	}
	
	
	private CampaignEventTarget tempTarget = null;
	
	@Override
	public CampaignEventTarget getEventTarget() {
		if (tempTarget != null) return tempTarget;
		return super.getEventTarget();
	}

	public boolean isDone() {
		return false;
	}
	
	@Override
	public CampaignEventCategory getEventCategory() {
		return CampaignEventCategory.DO_NOT_SHOW_IN_MESSAGE_FILTER;
	}
	
	public boolean showAllMessagesIfOngoing() {
		return false;
	}
}










