package com.fs.starfarer.api.impl.campaign.econ;

import java.util.Map;

import com.fs.starfarer.api.impl.campaign.events.TradeDisruptionAndSmugglingEvent;

public class Smuggling extends BaseMarketConditionPlugin {
	
	private TradeDisruptionAndSmugglingEvent event = null;
	
	public Smuggling() {
	}

	public void apply(String id) {
		//"market_smuggling"
		market.getStability().modifyFlat(id, -1 * event.getSmugglingPenalty(), "Smuggling");
	}

	public void unapply(String id) {
		market.getStability().unmodify(id);
	}
	
	@Override
	public void setParam(Object param) {
		event = (TradeDisruptionAndSmugglingEvent) param;
	}
	
	public Map<String, String> getTokenReplacements() {
		Map<String, String> tokens = super.getTokenReplacements();
		
		int penalty = event.getSmugglingPenalty();
		tokens.put("$smugglingPenalty", "" + penalty);
		
		return tokens;
	}

	@Override
	public String[] getHighlights() {
		return new String[] {"" + event.getSmugglingPenalty() };
	}

	@Override
	public boolean isTransient() {
		return false;
	}
	
	
}
