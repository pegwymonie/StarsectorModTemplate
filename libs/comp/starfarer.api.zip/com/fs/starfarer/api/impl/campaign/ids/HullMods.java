package com.fs.starfarer.api.impl.campaign.ids;

public class HullMods {

	//public static final String PDJAMMER = "pdjammer";
	
	public static final String DEDICATED_TARGETING_CORE = "dedicated_targeting_core";
	public static final String INTEGRATED_TARGETING_UNIT = "targetingunit";
	
	
	public static final String BLAST_DOORS = "blast_doors";
	public static final String REINFORCEDHULL = "reinforcedhull";
	public static final String HARDENED_SUBSYSTEMS = "hardened_subsystems";
	
	public static final String AUXILIARY_THRUSTERS = "auxiliarythrusters";
	public static final String FLUX_DISTRIBUTOR = "fluxdistributor";
	public static final String FLUX_COIL = "fluxcoil";
	
	
	
	public static final String PHASE_FIELD = "phasefield";
	
	public static final String AUTOMATED = "automated";
	
	public static final String CIVGRADE = "civgrade";
	public static final String SHIELDED_CARGO_HOLDS = "shielded_holds";
	
	
	public static final String COMP_ARMOR = "comp_armor";
	public static final String COMP_HULL = "comp_hull";
	public static final String DEGRADED_ENGINES = "degraded_engines";
	public static final String FAULTY_GRID = "faulty_grid";
	public static final String UNSTABLE_COILS = "unstable_coils";
	public static final String COMP_STRUCTURE = "comp_structure";
	public static final String GLITCHED_SENSORS = "glitched_sensors";
	public static final String DAMAGED_DECK = "damaged_deck";
	public static final String FRAGILE_SUBSYSTEMS = "fragile_subsystems";
	public static final String DESTROYED_MOUNTS = "destroyed_mounts";
	public static final String ILL_ADVISED = "ill_advised";
	
	//public static final String AXIAL_ROTATION = "shielded_holds";
}









