package com.fs.starfarer.api.impl.campaign.econ;

import com.fs.starfarer.api.impl.campaign.ids.Commodities;

public class ViceDemand extends BaseMarketConditionPlugin {

	public void apply(String id) {
		float size = market.getSize();
		float pop = getPopulation(market);
		
		float mult = getBaseSizeMult();
		
		if (size >= 2) {
//			market.getDemand(Commodities.DRUGS).getDemand().modifyFlat(id, Math.max(100, pop * 0.01f));
//			market.getDemand(Commodities.HAND_WEAPONS).getDemand().modifyFlat(id, Math.max(10, pop * 0.001f));
			market.getDemand(Commodities.DRUGS).getDemand().modifyFlat(id, Math.max(100, mult * ConditionData.VICE_DRUGS));
			market.getDemand(Commodities.HAND_WEAPONS).getDemand().modifyFlat(id, Math.max(10, mult * ConditionData.VICE_WEAPONS));
		}
	}

	public void unapply(String id) {
		market.getDemand(Commodities.DRUGS).getDemand().unmodify(id);
		market.getDemand(Commodities.HAND_WEAPONS).getDemand().unmodify(id);
	}

}
