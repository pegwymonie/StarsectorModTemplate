package com.fs.starfarer.api.impl.campaign.missions;

import org.apache.log4j.Logger;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.MissionBoardAPI;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.campaign.CargoAPI.CargoItemType;
import com.fs.starfarer.api.campaign.econ.CommodityOnMarketAPI;
import com.fs.starfarer.api.campaign.econ.CommoditySpecAPI;
import com.fs.starfarer.api.campaign.econ.EconomyAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.SubmarketAPI;
import com.fs.starfarer.api.characters.ImportantPeopleAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.characters.ImportantPeopleAPI.PersonDataAPI;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.MissionCompletionRep;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Ranks;
import com.fs.starfarer.api.impl.campaign.shared.SharedData;
import com.fs.starfarer.api.impl.campaign.shared.CommodityStatTracker.CommodityStats;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;

public class MarketProcurementMissionCreator implements EveryFrameScript {
	public static Logger log = Global.getLogger(MarketProcurementMissionCreator.class);
	
	
	private MissionBoardAPI board;
	private IntervalUtil tracker = new IntervalUtil(0.25f, .75f);
	
	public MarketProcurementMissionCreator() {
		board = Global.getSector().getMissionBoard();
	}
	
	
	public void advance(float amount) {
		//if (true) return;
		
		Global.getSettings().profilerBegin(this.getClass().getSimpleName() + ".advance()");
		float days = Global.getSector().getClock().convertToDays(amount);
		tracker.advance(days);
		if (tracker.intervalElapsed()) {
			int maxConcurrent = (int) Global.getSettings().getFloat("maxMarketProcurementConcurrent");
			int num = board.getNumMissions(MarketProcurementMission.class);
			if (num < maxConcurrent) {
				for (int i = 0; i < 3; i++) {
					if (createMission()) break;
				}
			}
		}
		Global.getSettings().profilerEnd();
//		for (MissionAvailabilityAPI mission : board.getMissionsCopy()) {
//			System.out.println("Misson: " + mission.getMission().getName());
//		}
	}
	
	
	/**
	 * 1) Target market should have some demand for commodity.
	 * 2) Commodity should not be available in sufficient quantity in target market's system.
	 * @return
	 */
	protected boolean createMission() {
		String commodityId = pickCommodity();
		if (commodityId == null) return false;
		
//		WeightedRandomPicker<Float> quantityPicker = new WeightedRandomPicker<Float>();
//		
//		float [] quantities = new float [] {10f, 20, 30, 40, 50, 75, 100,
//										    200, 300, 400, 500, 750, 1000,
//										    2000, 2500, 3000, 3500, 4000, 4500, 5000,
//										    6000, 7000, 8000, 9000, 10000};
//		
//		if (Global.getSector().isInNewGameAdvance()) {
//			quantities = new float [] {10f, 20, 30, 40, 50, 75, 100};
//		}
//		
//		
//		float playerCargo = 50f;
//		CampaignFleetAPI player = Global.getSector().getPlayerFleet();
//		if (player != null) {
//			playerCargo = (player.getCargo().getMaxCapacity() + player.getCargo().getMaxFuel()) * 0.5f;
//			//playerCargo = player.getCargo().getMaxCapacity();
//			if (playerCargo < 10) playerCargo = 10;
//		}
//		for (float q : quantities) {
//			float diff = Math.abs(playerCargo - q);
//			float prob = 1f;
//			if (diff > 50 && diff > playerCargo * 1.5f) {
//				prob = playerCargo / q;
//				if (prob > 1) prob = 1f / prob;
//			}
//			if (prob < 0.1f) prob = 0.1f;
//			quantityPicker.add(q, prob);
//			
//		}
//		float quantity = quantityPicker.pick();
		
		float quantity = getQuantity(commodityId);
		float illegalMult = 0.2f;
		float min = 10f;
		MarketAPI market = pickMarket(commodityId, quantity, illegalMult, min);
		if (market == null) return false;

//		commodityId = Commodities.ORE;
//		market = Global.getSector().getEconomy().getMarket("sphinx");
		quantity = (int) getQuantityAdjustedForMarket(commodityId, quantity, illegalMult, min, market);
		
		WeightedRandomPicker<Float> durationPicker = new WeightedRandomPicker<Float>();
		durationPicker.add(20f);
		durationPicker.add(30f);
		durationPicker.add(40f);
		durationPicker.add(60f);
		
		float duration = durationPicker.pick();
		
		CommodityStats stats = SharedData.getData().getActivityTracker().getCommodityTracker().getStats(commodityId);
		
		float price = market.getDemandPrice(commodityId, quantity, false);
		if (price < stats.getAverageDemandPrice() * quantity) price = stats.getAverageDemandPrice() * quantity;
		float basePerUnit = market.getCommodityData(commodityId).getCommodity().getBasePrice();
		if (price < basePerUnit * quantity) price = basePerUnit * quantity;
		
		float maxQuantity = 10000f;
		float maxDuration = 60f;

//		price *= 1f + 0.5f * (1f - duration / maxDuration);
//		price *= 1f + 0.5f * (1f - quantity / maxQuantity);
		
		float durationBonus = Math.min(price/quantity * (0.5f * (2f - Math.min(1f, duration / maxDuration))), 300);
		float quantityBonus = Math.min(price/quantity * (0.5f * (2f - Math.min(1f, quantity / maxQuantity))), 300);
		if (durationBonus < 10) durationBonus = 10;
		if (quantityBonus < 10) quantityBonus = 10;
		
//		if (duration == 10f) {
//			durationBonus += 100f + (float) Math.random() * 100f;
//		}
		
		price += durationBonus * quantity;
		price += quantityBonus * quantity;

		PersonAPI contact = pickContact(market, market.getCommodityData(commodityId));
		boolean illegal = contact.getFaction().isHostileTo(market.getFaction());
		//boolean illegal = market.isIllegal(commodityId);
		if (illegal) {
			price *= 2f;
		} else {
			price *= 1f;
		}
		
		
//		if (basePerUnit < 30 || price / quantity < 30) {
//			price += quantity * (0.5f + (float) Math.random() * 0.5f) * (30f - Math.min(price / quantity, basePerUnit));
//		}
		
		float pricePerUnit  = (int) (price / quantity);
		
//		if (commodityId.equals("drugs")) {
//			System.out.println("sdflhwefwe");
//		}

		if (pricePerUnit > stats.getAverageDemandPrice() * 2f && pricePerUnit > 200f) {
			//pricePerUnit = (float) (Math.ceil((stats.getAverageDemandPrice() * 2f) / 100f) * 100f);
			pricePerUnit = stats.getAverageDemandPrice() * (2f + (float) Math.random() * 0.5f);
		}
		if (pricePerUnit < 10) pricePerUnit = 10;
		
		
		boolean withBonus = duration > 10f && (float) Math.random() > 0.5f;
		
		float bonusDuration = 0f;
		float bonusAmount = 0f;
		if (withBonus) {
			bonusDuration = duration * 0.75f;
			if (bonusDuration < 10f) bonusDuration = 10f;
			
			bonusAmount = (int) (price * (0.25f + 0.25 * (float) Math.random()));
			//bonusAmount *= Math.max(maxDuration - bonusDuration, 0) / maxDuration;
			bonusAmount = (int) (bonusAmount / 1000) * 1000;
			if (bonusAmount < 1000) bonusAmount = 1000;
		}
		
		float repAmount = 0.01f * price / 100000f;
		if (repAmount < 0.01f) repAmount = 0.01f;
		if (repAmount > 0.05f) repAmount = 0.05f;
		
		
		MissionCompletionRep rep = new MissionCompletionRep(repAmount, RepLevel.WELCOMING, -repAmount, RepLevel.INHOSPITABLE);
		MarketProcurementMission mission = new MarketProcurementMission(market.getId(), contact, 
												commodityId, pricePerUnit, quantity, bonusAmount,
												10f, duration, bonusDuration,
												rep);
		
		log.info("Created MarketProcurementMission: " + commodityId + " to " + market.getName());
		
		BaseMissionCreator.makeMissionAvailableNearby(market, mission);
		
		return true;
	}
	
	
	protected PersonAPI pickContact(MarketAPI market, CommodityOnMarketAPI com) {
		Global.getSettings().profilerBegin(this.getClass().getSimpleName() + ".pickContact()");
		PersonAPI contact = null;
		ImportantPeopleAPI ip = Global.getSector().getImportantPeople();
		
		String comId = com.getId();
		
		if (com.getCommodity().hasTag(Commodities.TAG_MILITARY)) {
			if ((float) Math.random() > 0.1f) {
				contact = ip.getPerson(market.getFaction(), market,
							MarketProcurementMission.PERSON_CHECKOUT_REASON, Ranks.GROUND_LIEUTENANT, 
							Ranks.POST_SUPPLY_OFFICER,
							Ranks.POST_BASE_COMMANDER,
							Ranks.POST_OUTPOST_COMMANDER,
							Ranks.POST_PORTMASTER).getPerson();
			} else {
				contact = getCriminal(market, MarketProcurementMission.PERSON_CHECKOUT_REASON, Factions.PIRATES).getPerson();
			}
		}
		
		if (contact == null && com.getCommodity().hasTag(Commodities.TAG_MEDICAL)) {
			if ((float) Math.random() > 0.25f) {
				contact = ip.getPerson((float) Math.random() > 0.5f ? Factions.INDEPENDENT : market.getFactionId(),
						market,
						MarketProcurementMission.PERSON_CHECKOUT_REASON, Ranks.CITIZEN, 
						Ranks.POST_MEDICAL_SUPPLIER).getPerson();
			} else {
				contact = getCriminal(market, MarketProcurementMission.PERSON_CHECKOUT_REASON, Factions.PIRATES).getPerson();
			}
		}
		
		if (contact == null && com.getCommodity().hasTag(Commodities.TAG_LUXURY)) {
			if ((float) Math.random() > 0.1f && !market.isIllegal(comId)) {
				contact = getLegitTrader(market, MarketProcurementMission.PERSON_CHECKOUT_REASON, market.getFactionId()).getPerson();
			} else {
				contact = getCriminal(market, MarketProcurementMission.PERSON_CHECKOUT_REASON, Factions.PIRATES).getPerson();
			}
		}
		
		if (contact == null) {
			if ((float) Math.random() > 0.05f && !market.isIllegal(comId)) {
				contact = getLegitTrader(market, MarketProcurementMission.PERSON_CHECKOUT_REASON, market.getFactionId()).getPerson();
			} else {
				contact = getCriminal(market, MarketProcurementMission.PERSON_CHECKOUT_REASON, Factions.PIRATES).getPerson();
			}
		}
		
		if (contact == null) {
			// shouldn't happen, but just in case
			contact = market.getFaction().createRandomPerson();
			contact.setPostId(Ranks.POST_CITIZEN);
			contact.setRankId(null);
			market.addPerson(contact);
			ip.addPerson(contact);
			ip.getData(contact).getLocation().setMarket(market);
		}
		Global.getSettings().profilerEnd();
		return contact;
	}
	
	
	public static PersonDataAPI getLegitTrader(MarketAPI market, String checkoutReason, String factionId) {
		ImportantPeopleAPI ip = Global.getSector().getImportantPeople();
		return ip.getPerson(factionId,
				market,
				checkoutReason, Ranks.CITIZEN, 
				Ranks.POST_MERCHANT,
				Ranks.POST_COMMODITIES_AGENT,
				Ranks.POST_INVESTOR,
				Ranks.POST_TRADER);
	}
	
	public static PersonDataAPI getCriminal(MarketAPI market, String checkoutReason, String factionId) {
		ImportantPeopleAPI ip = Global.getSector().getImportantPeople();
		return ip.getPerson(factionId,
				market,
				checkoutReason, Ranks.CITIZEN, 
				Ranks.POST_GANGSTER,
				Ranks.POST_SMUGGLER,
				Ranks.POST_FENCE);
	}
	
	
	
	
	protected String pickCommodity() {
		Global.getSettings().profilerBegin(this.getClass().getSimpleName() + ".pickCommodity()");
		EconomyAPI economy = Global.getSector().getEconomy();
		WeightedRandomPicker<String> picker = new WeightedRandomPicker<String>();
		
		for (String curr : economy.getAllCommodityIds()) {
			CommoditySpecAPI spec = economy.getCommoditySpec(curr);
			if (spec.hasTag(Commodities.TAG_CREW)) continue;
			if (spec.hasTag(Commodities.TAG_MARINES)) continue;
			if (spec.hasTag(Commodities.TAG_NON_ECONOMIC)) continue;
//			if (spec.getId().equals(Commodities.SUPPLIES)) continue;
//			if (spec.getId().equals(Commodities.FUEL)) continue;
			
			//float weight = spec.getBasePrice();
			float weight = 1f;
			picker.add(curr, weight);
		}
		Global.getSettings().profilerEnd();
		return picker.pick();
	}
	
	protected int getQuantity(String commodityId) {
		CommoditySpecAPI spec = Global.getSettings().getCommoditySpec(commodityId);
		float cargoCapacity = 30;
		CampaignFleetAPI player = Global.getSector().getPlayerFleet();
		if (player != null) {
			if (Commodities.FUEL.equals(commodityId)) {
				cargoCapacity = Math.max(cargoCapacity, cargoCapacity = player.getCargo().getMaxFuel());
			} else {
				cargoCapacity = Math.max(cargoCapacity, player.getCargo().getMaxCapacity());
			}
		}
		
		// using fuel as a mid-price commodity
		CommoditySpecAPI fuel = Global.getSettings().getCommoditySpec(Commodities.FUEL);
		float targetValue = cargoCapacity * Math.max(5f, fuel.getBasePrice());
		
		float units = targetValue / Math.max(5f, spec.getBasePrice());
		
		units *= 0.5f + (float) Math.random();
		
		//return (int) Misc.getRounded(units);
		return (int) units / 10 * 10;
	}
	
	protected float getQuantityAdjustedForMarket(String commodityId, float quantity, float illegalMult, float min, MarketAPI market) {
		if (market.getSize() <= 4) {
			quantity = Math.min(quantity, 200);
		} else if (market.getSize() == 5) {
			quantity = Math.min(quantity, 500);
		} else if (market.getSize() == 6) {
			quantity = Math.min(quantity, 1000);
		} else if (market.getSize() == 7) {
			quantity = Math.min(quantity, 2000);
		} else if (market.getSize() >= 8) {
			quantity = Math.min(quantity, 10000);
		}
		CommodityOnMarketAPI com = market.getCommodityData(commodityId);
		if (com.getUtilityOnMarket() > 0) {
			quantity /= com.getUtilityOnMarket();
		}
		boolean illegal = market.isIllegal(commodityId);
		if (illegal) {
			quantity *= illegalMult;
			if (quantity < min) quantity = min;
		}
		return (int)quantity;
	}
	
	protected MarketAPI pickMarket(String commodityId, float quantity, float illegalMult, float min) {
		Global.getSettings().profilerBegin(this.getClass().getSimpleName() + ".pickMarket()");
		EconomyAPI economy = Global.getSector().getEconomy();
		
		WeightedRandomPicker<MarketAPI> picker = new WeightedRandomPicker<MarketAPI>();
		
		for (MarketAPI market : economy.getMarketsCopy()) {
			CommodityOnMarketAPI com = market.getCommodityData(commodityId);
			
			boolean illegal = market.isIllegal(commodityId);
			float test = getQuantityAdjustedForMarket(commodityId, quantity, illegalMult, min, market);
			if (illegal) {
				test *= illegalMult;
				if (test < min) test = min;
			}
			//if (com.getAverageStockpileAfterDemand() >= minQty) continue;
			// don't filter on demand - open up more possibilities; may be needed for non-market-condition reasons
			//if (com.getDemand().getDemandValue() < minQty) continue;
			
			if (doNearbyMarketsHave(market, commodityId, test * 0.5f)) continue;
			
			float weight = market.getSize();
			picker.add(market, weight);
		}
		Global.getSettings().profilerEnd();
		return picker.pick();
	}
	
	protected boolean doNearbyMarketsHave(MarketAPI from, String commodityId, float minQty) {
		if (from.getContainingLocation() == null) return false;
		//if (from.getContainingLocation() == null || from.getContainingLocation().isHyperspace()) return false;
		
		//Global.getSettings().profilerBegin(this.getClass().getSimpleName() + ".doNearbyMarketsHave()");
		for (MarketAPI curr : Misc.getMarketsInLocation(from.getContainingLocation())) {
			//if (curr == from) continue;
			if (curr.getPrimaryEntity() != null && from.getPrimaryEntity() != null) {
				float dist = Misc.getDistance(curr.getPrimaryEntity().getLocation(), from.getPrimaryEntity().getLocation());
				if (dist > 6000) continue;
			}
			
			CommodityOnMarketAPI com = curr.getCommodityData(commodityId);
			
			for (SubmarketAPI sub : curr.getSubmarketsCopy()) {
				if (!sub.getPlugin().isParticipatesInEconomy()) continue;
				if (sub.getPlugin().getDesiredAboveDemandCommodityQuantity(com) + 
					sub.getPlugin().getDesiredAboveDemandCommodityQuantity(com) >= minQty) {
					return true;
				}
			}
			
//			if (com.getAboveDemandStockpile() >= minQty) {
//				//Global.getSettings().profilerEnd();
//				return true;
//			}
			
			//if (com.getSupplyValue() >= minQty) return true;
			for (SubmarketAPI submarket : curr.getSubmarketsCopy()) {
				//if (!submarket.getPlugin().isParticipatesInEconomy()) continue;
				CargoAPI cargo = submarket.getCargoNullOk();
				if (cargo == null) continue;
				if (cargo.getQuantity(CargoItemType.RESOURCES, commodityId) >= minQty * 0.5f) return true;
			}
		}
		//Global.getSettings().profilerEnd();
		return false;
	}

	public boolean isDone() {
		return false;
	}

	public boolean runWhilePaused() {
		return false;
	}

}
