package com.fs.starfarer.api.impl.campaign.missions;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI.SurveyLevel;
import com.fs.starfarer.api.campaign.events.CampaignEventManagerAPI;
import com.fs.starfarer.api.campaign.events.CampaignEventPlugin;
import com.fs.starfarer.api.campaign.events.CampaignEventTarget;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.MissionCompletionRep;
import com.fs.starfarer.api.impl.campaign.ids.Events;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.util.Highlights;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;

public class SurveyPlanetMission extends BaseCampaignMission {
	
	private MarketAPI market; 
	private int reward;
	private float duration = 1f;
	private String factionId;
	
	private MissionCompletionRep repChange = null;
	private IntervalUtil randomCancel = new IntervalUtil(4, 6);

	private PlanetAPI planet;

	
	public SurveyPlanetMission(String marketId, String factionId, PlanetAPI planet,
								int reward, float duration, MissionCompletionRep rep) {
		
		this.planet = planet;
		this.market = Global.getSector().getEconomy().getMarket(marketId);
		this.reward = reward;
		this.duration = duration;
		this.repChange = rep;
		
		if (factionId == null) factionId = market.getFactionId();
		this.factionId = factionId;
		
		CampaignEventManagerAPI eventManager = Global.getSector().getEventManager();
		CampaignEventTarget target = new CampaignEventTarget(planet);
		target.setExtra(Misc.genUID());
		
		event = eventManager.primeEvent(target, Events.SURVEY_PLANET, this);
	}
	
	
	public void advance(float amount) {
		float days = Global.getSector().getClock().convertToDays(amount);
		
		if (!isValidMissionTarget(planet)) {
			Global.getSector().getMissionBoard().removeMission(this, true);
			return;
		}
		
		randomCancel.advance(days);
		if (randomCancel.intervalElapsed()) {
			if ((float) Math.random() < 0.5f) {
				Global.getSector().getMissionBoard().removeMission(this, true);
			}
		}
	}
	
	public static boolean isValidMissionTarget(PlanetAPI planet) {
		if (planet.isStar() || planet.getMarket() == null || !planet.getMarket().isPlanetConditionMarketOnly() ||
				planet.getMarket().getSurveyLevel() == SurveyLevel.FULL) {
			return false;
		}
		return true;
	}
	
	@Override
	public String getPostingStage() {
		return super.getPostingStage();
	}


	public String getName() {
		String where = planet.getContainingLocation().getNameWithTypeIfNebula();
		return "Survey Planet in " + where;
	}

	public void playerAccept(SectorEntityToken entity) {
		super.playerAccept(entity);
		CampaignEventManagerAPI eventManager = Global.getSector().getEventManager();
		eventManager.startEvent(event);
	}

	@Override
	public boolean canPlayerAccept() {
		if (!super.canPlayerAccept()) return false;
		
		CampaignFleetAPI player = Global.getSector().getPlayerFleet();
		float fleetHazardLimit = player.getStats().getDynamic().getValue(Stats.SURVEY_MAX_HAZARD, 0f);
		boolean canSurvey = fleetHazardLimit >= planet.getMarket().getHazardValue();
		return canSurvey;
	}

	@Override
	public String getAcceptTooltip() {
		if (!super.canPlayerAccept()) return super.getAcceptTooltip();
		
		CampaignFleetAPI player = Global.getSector().getPlayerFleet();
		float fleetHazardLimit = player.getStats().getDynamic().getValue(Stats.SURVEY_MAX_HAZARD, 0f);
		String fleetLimitPercent = "" + (int) Math.round(fleetHazardLimit * 100f) + "%";
		boolean canSurvey = fleetHazardLimit >= planet.getMarket().getHazardValue();
		if (canSurvey) return null; 
		//String planetHazardPercent = "" + (int) Math.round(planet.getMarket().getHazardValue() * 100f) + "%";
		return "Only capable of surveying planets with a hazard rating of " + fleetLimitPercent + " or less.";
	}

	@Override
	public Highlights getAcceptTooltipHighlights() {
		if (!super.canPlayerAccept()) return super.getAcceptTooltipHighlights();
		
		CampaignFleetAPI player = Global.getSector().getPlayerFleet();
		float fleetHazardLimit = player.getStats().getDynamic().getValue(Stats.SURVEY_MAX_HAZARD, 0f);
		String fleetLimitPercent = "" + (int) Math.round(fleetHazardLimit * 100f) + "%";
		
		Highlights h = new Highlights();
		h.setText(fleetLimitPercent);
		h.setColors(Misc.getNegativeHighlightColor());
		
		return h;
	}

	

	public MarketAPI getMarket() {
		return market;
	}

	public CampaignEventPlugin getPrimedEvent() {
		return event;
	}
	
	public PersonAPI getImportantPerson() {
		return super.getImportantPerson();
	}

	public MissionCompletionRep getRepChange() {
		return repChange;
	}
	
	public int getReward() {
		return reward;
	}

	public float getDuration() {
		return duration;
	}

	public PlanetAPI getPlanet() {
		return planet;
	}

	public String getFactionId() {
		return factionId;
	}

}




