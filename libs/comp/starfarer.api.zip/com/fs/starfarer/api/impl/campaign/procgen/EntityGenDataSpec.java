package com.fs.starfarer.api.impl.campaign.procgen;

public interface EntityGenDataSpec {
	String getId();
	String getCategory();
	
	
	
	float getHabOffsetYOUNG();
	float getHabOffsetAVERAGE();
	float getHabOffsetOLD();
}
