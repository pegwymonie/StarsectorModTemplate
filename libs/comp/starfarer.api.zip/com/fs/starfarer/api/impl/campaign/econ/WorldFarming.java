package com.fs.starfarer.api.impl.campaign.econ;

import com.fs.starfarer.api.impl.campaign.ids.Commodities;

public class WorldFarming extends BaseMarketConditionPlugin {

	private float foodMult, machineryMult, maxFood;
	public WorldFarming(float foodMult, float machineryMult) {
		this.foodMult = foodMult;
		this.machineryMult = machineryMult;
		this.maxFood = Float.MAX_VALUE;
	}
	
	public boolean showIcon() {
		return false;
	}
	
	public WorldFarming(float foodMult, float machineryMult, float maxFood) {
		this.foodMult = foodMult;
		this.machineryMult = machineryMult;
		this.maxFood = maxFood;
	}

	public void apply(String id) {
		float pop = getPopulation(market);
		float foodProduced = pop * foodMult;
		if (foodProduced > maxFood) foodProduced = maxFood;
		//float organicsProduced = foodProduced * ConditionData.FARMING_ORGANICS_FRACTION;
		//float machineryNeeded = pop * machineryMult;
		
		
		float mult = getBaseSizeMult();
		
		float food = 500f * mult * foodMult;
		//food *= 3f;
		food *= 2f;
		market.getCommodityData(Commodities.FOOD).getSupply().modifyFlat(id, food);
		
//		market.getCommodityData(Commodities.ORGANICS).getSupply().modifyFlat(id, Math.max(1, organicsProduced));
//		market.getCommodityData(Commodities.FOOD).getSupply().modifyFlat(id, Math.max(1, foodProduced));
//		market.getDemand(Commodities.HEAVY_MACHINERY).getDemand().modifyFlat(id, Math.max(1, machineryNeeded));
	}

	public void unapply(String id) {
		market.getCommodityData(Commodities.FOOD).getSupply().unmodify(id);
		
//		market.getCommodityData(Commodities.ORGANICS).getSupply().unmodify(id);
//		market.getCommodityData(Commodities.FOOD).getSupply().unmodify(id);
//		market.getDemand(Commodities.HEAVY_MACHINERY).getDemand().unmodify(id);
	}

}




