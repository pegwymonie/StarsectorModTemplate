package com.fs.starfarer.api.impl.campaign.econ;


public class WorldIce extends WorldFarming {

	public WorldIce() {
		super(ConditionData.WORLD_ICE_FARMING_MULT, ConditionData.WORLD_ICE_MACHINERY_MULT);
	}

}
