package com.fs.starfarer.api.impl.campaign.econ;

import java.util.List;
import java.util.Map;

import com.fs.starfarer.api.impl.campaign.events.TradeDisruptionAndSmugglingEvent;

public class TradeDisruption extends BaseMarketConditionPlugin {
	
	private TradeDisruptionAndSmugglingEvent event = null;
	
	public TradeDisruption() {
	}

	public void apply(String id) {
//		for (AffectedCommodity com : event.getDisruptedCommodities()) {
//			com.commodity.removeFromAverageStockpile(com.disruptionQuantity);
//			com.commodity.setAverageStockpileAfterDemand(0f);
//		}
//		for (AffectedCommodity com : event.getDisruptedCommodities()) {
//			com.commodity.getPlayerPriceMod().modifyPercent(id, com.pricePercent);
//			com.commodity.getPlayerPriceMod().modifyFlat(id, com.priceFlat);
//		}
	}

	public void unapply(String id) {
//		for (AffectedCommodity com : event.getDisruptedCommodities()) {
//			float dq = Math.min(com.disruptionQuantity, com.preDisruptionStockpile - com.commodity.getAverageStockpile());
//			if (dq < 0) dq = 0;
//			com.commodity.addToAverageStockpile(dq);
//			com.disruptionQuantity = dq;
//		}
//		for (CommodityOnMarketAPI com : market.getAllCommodities()) {
//			com.getPlayerPriceMod().unmodify(id);
//		}
	}
	
	
	@Override
	public List<String> getRelatedCommodities() {
		return event.getRelatedCommodities();
	}

	@Override
	public void setParam(Object param) {
		event = (TradeDisruptionAndSmugglingEvent) param;
	}
	
	public Map<String, String> getTokenReplacements() {
		return event.getTokenReplacements();
	}

	@Override
	public String[] getHighlights() {
		return event.getHighlights("report_td");
	}
	
	@Override
	public boolean isTransient() {
		return false;
	}
}





