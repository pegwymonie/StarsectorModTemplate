package com.fs.starfarer.api.impl.campaign.events;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.log4j.Logger;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BaseOnMessageDeliveryScript;
import com.fs.starfarer.api.campaign.BattleAPI;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.FleetAssignment;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.comm.CommMessageAPI;
import com.fs.starfarer.api.campaign.comm.MessagePriority;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.events.CampaignEventManagerAPI;
import com.fs.starfarer.api.campaign.events.CampaignEventPlugin;
import com.fs.starfarer.api.campaign.events.CampaignEventTarget;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.combat.ShipHullSpecAPI;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.RepActionEnvelope;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.RepActions;
import com.fs.starfarer.api.impl.campaign.econ.BaseMarketConditionPlugin;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactoryV2;
import com.fs.starfarer.api.impl.campaign.fleets.FleetParams;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.FleetTypes;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.impl.campaign.ids.Skills;
import com.fs.starfarer.api.impl.campaign.ids.Strings;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.special.BreadcrumbSpecial;
import com.fs.starfarer.api.impl.campaign.shared.PersonBountyEventData;
import com.fs.starfarer.api.impl.campaign.shared.SharedData;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;

public class PersonBountyEvent extends BaseEventPlugin {
	public static Logger log = Global.getLogger(PersonBountyEvent.class);
	
	public static enum BountyType {
		PIRATE,
		DESERTER,
	}
	
	public static enum FleetType {
		LARGE,
		SMALL,
	}
	
	private float elapsedDays = 0f;
	private float duration = 60f;
	private float bountyCredits = 0;
	private MessagePriority messagePriority;
	
	private FactionAPI faction;
	private PersonAPI person;
	private CampaignFleetAPI fleet;
	private String targetDesc;
	
	private BountyType bountyType;
	//private FleetType fleetType;
	
	private PersonBountyEventData data;
	
	private SectorEntityToken hideoutLocation = null;
	
	private int level = 0;
	
	public void init(String type, CampaignEventTarget eventTarget) {
		super.init(type, eventTarget, false);
		messagePriority = MessagePriority.SECTOR;
	}
	
	public float getElapsedDays() {
		return elapsedDays;
	}

	public void setElapsedDays(float elapsedDays) {
		this.elapsedDays = elapsedDays;
	}


	@Override
	public void setParam(Object param) {
		super.setParam(param);
	}

	public void startEvent() {
		super.startEvent(true);
		
		data = SharedData.getData().getPersonBountyEventData();
		data.reportStarted();
		
		pickLevel();
		
		pickMarketAndFaction();
		if (isDone()) return;
		
		initBountyAmount();
		
		pickHideoutLocation();
		if (isDone()) return;
		
		pickBountyType();
		if (bountyType == BountyType.DESERTER) {
			bountyCredits *= 1.5f;
			payment = bountyCredits;
		}
		
		initPerson();
		if (isDone()) return;
		
		spawnFleet();
		if (isDone()) return;
		
		initTargetDesc();
		if (isDone()) return;
		
		if (bountyType == BountyType.PIRATE) {
			Global.getSector().reportEventStage(this, "start_pirate", null, messagePriority, new BaseOnMessageDeliveryScript() {
				public void beforeDelivery(CommMessageAPI message) {
					message.setStarSystemId(hideoutLocation.getContainingLocation().getId());
				}
			});
		} else {
			Global.getSector().reportEventStage(this, "start_deserter", null, messagePriority, new BaseOnMessageDeliveryScript() {
				public void beforeDelivery(CommMessageAPI message) {
					message.setStarSystemId(hideoutLocation.getContainingLocation().getId());
				}
			});
		}
			
		log.info(String.format("Starting person bounty by faction [%s] for person %s", faction.getDisplayName(), person.getName().getFullName()));
	}
	
	protected void pickLevel() {
		
		int base = data.getLevel();
		
		if (Global.getSector().getPlayerFleet() != null) {
			int playerLevel = Global.getSector().getPlayerFleet().getCommander().getStats().getLevel();
			base = Math.max(base, (playerLevel - 10) / 3);
		}
		
		boolean hasLow = false;
		boolean hasHigh = false;
		CampaignEventManagerAPI em = Global.getSector().getEventManager();
		for (CampaignEventPlugin event : em.getOngoingEvents()) {
			if (!(event instanceof PersonBountyEvent)) continue;
			PersonBountyEvent bounty = (PersonBountyEvent) event;
			
			int curr = bounty.getLevel();
			
			if (curr < base || curr == 0) hasLow = true;
			if (curr > base) hasHigh = true;
		}
		
		level = base;
		if (!hasLow) {
			//level -= new Random().nextInt(2) + 1;
			level = 0;
		} else if (!hasHigh) {
			level += new Random().nextInt(3) + 2;
		}
		
		if (level < 0) level = 0;
	}
	
	public int getLevel() {
		return level;
	}

	protected void pickHideoutLocation() {
		WeightedRandomPicker<StarSystemAPI> systemPicker = new WeightedRandomPicker<StarSystemAPI>();
		for (StarSystemAPI system : Global.getSector().getStarSystems()) {
			float weight = system.getPlanets().size();
			float mult = 0f;
			
			if (system.hasPulsar()) continue;
			
			if (system.hasTag(Tags.THEME_MISC_SKIP)) {
				mult = 1f;
			} else if (system.hasTag(Tags.THEME_MISC)) {
				mult = 3f;
			} else if (system.hasTag(Tags.THEME_RUINS)) {
				mult = 5f;
			} else if (system.hasTag(Tags.THEME_REMNANT_DESTROYED)) {
				mult = 3f;
			} else if (system.hasTag(Tags.THEME_CORE_UNPOPULATED)) {
				mult = 1f;
			}
			
			float distToPlayer = Misc.getDistanceToPlayerLY(system.getLocation());
			float noSpawnRange = Global.getSettings().getFloat("personBountyNoSpawnRangeAroundPlayerLY");
			if (distToPlayer < noSpawnRange) mult = 0f;
			
			if (mult <= 0) continue;
			float dist = system.getLocation().length();
			float distMult = Math.max(0, 50000f - dist);
			
			systemPicker.add(system, weight * mult * distMult);
		}
		
		StarSystemAPI system = systemPicker.pick();
		
		if (system != null) {
			WeightedRandomPicker<SectorEntityToken> picker = new WeightedRandomPicker<SectorEntityToken>();
			for (SectorEntityToken planet : system.getPlanets()) {
				if (planet.isStar()) continue;
				if (planet.getMarket() != null && 
						!planet.getMarket().isPlanetConditionMarketOnly()) continue;
				
				picker.add(planet);
			}
			hideoutLocation = picker.pick();
		}
		
		
		if (hideoutLocation == null) {
			endEvent();
		}
	}
	
	

	private void pickMarketAndFaction() {
		FactionAPI player = Global.getSector().getPlayerFaction();

		String commFacId = Misc.getCommissionFactionId();
		boolean forceCommissionFaction = true;
		if (commFacId != null && data.isParticipating(commFacId)) {
			CampaignEventManagerAPI em = Global.getSector().getEventManager();
			for (CampaignEventPlugin event : em.getOngoingEvents()) {
				if (!(event instanceof PersonBountyEvent)) continue;
				PersonBountyEvent bounty = (PersonBountyEvent) event;
				if (bounty.faction != null && bounty.faction.getId().equals(commFacId)) {
					forceCommissionFaction = false;
				}
			}
		} else {
			forceCommissionFaction = false;
		}
		
		WeightedRandomPicker<MarketAPI> picker = new WeightedRandomPicker<MarketAPI>();
		for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
			if (!data.isParticipating(market.getFactionId())) continue;
			if (market.getSize() < 3) continue;
			
			
			float weight = market.getSize();
			if (market.hasCondition(Conditions.MILITARY_BASE)) weight *= 2f;
			if (market.hasCondition(Conditions.HEADQUARTERS)) weight *= 2f;

			if (market.getFaction() != null) {
				if (forceCommissionFaction && !market.getFaction().getId().equals(commFacId)) {
					continue;
				}
					
				if (market.getFaction().isHostileTo(player)) {
					weight *= 0.5f;
				} else {
					// turned off to vary bounties a bit more
					//float rel = market.getFaction().getRelToPlayer().getRel();
					//weight *= 1f + rel; // (0.5 to 2], given that it's not hostile if we're here
				}
			}
			
			if (weight > 0) {
				picker.add(market, weight);
			}
		}
		
		if (picker.isEmpty()) {
			endEvent();
			return;
		}
		
		market = picker.pick();
		faction = market.getFaction();
		eventTarget = new CampaignEventTarget(market);
	}
	
	private void initBountyAmount() {
		float highStabilityMult = BaseMarketConditionPlugin.getHighStabilityBonusMult(market);
		
		float base = Global.getSettings().getFloat("basePersonBounty");
		float perLevel = Global.getSettings().getFloat("personBountyPerLevel");
		
		float random = perLevel * (int)(Math.random() * 10) / 10f;
		
		bountyCredits = (int) ((base + perLevel * level + random) * highStabilityMult);
		payment = bountyCredits;
	}
	
	private void initPerson() {
		String factionId = Factions.PIRATES;
		if (bountyType == BountyType.DESERTER) {
			factionId = market.getFactionId();
		}
		int personLevel = (int) (5 + level * 1.5f);
		person = OfficerManagerEvent.createOfficer(Global.getSector().getFaction(factionId), 
												   personLevel);
	}
	
	private void pickBountyType() {
//		if (level >= 3) {
//			bountyType = BountyType.DESERTER;
//			return;	
//		}
//		bountyType = BountyType.PIRATE;
//		return;
		WeightedRandomPicker<BountyType> picker = new WeightedRandomPicker<BountyType>();
		picker.add(BountyType.PIRATE, 10f);
		
		if (data.getLevel() >= 3) {
			picker.add(BountyType.DESERTER, 30f);
		}
		bountyType = picker.pick();
	}
	
	private void initTargetDesc() {
		//targetDesc = person.getName().getFullName() + " is known to be a highly capable combat officer in command of a sizeable fleet.";
		
		ShipHullSpecAPI spec = fleet.getFlagship().getVariant().getHullSpec();
		String shipType = spec.getHullNameWithDashClass() + " " + spec.getDesignation().toLowerCase(); 

		String heOrShe = "he";
		String hisOrHer = "his";
		if (person.isFemale()) {
			heOrShe = "she";
			hisOrHer = "her";
		}
		
		String levelDesc = "";
		int personLevel = person.getStats().getLevel();
		if (personLevel <= 5) {
			levelDesc = "an unremarkable officer";
		} else if (personLevel <= 10) {
			levelDesc = "a capable officer";
		} else if (personLevel <= 15) {
			levelDesc = "a highly capable officer";
		} else {
			levelDesc = "an exceptionally capable officer";
		}
		
		String skillDesc = "";
		
		if (person.getStats().getSkillLevel(Skills.OFFICER_MANAGEMENT) > 0) {
			skillDesc = "having a high number of skilled subordinates";
		} else if (person.getStats().getSkillLevel(Skills.ELECTRONIC_WARFARE) > 0) {
			skillDesc = "being proficient in electronic warfare";
		} else if (person.getStats().getSkillLevel(Skills.FIGHTER_DOCTRINE) > 0) {
			skillDesc = "a noteworthy level of skill in running carrier operations";
		} else if (person.getStats().getSkillLevel(Skills.COORDINATED_MANEUVERS) > 0) {
			skillDesc = "a high effectiveness in coordinating the maneuvers of ships during combat";
		}
		
		if (!skillDesc.isEmpty() && levelDesc.contains("unremarkable")) {
			levelDesc = "an otherwise unremarkable officer";
		}
		
		String fleetDesc = "";
		if (level < 3) {
			fleetDesc = "small";
		} else if (level <= 5) {
			fleetDesc = "medium-sized";
		} else if (level <= 8) {
			fleetDesc = "large";
		} else {
			fleetDesc = "very large";
		}
		
		targetDesc = String.format("%s is in command of a %s fleet and was last seen using a %s as %s flagship.",
						person.getName().getFullName(), fleetDesc, shipType, hisOrHer);					
		
		if (skillDesc.isEmpty()) {
			targetDesc += String.format(" %s is known to be %s.", Misc.ucFirst(heOrShe), levelDesc);
		} else {
			targetDesc += String.format(" %s is %s known for %s.", Misc.ucFirst(heOrShe), levelDesc, skillDesc);
		}
		
		//targetDesc += "\n\nLevel: " + level;
	}

	public void advance(float amount) {
		if (!isEventStarted()) return;
		if (isDone()) return;
		
		float days = Global.getSector().getClock().convertToDays(amount);
		//days *= 60f;
		elapsedDays += days;

		if (elapsedDays >= duration && !isDone()) {
			boolean canEnd = fleet == null || !fleet.isInCurrentLocation();
			if (canEnd) {
				log.info(String.format("Ending bounty on %s by %s", person.getName().getFullName(), market.getName()));
				Global.getSector().reportEventStage(this, "expire_end", messagePriority);
				endEvent();
			}
		}
		
		if (fleet.isInCurrentLocation() && !fleet.getFaction().getId().equals(Factions.PIRATES)) {
			fleet.setFaction(Factions.PIRATES, true);
		} else if (!fleet.isInCurrentLocation() && !fleet.getFaction().getId().equals(Factions.NEUTRAL)) {
			fleet.setFaction(Factions.NEUTRAL, true);
		}
		
		if (fleet.getFlagship() == null || fleet.getFlagship().getCaptain() != person) {
			Global.getSector().reportEventStage(this, "other_end", market.getPrimaryEntity(), messagePriority);
			endEvent();	
		}
	}
	
	private boolean ended = false;

	private void endEvent() {
		data.reportEnded();
		ended = true;
		
		if (fleet != null) {
			Misc.makeUnimportant(fleet, "pbe");
			fleet.clearAssignments();
			if (hideoutLocation != null) {
				fleet.getAI().addAssignment(FleetAssignment.GO_TO_LOCATION_AND_DESPAWN, hideoutLocation, 1000000f, null);
			} else {
				fleet.despawn();
			}
		}
	}

	public boolean isDone() {
		return ended;
	}

	public Map<String, String> getTokenReplacements() {
		Map<String, String> map = super.getTokenReplacements();
		// this is ok because the token replacement happens right as the message is sent, not when it's received
		// so the lastBounty is the correct value for the message
		//map.put("$bountyCredits", "" + (int) payment);
		map.put("$bountyCredits", Misc.getWithDGS(payment));
		map.put("$sender", faction.getDisplayName());
		
		map.put("$daysLeft", "" + (int) + Math.max(1, duration - elapsedDays));
		map.put("$targetName", person.getName().getFullName());
		if (targetDesc != null) {
			map.put("$targetDesc", targetDesc);
		}
		
		if (hideoutLocation != null) {
			if (hideoutLocation.getContainingLocation() instanceof StarSystemAPI) {
				map.put("$hideoutSystem", ((StarSystemAPI)hideoutLocation.getContainingLocation()).getBaseName());
			}
			
			SectorEntityToken fake = hideoutLocation.getContainingLocation().createToken(0, 0);
			fake.setOrbit(Global.getFactory().createCircularOrbit(hideoutLocation, 0, 1000, 100));
			
			map.put("$hideout", hideoutLocation.getName());
			String loc = BreadcrumbSpecial.getLocatedString(fake);
			loc = loc.replaceAll("orbiting", "hiding out near");
			loc = loc.replaceAll("located in", "hiding out in");
			map.put("$hideoutCrumb", loc);
		}
		
		return map;
	}

	@Override
	public String[] getHighlights(String stageId) {
		
		List<String> result = new ArrayList<String>();
		addTokensToList(result, "$bountyCredits");
		
		if (stageId != null && stageId.startsWith("start_")) {
			addTokensToList(result, "$daysLeft");
		}
		
		return result.toArray(new String[0]);
	}

	@Override
	public String getEventName() {
//		String locName = market.getContainingLocation().getName();
//		if (market.getContainingLocation() instanceof StarSystemAPI) {
//			locName = ((StarSystemAPI)market.getContainingLocation()).getBaseName();
//		}
//		locName = ((StarSystemAPI)hideoutLocation.getContainingLocation()).getBaseName();
//		String factionName = market.getFaction().getDisplayName();
//		String text = locName + ", " + factionName + "";
//		//String text = "Wanted by " + factionName + "";
//		if (isDone()) {
//			return text + " - over";
//		}
//		int daysLeft = (int) (duration - elapsedDays);
//		String days = "";
//		if (daysLeft > 0) {
//			days = ", " + daysLeft + "d";
//		} else {
//			days = ", <1d";
//		}
//		return text + " - " + (int) bountyCredits + Strings.C + days;
		
		if (isDone()) {
			return "" + person.getName().getFullName() + " - over";
		}
		int daysLeft = (int) (duration - elapsedDays);
		String days = "";
		if (daysLeft > 0) {
			days = ", " + daysLeft + "d";
		} else {
			days = ", <1d";
		}
		return "" + person.getName().getFullName() + " - " + Misc.getWithDGS(bountyCredits) + Strings.C + days;
	}
	

	@Override
	public CampaignEventCategory getEventCategory() {
		return CampaignEventCategory.BOUNTY;
	}
	
	@Override
	public String getCurrentMessageIcon() {
		return person.getPortraitSprite();
	}
	
	@Override
	public String getCurrentImage() {
		return person.getPortraitSprite();
	}
	
	public String getEventIcon() {
		return person.getPortraitSprite();
		//return market.getFaction().getCrest();
	}

	private float payment = 0;
	@Override
	public void reportBattleOccurred(CampaignFleetAPI primaryWinner, BattleAPI battle) {
		if (!isEventStarted()) return;
		if (isDone()) return;
		
		if (battle.isInvolved(fleet) && !battle.isPlayerInvolved()) {
			if (fleet.getFlagship() == null || fleet.getFlagship().getCaptain() != person) {
				fleet.setCommander(fleet.getFaction().createRandomPerson());
				Global.getSector().reportEventStage(this, "other_end", market.getPrimaryEntity(), messagePriority);
				endEvent();
				return;
			}
		}
		
		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		if (!battle.isPlayerInvolved() || !battle.isInvolved(fleet) || battle.onPlayerSide(fleet)) {
			return;
		}
		
		 // didn't destroy the original flagship
		if (fleet.getFlagship() != null && fleet.getFlagship().getCaptain() == person) return;
		
		RepLevel level = playerFleet.getFaction().getRelationshipLevel(market.getFaction());
		//final int payment = (int) (bountyCredits * battle.getPlayerInvolvementFraction());
		payment = (int) (bountyCredits * battle.getPlayerInvolvementFraction());
		if (payment <= 0) return;
		
		if (level.isAtWorst(RepLevel.SUSPICIOUS)) {
			String reportId = "bounty_payment_end";
			if (battle.getPlayerInvolvementFraction() < 1) {
				reportId = "bounty_payment_share_end";
			}
			log.info(String.format("Paying bounty of %d from faction [%s]", (int) payment, faction.getDisplayName()));
			Global.getSector().reportEventStage(this, reportId, market.getPrimaryEntity(),
										MessagePriority.ENSURE_DELIVERY,
						new BaseOnMessageDeliveryScript() {
				public void beforeDelivery(CommMessageAPI message) {
					CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
					playerFleet.getCargo().getCredits().add(payment);
					Global.getSector().adjustPlayerReputation(
							new RepActionEnvelope(RepActions.PERSON_BOUNTY_REWARD, null, message, true), 
							faction.getId());
				}
			});
		} else if (level.isAtWorst(RepLevel.HOSTILE)) {
			log.info(String.format("Not paying bounty, but improving rep with faction [%s]", faction.getDisplayName()));
			Global.getSector().reportEventStage(this, "bounty_no_payment_end", market.getPrimaryEntity(),
										MessagePriority.ENSURE_DELIVERY,
						new BaseOnMessageDeliveryScript() {
				public void beforeDelivery(CommMessageAPI message) {
					Global.getSector().adjustPlayerReputation(
							new RepActionEnvelope(RepActions.PERSON_BOUNTY_REWARD, null, message, true), 
							faction.getId());
				}
			});
		} else {
			log.info(String.format("Not paying bounty or improving rep with faction [%s]", faction.getDisplayName()));
			Global.getSector().reportEventStage(this, "bounty_no_rep_end", market.getPrimaryEntity(),
										MessagePriority.ENSURE_DELIVERY);
		}
		
		data.reportSuccess();
		endEvent();
	}

	@Override
	public void reportFleetDespawned(CampaignFleetAPI fleet, FleetDespawnReason reason, Object param) {
		if (isDone()) return;
		
		if (this.fleet == fleet) {
			fleet.setCommander(fleet.getFaction().createRandomPerson());
			Global.getSector().reportEventStage(this, "other_end", market.getPrimaryEntity(), messagePriority);
			endEvent();
		}
	}
	
	
	private void spawnFleet() {
		String fleetFactionId = Factions.PIRATES;
		if (bountyType == BountyType.DESERTER) {
			fleetFactionId = market.getFactionId();
		}
		
		float qf = (float) level / 10f;
		if (qf > 1) qf = 1;
		
		String fleetName = "";
//		if (bountyType == BountyType.PIRATE) {
//			fleetName = person.getName().getLast() + "'s" + " Armada";
//		} else {
//			fleetName = person.getName().getLast() + "'s" + " Free Company";
//		}
		fleetName = person.getName().getLast() + "'s" + " Fleet";
		
		fleet = FleetFactoryV2.createFleet(new FleetParams(
				hideoutLocation.getLocationInHyperspace(),
				null, 
				fleetFactionId,
				FleetTypes.PERSON_BOUNTY_FLEET,
				5 + level * 4, // combatPts
				0f, // freighterPts 
				0f, // tankerPts
				0f, // transportPts
				0f, // linerPts
				0f, // civilianPts 
				0f, // utilityPts
				qf, // qualityBonus
				-1f, // qualityOverride
				1f + (float) level / 10f, // officer num mult
				(int) level, // officer level bonus
				person,
				person.getStats().getLevel()
				));
		if (fleet == null) {
			endEvent();
			return;
		}

		FleetFactoryV2.addCommanderSkills(person, fleet, null);
		
		//Misc.getSourceMarket(fleet).getStats().getDynamic().getValue(Stats.OFFICER_LEVEL_MULT);
		
		Misc.makeImportant(fleet, "pbe", duration);
		fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_PIRATE, true);
		fleet.setNoFactionInName(true);
		fleet.setFaction(Factions.NEUTRAL, true);
		fleet.setName(fleetName);

		
		LocationAPI location = hideoutLocation.getContainingLocation();
		location.addEntity(fleet);
		fleet.setLocation(hideoutLocation.getLocation().x - 500, hideoutLocation.getLocation().y + 500);
		fleet.getAI().addAssignment(FleetAssignment.ORBIT_AGGRESSIVE, hideoutLocation, 1000000f, null);
	}
	
}






