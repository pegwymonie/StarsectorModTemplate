package com.fs.starfarer.api.impl.campaign.econ;

import com.fs.starfarer.api.impl.campaign.ids.Commodities;

public class ShipbreakingCenter extends BaseMarketConditionPlugin {

	public void apply(String id) {
		
		//market.getDemand(Commodities.REGULAR_CREW).getDemand().modifyFlat(id, ConditionData.SHIPBREAKING_CREW);
		//market.getDemand(Commodities.REGULAR_CREW).getNonConsumingDemand().modifyFlat(id, ConditionData.SHIPBREAKING_CREW * ConditionData.CREW_MARINES_NON_CONSUMING_FRACTION);
		float crewDemandMet = getCrewDemandMet(market);

		float productionMult = crewDemandMet;
		
		market.getCommodityData(Commodities.HEAVY_MACHINERY).getSupply().modifyFlat(id, ConditionData.SHIPBREAKING_MACHINERY * productionMult);
		market.getCommodityData(Commodities.SUPPLIES).getSupply().modifyFlat(id, ConditionData.SHIPBREAKING_SUPPLIES * productionMult);
		market.getCommodityData(Commodities.METALS).getSupply().modifyFlat(id, ConditionData.SHIPBREAKING_METALS * productionMult);
		market.getCommodityData(Commodities.RARE_METALS).getSupply().modifyFlat(id, ConditionData.SHIPBREAKING_RARE_METALS * productionMult);
	}

	public void unapply(String id) {
		
//		market.getDemand(Commodities.REGULAR_CREW).getDemand().unmodify(id);
//		market.getDemand(Commodities.REGULAR_CREW).getNonConsumingDemand().unmodify(id);
		
		market.getCommodityData(Commodities.HEAVY_MACHINERY).getSupply().unmodify(id);
		market.getCommodityData(Commodities.SUPPLIES).getSupply().unmodify(id);
		market.getCommodityData(Commodities.METALS).getSupply().unmodify(id);
		market.getCommodityData(Commodities.RARE_METALS).getSupply().unmodify(id);
	}

}
