package com.fs.starfarer.api.impl.campaign.fleets;

import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.FleetAssignment;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactory.MercType;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;

public class BountyPirateFleetManager extends PlayerVisibleFleetManager {

	public static final String KEY_SYSTEM = "$bountySystem";
	public static final float MAX_RANGE_FROM_PLAYER_LY = 2f;
	
	protected IntervalUtil tracker2 = new IntervalUtil(0.75f, 1.25f);;
	
	protected Object readResolve() {
		super.readResolve();
		if (tracker2 == null) {
			tracker2 = new IntervalUtil(0.75f, 1.25f);
		}
		return this;
	}
		
	@Override
	protected int getMaxFleets() {
		if (currPlayerLoc == null || currPlayerLoc.isHyperspace()) {
			return 0;
		}
		if (Global.getSector().getPlayerFleet() == null) return 0;

		float bountyMarketSizeTotal = 0f;
		for (MarketAPI market : Misc.getMarketsInLocation(currPlayerLoc)) {
			if (market.getFactionId().equals(Factions.PIRATES)) continue;
			if (market.hasCondition(Conditions.EVENT_SYSTEM_BOUNTY)) {
				bountyMarketSizeTotal += market.getSize();
			}
		}
		
		return (int) Math.ceil(bountyMarketSizeTotal * 1.25f);
	}

	
	
	@Override
	protected boolean isOkToDespawnAssumingNotPlayerVisible(CampaignFleetAPI fleet) {
		if (currPlayerLoc == null) return true;
		String system = fleet.getMemoryWithoutUpdate().getString(KEY_SYSTEM);
		return system == null || !system.equals(currPlayerLoc.getName());
	}
	
	protected StarSystemAPI currPlayerLoc = null;
	
	@Override
	public void advance(float amount) {
		super.advance(amount);
		
		CampaignFleetAPI player = Global.getSector().getPlayerFleet();
		if (player == null) return;
		
		float days = Global.getSector().getClock().convertToDays(amount);
		tracker2.advance(days);
		if (tracker2.intervalElapsed()) {
			StarSystemAPI nearest = getNearbySystemWithBounty();
			if (nearest != currPlayerLoc) {
				currPlayerLoc = nearest;
			}
		}
	}
	
	
	protected StarSystemAPI getNearbySystemWithBounty() {
		CampaignFleetAPI player = Global.getSector().getPlayerFleet();
		if (player == null) return null;
		StarSystemAPI nearest = null;
		float maxDist = Float.MAX_VALUE;
		for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
			float distToPlayerLY = Misc.getDistanceLY(player.getLocationInHyperspace(), market.getLocationInHyperspace());
			if (distToPlayerLY > MAX_RANGE_FROM_PLAYER_LY) continue;
			
			if (distToPlayerLY < maxDist && market.hasCondition(Conditions.EVENT_SYSTEM_BOUNTY) && market.getStarSystem() != null) {
				nearest = market.getStarSystem();
				maxDist = distToPlayerLY;
			}
		}
		return nearest;
	}



	@Override
	protected CampaignFleetAPI spawnFleet() {
		StarSystemAPI system = currPlayerLoc;
		if (system == null) return null;
		
		CampaignFleetAPI player = Global.getSector().getPlayerFleet();
		if (player == null) return null;
		float distToPlayerLY = Misc.getDistanceLY(player.getLocationInHyperspace(), system.getLocation());
		if (distToPlayerLY > 1f) return null;
		
		WeightedRandomPicker<MercType> picker = new WeightedRandomPicker<MercType>();
		picker.add(MercType.SCOUT, 10f); 
		picker.add(MercType.BOUNTY_HUNTER, 10f); 
		picker.add(MercType.PRIVATEER, 10f); 
		picker.add(MercType.PATROL, 10f); 
		picker.add(MercType.ARMADA, 3f); 
		
		MercType type = picker.pick();
		
		
		float combat = 0f;
		float tanker = 0f;
		float freighter = 0f;
		String fleetType = type.fleetType;
		switch (type) {
		case SCOUT:
			combat = Math.round(1f + (float) Math.random() * 2f);
			break;
		case PRIVATEER:
		case BOUNTY_HUNTER:
			combat = Math.round(3f + (float) Math.random() * 2f);
			break;
		case PATROL:
			combat = Math.round(9f + (float) Math.random() * 3f);
			break;
		case ARMADA:
			combat = Math.round(12f + (float) Math.random() * 8f);
			break;
		}
		
		CampaignFleetAPI fleet = FleetFactoryV2.createFleet(new FleetParams(
				system.getLocation(), // location
				null, // market
				Factions.PIRATES,
				null, // fleet's faction, if different from above, which is also used for source market picking
				fleetType,
				combat, // combatPts
				freighter, // freighterPts 
				tanker, // tankerPts
				0f, // transportPts
				0f, // linerPts
				0f, // civilianPts 
				0f, // utilityPts
				0f, // qualityBonus
				-1f, // qualityOverride
				1f, // officer num mult
				0 // officer level bonus
				));
		if (fleet == null) return null;
		
		fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_PIRATE, true);
		
		MarketAPI source = Misc.getSourceMarket(fleet);
		if (source == null) return null;
		
		//CampaignFleetAPI player = Global.getSector().getPlayerFleet();

		if ((float) Math.random() > 0.5f) {
			Vector2f loc = Misc.pickHyperLocationNotNearPlayer(system.getLocation(), Global.getSettings().getMaxSensorRange() + 500f);
			Global.getSector().getHyperspace().addEntity(fleet);
			fleet.setLocation(loc.x, loc.y);
			
			Vector2f dest = Misc.getPointAtRadius(system.getLocation(), 1500);
			LocationAPI hyper = Global.getSector().getHyperspace();
			SectorEntityToken token = hyper.createToken(dest.x, dest.y);
			fleet.addAssignment(FleetAssignment.GO_TO_LOCATION, token, 1000,
					"travelling to the " + system.getBaseName() + " star system");
			
			if ((float) Math.random() > 0.75f) {
				fleet.addAssignment(FleetAssignment.RAID_SYSTEM, system.getHyperspaceAnchor(), 20,
						"raiding around the " + system.getBaseName() + " star system");
			} else {
				fleet.addAssignment(FleetAssignment.RAID_SYSTEM, system.getCenter(), 20,
						"raiding the " + system.getBaseName() + " star system");
			}
		} else {
			Vector2f loc = Misc.pickLocationNotNearPlayer(system, 
					Misc.getPointAtRadius(new Vector2f(0, 0), 8000),
					Global.getSettings().getMaxSensorRange() + 500f);
			system.addEntity(fleet);
			fleet.setLocation(loc.x, loc.y);
			
			fleet.addAssignment(FleetAssignment.RAID_SYSTEM, system.getCenter(), 30,
					"raiding the " + system.getBaseName() + " star system");
		}
		

		fleet.addAssignment(FleetAssignment.GO_TO_LOCATION, source.getPrimaryEntity(), 1000,
					"returning to " + source.getName());
		fleet.addAssignment(FleetAssignment.ORBIT_PASSIVE, source.getPrimaryEntity(), 2f + 2f * (float) Math.random(),
					"offloading ill-gotten goods");
		fleet.addAssignment(FleetAssignment.GO_TO_LOCATION_AND_DESPAWN, source.getPrimaryEntity(), 1000);
		
		fleet.getMemoryWithoutUpdate().set(KEY_SYSTEM, system.getName());
		return fleet;
	}
	
}















