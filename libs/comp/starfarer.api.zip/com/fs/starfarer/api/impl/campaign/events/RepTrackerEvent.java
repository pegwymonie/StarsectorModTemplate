package com.fs.starfarer.api.impl.campaign.events;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BaseOnMessageDeliveryScript;
import com.fs.starfarer.api.campaign.BattleAPI;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.campaign.SubmarketPlugin;
import com.fs.starfarer.api.campaign.ReputationActionResponsePlugin.ReputationAdjustmentResult;
import com.fs.starfarer.api.campaign.comm.CommMessageAPI;
import com.fs.starfarer.api.campaign.comm.MessagePriority;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.SubmarketAPI;
import com.fs.starfarer.api.campaign.events.CampaignEventManagerAPI;
import com.fs.starfarer.api.campaign.events.CampaignEventTarget;
import com.fs.starfarer.api.campaign.events.EventProbabilityAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.RepActionEnvelope;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.RepActions;
import com.fs.starfarer.api.impl.campaign.ids.Events;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.shared.PlayerTradeDataForSubmarket;
import com.fs.starfarer.api.impl.campaign.shared.PlayerTradeProfitabilityData;
import com.fs.starfarer.api.impl.campaign.shared.ReputationChangeTracker;
import com.fs.starfarer.api.impl.campaign.shared.SharedData;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;

/**
 * Trade, time-based rep decay, rep from combat w/ enemies of faction fought against.
 * 
 * @author Alex Mosolov
 *
 * Copyright 2014 Fractal Softworks, LLC
 */
public class RepTrackerEvent extends BaseEventPlugin {
	public static Logger log = Global.getLogger(RepTrackerEvent.class);
	
	public static class FactionTradeRepData {
		public float currVolumePerPoint = Global.getSettings().getFloat("economyPlayerTradeVolumeForRepChangeMin");
		
		public float [] getRepPointsAndVolumeUsedFor(float volume) {
			float max = Global.getSettings().getFloat("economyPlayerTradeVolumeForRepChangeMax");
			float incr = Global.getSettings().getFloat("economyPlayerTradeVolumeForRepChangeIncr");
			float points = 0;
			
			float used = 0;
			
			while (volume >= currVolumePerPoint) {
				points++;
				used += currVolumePerPoint;
				volume -= currVolumePerPoint;
				
				if (currVolumePerPoint < max) currVolumePerPoint += incr;
				if (currVolumePerPoint > max) currVolumePerPoint = max;
			}
			return new float [] {points, used};
		}
	}
	
	
	private IntervalUtil tracker;
	private IntervalUtil repDecayTracker;
	private IntervalUtil factionChannelTracker;
	private Map<String, FactionTradeRepData> repData = new HashMap<String, FactionTradeRepData>();
	
	public void init(String type, CampaignEventTarget eventTarget) {
		super.init(type, eventTarget);
		readResolve();
	}
	
	Object readResolve() {
		if (repDecayTracker == null) {
			repDecayTracker = new IntervalUtil(130f, 170f);
		}
		if (tracker == null) {
			tracker = new IntervalUtil(3f, 7f);
		}
		if (factionChannelTracker == null) {
			factionChannelTracker = new IntervalUtil(2f, 4f);
		}
		return this;
	}
	
	public void startEvent() {
		super.startEvent();
	}
	
	private float [] getRepPointsAndVolumeUsedFor(float volume, FactionAPI faction) {
		FactionTradeRepData data = repData.get(faction.getId());
		if (data == null) {
			data = new FactionTradeRepData();
			repData.put(faction.getId(), data);
		}
		return data.getRepPointsAndVolumeUsedFor(volume);
	}
	
	public void advance(float amount) {
		if (!isEventStarted()) return;
		if (isDone()) return;
		
		float days = Global.getSector().getClock().convertToDays(amount);
		
		tracker.advance(days);
		if (tracker.intervalElapsed()) {
			for (FactionAPI faction : Global.getSector().getAllFactions()) {
			//List<FactionAPI> factions = Global.getSector().getAllFactions();
			//FactionAPI faction = factions.get(new Random().nextInt(factions.size()));
				if (!faction.isPlayerFaction() && !faction.isNeutralFaction()) {
					checkForTradeReputationChanges(faction);
				}
			}
			checkForXPGain();
		}
		
//		repDecayTracker.advance(days);
//		if (repDecayTracker.intervalElapsed()) {
//			checkForRepDecay();
//		}
		
		factionChannelTracker.advance(days);
		if (factionChannelTracker.intervalElapsed()) {
			checkForChannelAccess();
		}
	}
	
	
	private void checkForChannelAccess() {
		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		
		for (final FactionAPI faction : Global.getSector().getAllFactions()) {
			if (faction.isPlayerFaction()) continue;
		
			RepLevel level = faction.getRelationshipLevel(Factions.PLAYER);
			final String channelId = faction.getInternalCommsChannel();
			
//			if (faction.getId().equals(Factions.HEGEMONY)) {
//				System.out.println("1223rsdfd");
//			}
			
			if (channelId == null || channelId.isEmpty()) continue;
			
			if (level.isAtWorst(RepLevel.COOPERATIVE)) {
				if (Global.getSector().getCharacterData().getCommChannels().contains(channelId)) continue;

				MarketAPI market = Misc.findNearestLocalMarket(playerFleet, 100000f, new MarketFilter() {
					public boolean acceptMarket(MarketAPI curr) {
						return curr.getFaction() == faction;
					}
				});
				if (market == null || market.getFaction() != faction) continue;
				tempTarget = new CampaignEventTarget(market);
				
				Global.getSector().reportEventStage(this, "comm_access_granted", playerFleet, MessagePriority.ENSURE_DELIVERY,
						new BaseOnMessageDeliveryScript() {
					boolean deliver = true;
					public void beforeDelivery(CommMessageAPI message) {
						if (Global.getSector().getCharacterData().getCommChannels().contains(channelId)) {
							deliver = false;
						} else {
							Global.getSector().getCharacterData().addCommChannel(channelId);
							message.addTag(Tags.REPORT_REP);
							message.getCustomMap().put(CommMessageAPI.MESSAGE_FACTION_ID_KEY, faction.getId());
						}
					}
					@Override
					public boolean shouldDeliver() {
						return deliver;
					}
				});
			} else if (level.isAtBest(RepLevel.WELCOMING)) {
				if (!Global.getSector().getCharacterData().getCommChannels().contains(channelId)) continue;
				
				MarketAPI market = null;
				for (MarketAPI curr : Global.getSector().getEconomy().getMarketsCopy()) {
					if (curr.getFaction().getId().equals(faction.getId())) {
						market = curr;
						break;
					}
				}
				
				if (market == null || market.getFaction() != faction) continue;
				tempTarget = new CampaignEventTarget(market);
				
				Global.getSector().reportEventStage(this, "comm_access_revoked", playerFleet, MessagePriority.ENSURE_DELIVERY,
						new BaseOnMessageDeliveryScript() {
					boolean deliver = true;
					public void beforeDelivery(CommMessageAPI message) {
						if (!Global.getSector().getCharacterData().getCommChannels().contains(channelId)) {
							deliver = false;
						} else {
							Global.getSector().getCharacterData().removeCommChannel(channelId);
							message.addTag(Tags.REPORT_REP);
							message.getCustomMap().put(CommMessageAPI.MESSAGE_FACTION_ID_KEY, faction.getId());
						}
					}
					@Override
					public boolean shouldDeliver() {
						return deliver;
					}
				});
			}
		}
	}
	
	
	
	private void checkForRepDecay() {
		ReputationChangeTracker rct = SharedData.getData().getPlayerActivityTracker().getRepChangeTracker();
		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		FactionAPI player = Global.getSector().getFaction(Factions.PLAYER); 
		for (final FactionAPI faction : Global.getSector().getAllFactions()) {
			if (faction.isPlayerFaction()) continue;
			float sinceLastChange = rct.getDaysSinceLastNegativeChange(faction.getId());
			if (sinceLastChange < 180f) continue;

			factionString = faction.getDisplayNameWithArticle();
			RepLevel level = faction.getRelationshipLevel(player);
			if (level.isNegative() && level.isAtWorst(RepLevel.INHOSPITABLE)) {
				Global.getSector().reportEventStage(this, "rep_decay_positive", playerFleet, MessagePriority.ENSURE_DELIVERY,
					new BaseOnMessageDeliveryScript() {
						boolean deliver = true;
						public void beforeDelivery(CommMessageAPI message) {
							ReputationAdjustmentResult result = Global.getSector().adjustPlayerReputation(
									new RepActionEnvelope(RepActions.REP_DECAY_POSITIVE, null, message, false), 
									faction.getId());
							deliver = result.delta != 0;
						}
						@Override
						public boolean shouldDeliver() {
							return deliver;
						}
				});
			}
		}
		factionString = null;
	}
	
	
	private long xpGain = 0;
	private void checkForXPGain() {
		PlayerTradeProfitabilityData data = SharedData.getData().getPlayerActivityTracker().getProfitabilityData();
		final long gain = data.getAccruedXP();
		//final long gain = 1000;
		if (gain > 0) {
			data.setAccruedXP(0);
			xpGain = gain;
			CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
			Global.getSector().reportEventStage(this, "trade_xp_gain", playerFleet, MessagePriority.ENSURE_DELIVERY,
				new BaseOnMessageDeliveryScript() {
					public void beforeDelivery(CommMessageAPI message) {
						Global.getSector().getCharacterData().getPerson().getStats().addXP(gain);
					}
			});
		}
	}
	
	
	public static class MarketTradeInfo {
		public MarketAPI market;
		public float tradeTotal;
		public float smugglingTotal;
	}
	
	private String marketListString = null;
	private String factionString = null;
	private CampaignEventTarget tempTarget = null;
	private void checkForTradeReputationChanges(final FactionAPI faction) {
		tempTarget = null;
		factionString = null;
		marketListString = null;
		
		
//		SubmarketAPI sub = null;
//		sub = Global.getSector().getEconomy().getMarket("salamanca").getSubmarket(Submarkets.SUBMARKET_OPEN);
//		SharedData.getData().getPlayerActivityTracker().getPlayerTradeData(sub).setAccumulatedPlayerTradeValueForPositive(1000000f);
//		SharedData.getData().getPlayerActivityTracker().getPlayerTradeData(sub).setAccumulatedPlayerTradeValueForNegative(1000000f);
//		
//		sub = Global.getSector().getEconomy().getMarket("qaras").getSubmarket(Submarkets.SUBMARKET_OPEN);
//		SharedData.getData().getPlayerActivityTracker().getPlayerTradeData(sub).setAccumulatedPlayerTradeValueForPositive(1000000f);
//		SharedData.getData().getPlayerActivityTracker().getPlayerTradeData(sub).setAccumulatedPlayerTradeValueForNegative(1000000f);
		
		float playerTradeVolume = 0;
		float playerSmugglingVolume = 0;
		
		final List<MarketTradeInfo> info = new ArrayList<MarketTradeInfo>();
		for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
			//if (market.getFaction() != faction) continue;
			
//			if (faction.getId().equals("hegemony")) {
//				System.out.println("23dsfsdf");
//			}
			
			//boolean isFactionInvolved = market.getFaction() == faction;
			
			MarketTradeInfo curr = new MarketTradeInfo();
			curr.market = market;
			
			for (SubmarketAPI submarket : market.getSubmarketsCopy()) {
				SubmarketPlugin plugin = submarket.getPlugin();
				if (!plugin.isParticipatesInEconomy()) continue;
				
				//isFactionInvolved |= submarket.getFaction() == faction;
				
				PlayerTradeDataForSubmarket tradeData =  SharedData.getData().getPlayerActivityTracker().getPlayerTradeData(submarket);
				
				//if (plugin.isBlackMarket()) {
				if (market.getFaction() == faction && (submarket.getFaction().isHostileTo(faction) || submarket.getPlugin().isBlackMarket())) {
					curr.smugglingTotal += tradeData.getAccumulatedPlayerTradeValueForNegative();
				} else if (submarket.getFaction() == faction) {
					curr.tradeTotal += tradeData.getAccumulatedPlayerTradeValueForPositive();
				}
			}
			
			//if (!isFactionInvolved) continue;
			if (curr.tradeTotal == 0 && curr.smugglingTotal == 0) continue;
			
			info.add(curr);
			
			playerTradeVolume += curr.tradeTotal;
			playerSmugglingVolume += curr.smugglingTotal;
			
			if (tempTarget == null && (playerTradeVolume > 0 || playerSmugglingVolume > 0)) {
				tempTarget = new CampaignEventTarget(market);
			}
		}
		
//		if (faction.getId().equals("pirates")) {
//			System.out.println("23dsfsdf");
//		}
		
		float [] repPlus = getRepPointsAndVolumeUsedFor(playerTradeVolume, faction);
		float [] repMinus = getRepPointsAndVolumeUsedFor(playerSmugglingVolume, faction);
		final float repChange = repPlus[0] - repMinus[0];
		
		if (Math.abs(repChange) < 1) {
			log.info("Not enough trade/smuggling with " + faction.getDisplayNameWithArticle() + " for a rep change (" + playerTradeVolume + ", " + playerSmugglingVolume + ")");
			return;
		}

		log.info("Sending rep change of " + repChange + " with " + faction.getDisplayNameWithArticle() + " due to trade/smuggling");
		
		float tradeUsed = repPlus[1];
		float smugglingUsed = repMinus[1];
		
		// remove the player trade volume used for the rep change from the accumulated volume
		for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
			//if (market.getFaction() != faction) continue;
			for (SubmarketAPI submarket : market.getSubmarketsCopy()) {
				SubmarketPlugin plugin = submarket.getPlugin();
				if (!plugin.isParticipatesInEconomy()) continue;
				
				if (market.getFaction() != faction && submarket.getFaction() != faction) {
					continue;
				}
				
				PlayerTradeDataForSubmarket tradeData = SharedData.getData().getPlayerActivityTracker().getPlayerTradeData(submarket);
				
				//if (playerTradeVolume > 0 && !plugin.isBlackMarket()) {
				if (playerSmugglingVolume > 0 && market.getFaction() == faction && (submarket.getFaction().isHostileTo(faction) || submarket.getPlugin().isBlackMarket())) {
					float value = tradeData.getAccumulatedPlayerTradeValueForNegative();
					tradeData.setAccumulatedPlayerTradeValueForNegative(value - smugglingUsed * value / playerSmugglingVolume);
				} else if (playerTradeVolume > 0 && submarket.getFaction() == faction) {
					float value = tradeData.getAccumulatedPlayerTradeValueForPositive();
					tradeData.setAccumulatedPlayerTradeValueForPositive(value - tradeUsed * value / playerTradeVolume);
				}
			}
		}
		
		
		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();

		factionString = faction.getDisplayNameWithArticle();
		
		if (repChange > 0) {
			Collections.sort(info, new Comparator<MarketTradeInfo>() {
				public int compare(MarketTradeInfo o1, MarketTradeInfo o2) {
					return (int) (o2.tradeTotal - o1.tradeTotal);
				}
			});
			tempTarget = new CampaignEventTarget(info.get(0).market);
			List<String> strings = new ArrayList<String>();
			for (int i = 0; i < info.size() && i < 3; i++) {
				strings.add(info.get(i).market.getName());
			}
			marketListString = Misc.getAndJoined(strings.toArray(new String[0]));
			
			final RepActions action = RepActions.TRADE_EFFECT;
			Global.getSector().reportEventStage(this, "trade_rep", playerFleet, MessagePriority.ENSURE_DELIVERY,
				new BaseOnMessageDeliveryScript() {
					boolean deliver = true;
					public void beforeDelivery(CommMessageAPI message) {
						ReputationAdjustmentResult result = Global.getSector().adjustPlayerReputation(
								new RepActionEnvelope(action, new Float(Math.abs(repChange)), message, false), 
								faction.getId());
						deliver = result.delta != 0;
						//trade_no_change
						if (result.delta == 0) {
							
						}
					}
					@Override
					public boolean shouldDeliver() {
						return deliver;
					}
			});
			causeNegativeRepChangeWithEnemies(info);
		} else if (repChange < 0) {
			Collections.sort(info, new Comparator<MarketTradeInfo>() {
				public int compare(MarketTradeInfo o1, MarketTradeInfo o2) {
					return (int) (o2.smugglingTotal - o1.smugglingTotal);
				}
			});
			tempTarget = new CampaignEventTarget(info.get(0).market);
			
			List<String> strings = new ArrayList<String>();
			for (int i = 0; i < info.size() && i < 3; i++) {
				strings.add(info.get(i).market.getName());
			}
			marketListString = Misc.getAndJoined(strings.toArray(new String[0]));
			
			WeightedRandomPicker<MarketAPI> picker = new WeightedRandomPicker<MarketAPI>();
			for (MarketTradeInfo curr : info) {
				picker.add(curr.market, curr.smugglingTotal);
			}
			final MarketAPI investigationMarket = picker.pick();
			
			final RepActions action = RepActions.SMUGGLING_EFFECT;
			//Global.getSector().reportEventStage(this, "smuggling_rep", playerFleet, MessagePriority.ENSURE_DELIVERY,
			Global.getSector().reportEventStage(this, "smuggling_rep", playerFleet, MessagePriority.ENSURE_DELIVERY,
				new BaseOnMessageDeliveryScript() {
					boolean deliver = true;
					public void beforeDelivery(CommMessageAPI message) {
						ReputationAdjustmentResult result = Global.getSector().adjustPlayerReputation(
								new RepActionEnvelope(action, new Float(Math.abs(repChange)), message, false), 
								faction.getId());
						deliver = result.delta != 0;

						// "overflow" rep increases investigation chance
						if (deliver == false && false) {
							CampaignEventManagerAPI manager = Global.getSector().getEventManager();
							EventProbabilityAPI ep = manager.getProbability(Events.INVESTIGATION_SMUGGLING, investigationMarket);
							float increase = Math.abs(repChange) * 0.01f * 10;
							ep.increaseProbability(increase);
							log.info("Increasing smuggling investigation (due to failed smuggling rep change) probability for " + investigationMarket.getName() + " by " + increase + ", is now " + ep.getProbability());
						}
					}
					@Override
					public boolean shouldDeliver() {
						return deliver;
					}
			});
			causeNegativeRepChangeWithEnemies(info);
		}
	}
	
	
	private String theHostileFaction = null;
	private String pickedMarket = null;
	private String hostileMarket = null;
	
	public void causeNegativeRepChangeWithEnemies(List<MarketTradeInfo> info) {
		theHostileFaction = null;
		pickedMarket = null;
		hostileMarket = null;
		
//		float volumeForRepChange = Global.getSettings().getFloat("economyPlayerTradeVolumeForRepChange");
		//float maxRange = Global.getSettings().getFloat("economyMaxRangeForNegativeRepChangeLY");
		int maxToSend = 3;
		int sent = 0;
		for (final MarketTradeInfo curr : info) {
			float actionableTotal = curr.tradeTotal * 2f + curr.smugglingTotal * 0.5f;
			//float repMinus = (float) Math.floor(actionableTotal / volumeForRepChange);
			List<FactionAPI> factions = new ArrayList<FactionAPI>(Global.getSector().getAllFactions());
			Collections.shuffle(factions);
			for (final FactionAPI faction : factions) {
				// pirates don't get mad about you trading with someone else
				//if (faction.getId().equals(Factions.PIRATES)) {
				if (faction.getCustom().optBoolean(Factions.CUSTOM_IGNORE_TRADE_WITH_ENEMIES)) {
					continue;
				}
				if (faction.isPlayerFaction()) continue; // don't report player to themselves for trading with their own enemies
				
				final MarketAPI other = BaseEventPlugin.findNearestMarket(curr.market, new MarketFilter() {
					public boolean acceptMarket(MarketAPI market) {
						if (!market.getFactionId().equals(faction.getId())) {
							return false;
						}
						if (market.getFaction().isAtBest(curr.market.getFaction(), RepLevel.HOSTILE)) {
							return true;
						}
						return false;
					}
				});
				if (other == null) continue;
	
				float dist = Misc.getDistanceLY(curr.market.getLocationInHyperspace(), other.getLocationInHyperspace());
				//if (dist > 2f) continue;
				if (dist > Global.getSettings().getFloat("economyMaxRangeForNegativeTradeRepImpactLY")) continue;
				
				
				float [] repMinus = getRepPointsAndVolumeUsedFor(actionableTotal, faction);
				if (repMinus[0] <= 0) continue;
				
				if (dist <= 0) { // same star system
					repMinus[0] *= 2f;
				}
				
				final float repChange = -repMinus[0];
				
				log.info("Sending rep change of " + repChange + " with " + other.getFaction().getDisplayNameWithArticle() + 
						" due to trade with enemy (" + curr.market.getFaction().getDisplayNameWithArticle() + ")");
				
				theHostileFaction = other.getFaction().getDisplayNameWithArticle();
				hostileMarket = other.getName();
				pickedMarket = curr.market.getName();
				tempTarget = new CampaignEventTarget(other);
				CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
				final RepActions action = RepActions.TRADE_WITH_ENEMY;
				Global.getSector().reportEventStage(this, "trade_negative", playerFleet, MessagePriority.ENSURE_DELIVERY,
				//Global.getSector().reportEventStage(this, "trade_negative", other.getPrimaryEntity(), MessagePriority.ENSURE_DELIVERY,
					new BaseOnMessageDeliveryScript() {
						boolean deliver = true;
						public void beforeDelivery(CommMessageAPI message) {
							ReputationAdjustmentResult result = Global.getSector().adjustPlayerReputation(
									new RepActionEnvelope(action, new Float(Math.abs(repChange)), message, false), 
									other.getFactionId());
							deliver = result.delta != 0;
						}
						@Override
						public boolean shouldDeliver() {
							return deliver;
						}
					});
				sent++;
				if (sent >= maxToSend) break;
			}
			if (sent >= maxToSend) break;
		}
	}
	
	
	private String otherFleetName = null;
	@Override
	public void reportBattleOccurred(CampaignFleetAPI primaryWinner, BattleAPI battle) {
		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		if (!battle.isPlayerInvolved()) return;

		// turning this off now that you can fight alongside allies and gain rep that way
		if (true) return;
		
		//boolean playerWon = battle.isOnPlayerSide(primaryWinner);
		
		for (CampaignFleetAPI otherFleet : battle.getNonPlayerSideSnapshot()) {
			otherFleetName = otherFleet.getFaction().getEntityNamePrefix() + " " + otherFleet.getName();
			
			List<MarketAPI> markets = Global.getSector().getEconomy().getMarketsCopy();
			Collections.shuffle(markets);
			
			CampaignEventManagerAPI eventManager = Global.getSector().getEventManager();
			Set<String> seenFactions = new HashSet<String>();
			for (final MarketAPI market : markets) {
				if (!market.getFaction().isHostileTo(otherFleet.getFaction())) continue;
				if (!primaryWinner.isInOrNearSystem(market.getStarSystem())) continue;
				if (seenFactions.contains(market.getFactionId())) continue;
				if (eventManager.isOngoing(new CampaignEventTarget(market), Events.SYSTEM_BOUNTY)) continue;
				
				float fpDestroyed = 0;
				for (FleetMemberAPI loss : Misc.getSnapshotMembersLost(otherFleet)) {
					fpDestroyed += loss.getFleetPointCost();
				}
				
				tempTarget = new CampaignEventTarget(market);
				RepLevel level = playerFleet.getFaction().getRelationshipLevel(market.getFaction());
				//final float repFP = fpDestroyed;
				final float repFP = (int)(fpDestroyed * battle.getPlayerInvolvementFraction());
				if (repFP > 0 && level.isAtWorst(RepLevel.INHOSPITABLE)) {
					seenFactions.add(market.getFactionId());
					log.info(String.format("Improving reputation with owner of market [%s] due to fighting " + otherFleet.getName(), market.getName()));
					Global.getSector().reportEventStage(this, "battle_rep_positive", market.getPrimaryEntity(),
												MessagePriority.ENSURE_DELIVERY,
								new BaseOnMessageDeliveryScript() {
						boolean deliver = true;
						public void beforeDelivery(CommMessageAPI message) {
							ReputationAdjustmentResult result = Global.getSector().adjustPlayerReputation(
									new RepActionEnvelope(RepActions.COMBAT_WITH_ENEMY, new Float(repFP), message, true), 
									market.getFaction().getId());
							deliver = Math.abs(result.delta) >= 0.01f;
						}
						@Override
						public boolean shouldDeliver() {
							return deliver;
						}
						
					});
				}
			}
		}
	}
	
	public Map<String, String> getTokenReplacements() {
		Map<String, String> map = super.getTokenReplacements();
		if (factionString != null) {
			map.put("$theFaction", factionString);
		}
		if (marketListString != null) {
			map.put("$marketList", marketListString);
		}
		
		if (theHostileFaction != null) {
			map.put("$theHostileFaction", theHostileFaction);
		}
		if (hostileMarket != null) {
			map.put("$hostileMarket", hostileMarket);
		}
		if (pickedMarket != null) {
			map.put("$pickedMarket", pickedMarket);
		}
		
		if (otherFleetName != null) {
			map.put("$otherFleetName", otherFleetName);
		}
		
		if (tempTarget != null) {
			map.put("$sender", map.get("$marketFaction"));
		}
		
		map.put("$xpGain", "" + (int) xpGain);
		
		return map;
	}

	@Override
	public String[] getHighlights(String stageId) {
		if (stageId.equals("trade_xp_gain")) {
			List<String> result = new ArrayList<String>();
			addTokensToList(result, "$xpGain");
			return result.toArray(new String[0]);
		}
		return null;
	}
	
	@Override
	public Color[] getHighlightColors(String stageId) {
		return super.getHighlightColors(stageId);
	}
	
	@Override
	public CampaignEventTarget getEventTarget() {
		if (tempTarget != null) return tempTarget;
		return super.getEventTarget();
	}

	public boolean isDone() {
		return false;
	}
	
	@Override
	public CampaignEventCategory getEventCategory() {
		return CampaignEventCategory.DO_NOT_SHOW_IN_MESSAGE_FILTER;
	}
	
	public boolean showAllMessagesIfOngoing() {
		return false;
	}
}










