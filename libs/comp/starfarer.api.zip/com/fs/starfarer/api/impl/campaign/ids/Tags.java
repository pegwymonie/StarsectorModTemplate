package com.fs.starfarer.api.impl.campaign.ids;

public class Tags {
	
	public static final String THEME_CORE_UNPOPULATED = "theme_core_unpopulated";
	public static final String THEME_CORE_POPULATED = "theme_core_populated";
	
	public static final String THEME_MISC = "theme_misc";
	public static final String THEME_MISC_SKIP = "theme_misc_skip";
	
	public static final String THEME_RUINS = "theme_ruins";
	public static final String THEME_RUINS_MAIN = "theme_ruins_main";
	public static final String THEME_RUINS_SECONDARY = "theme_ruins_secondary";
	
	public static final String THEME_DERELICT = "theme_derelict";
	public static final String THEME_DERELICT_MOTHERSHIP = "theme_derelict_mothership";
	public static final String THEME_DERELICT_SURVEY_SHIP = "theme_derelict_survey_ship";
	public static final String THEME_DERELICT_PROBES = "theme_derelict_probes";
	
	public static final String THEME_REMNANT = "theme_remnant";
	public static final String THEME_REMNANT_MAIN = "theme_remnant_main";
	public static final String THEME_REMNANT_SECONDARY = "theme_remnant_secondary";
	public static final String THEME_REMNANT_DESTROYED = "theme_remnant_destroyed";
	public static final String THEME_REMNANT_SUPPRESSED = "theme_remnant_suppressed";
	public static final String THEME_REMNANT_RESURGENT = "theme_remnant_resurgent";
	
	public static final String SALVAGE_ENTITY_NO_DEBRIS = "no_debris";
	
	public static final String WEAPON_REMNANTS = "remnant";
	
	public static final String LOW_TECH = "low";
	public static final String HIGH_TECH = "high";
	public static final String MIDLINE = "mid";
	
	public static final String SHIP_RECOVERABLE = "ship_recoverable";
	
	
	public static final String HULLMOD_NO_DROP = "no_drop";
	
	// battle-damage related hullmods
	public static final String HULLMOD_DMOD = "dmod";
	public static final String HULLMOD_DAMAGE = "damage";
	public static final String HULLMOD_DAMAGE_PHASE = "phaseDamage";
	public static final String HULLMOD_DAMAGE_STRUCT = "damageStruct";
	public static final String HULLMOD_DESTROYED_ALWAYS = "destroyedDamageAlways";
	public static final String HULLMOD_FIGHTER_BAY_DAMAGE = "fighterBayDamage";
	public static final String HULLMOD_CARRIER_ALWAYS = "carrierDamageAlways";
	public static final String HULLMOD_PEAK_TIME = "peak_time";
	public static final String HULLMOD_NOT_PHASE = "notPhase";
	
	public static final String HULLMOD_SHIELDS = "shields";
	public static final String HULLMOD_DEFENSIVE = "defensive";
	public static final String HULLMOD_OFFENSIVE = "offensive";
	public static final String HULLMOD_ENGINES = "engines";
	public static final String HULLMOD_SPECIAL = "special";
	
	
	public static final String WING_NO_DROP = "no_drop";
	public static final String WING_NO_SELL = "no_sell";
	
	public static final String SKILL_CARRIER = "carrier";
	
	
	
	public static final String STAR = "star";
	public static final String PLANET = "planet";
	public static final String TERRAIN = "terrain";
	//public static final String SYSTEM_ANCHOR = "system_anchor";
	public static final String NON_CLICKABLE = "non_clickable";
	
	public static final String AMBIENT_LS = "ambient_ls";

	
	public static final String HAS_INTERACTION_DIALOG = "has_interaction_dialog";
	
	public static final String STATION = "station";
	public static final String COMM_RELAY = "comm_relay";
	public static final String GATE = "gate";
	public static final String ORBITAL_JUNK = "orbital_junk";
	
	public static final String TRANSIENT = "transient";
	public static final String JUMP_POINT = "jump_point";
	public static final String STELLAR_MIRROR = "stellar_mirror";
	public static final String STELLAR_SHADE = "stellar_shade";
	
	public static final String WARNING_BEACON = "warning_beacon";
	public static final String SALVAGEABLE = "salvageable";
	public static final String DEBRIS_FIELD = "debris";
	
	public static final String WRECK = "wreck";
	
	/**
	 * Will expire at some point in the near future; not everything that expires is guaranteed to have this tag.
	 */
	public static final String EXPIRES = "expires";
	
	public static final String NEUTRINO = "neutrino";
	public static final String NEUTRINO_LOW = "neutrino_low";
	public static final String NEUTRINO_HIGH = "neutrino_high";
	
	
	
	public static final String REPORT_REP = "reputation_change";
	public static final String REPORT_PRICES = "prices";
	public static final String REPORT_IMPORTANT = "important";
	public static final String REPORT_NOMAP = "nomap";
	public static final String REPORT_NO_SYSTEM = "no_system_prefix";
	public static final String FLEET_LOG = "fleet_log";
}
