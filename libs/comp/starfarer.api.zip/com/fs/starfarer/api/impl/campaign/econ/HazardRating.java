package com.fs.starfarer.api.impl.campaign.econ;



public class HazardRating extends BaseMarketConditionPlugin {
	
	public void apply(String id) {
		// problem: if hazard rating is added onto from other conditions, then applying its effect
		// here won't use the correct hazard rating, since this condition is "first".
		// can't display it correctly, either
		
		// let's not use this for now, may be unnecessary
	}

	public void unapply(String id) {
	}

}
