package com.fs.starfarer.api.impl.campaign.events;

import java.awt.Color;
import java.util.Map;

import org.apache.log4j.Logger;
import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BaseOnMessageDeliveryScript;
import com.fs.starfarer.api.campaign.BattleAPI;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.FleetAssignment;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.comm.CommMessageAPI;
import com.fs.starfarer.api.campaign.comm.MessagePriority;
import com.fs.starfarer.api.campaign.events.CampaignEventTarget;
import com.fs.starfarer.api.combat.EngagementResultAPI;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.RepActionEnvelope;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.RepActions;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.impl.campaign.ids.Pings;
import com.fs.starfarer.api.impl.campaign.shared.SharedData;
import com.fs.starfarer.api.util.Misc;

public class CustomsInspectionEvent extends BaseEventPlugin {
	
	public static float MAX_COMM_BURST_RANGE = 150f;
	public static float DISTANCE_FROM_FLEET_LEEWAY = 300f;
	public static float DISTANCE_FROM_POINT_LEEWAY = 400f;
	public static float TIME_LEEWAY_DAYS = 3f;
	
	public static enum InspectionOutcome {
		PLAYER_EVASION_SUCCESS,
		PLAYER_LEFT_SYSTEM,
		INTERRUPTED_BY_THIRD_PARTY,
		PLAYER_EVASION_NOTICED,
		PLAYER_FOUGHT_OR_RAN_BEFORE_SCAN,
		PLAYER_FOUGHT_OR_RAN_AFTER_SCAN,
		ENDED_PEACEFULLY,
		EVENT_TOOK_TOO_LONG,
	}
	
	public static Logger log = Global.getLogger(CustomsInspectionEvent.class);
	
	private CampaignFleetAPI fleet;
	
	public void init(String type, CampaignEventTarget eventTarget) {
		super.init(type, eventTarget);
		fleet = (CampaignFleetAPI) eventTarget.getEntity();
		initialFleetLoc = new Vector2f(fleet.getLocation());
		StarSystemAPI starSystem = Misc.getNearbyStarSystem(Global.getSector().getPlayerFleet());
		if (starSystem != null) {
			starSystemId = starSystem.getId();
		}
	}
	
//	@Override
//	public void setParam(Object param) {
//		fleet = (CampaignFleetAPI) param;
//	}

	public void startEvent() {
		super.startEvent();
	}
	
	private boolean done = false;
	private int stage = 0;
	private float elapsed = 0;
	
	private float initialDistance = 0;
	private Vector2f initialPoint = null;
	private Vector2f initialFleetLoc = null;
	private float elapsedSinceWarning = 0f;
	
	private boolean playerFoughtFleet = false;
	private boolean interruptedByThirdPartyFight = false;
	private String starSystemId = null;
	
	public void advance(float amount) {
		if (!isEventStarted()) return;
		if (isDone()) return;

		if (Global.getSector().getPlayerFleet().getFaction().isHostileTo(fleet.getFaction())) {
			// the *inspection* ended peacefully.
			endEvent(InspectionOutcome.ENDED_PEACEFULLY);
			return;
		}
		
		float days = Global.getSector().getClock().convertToDays(amount);
		//fleet.getContainingLocation().getFleets().contains(fleet);
		elapsed += days;
		//System.out.println("Elapsed: " + elapsed);
		if (elapsed > 10f) {// || !fleet.isAlive()) {
			endEvent(InspectionOutcome.EVENT_TOOK_TOO_LONG);
			return;
		}
		
		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		float dist = Misc.getDistance(fleet.getLocation(), playerFleet.getLocation()) - fleet.getRadius() - playerFleet.getRadius();
		boolean showingDialog = Global.getSector().getCampaignUI().isShowingDialog();
		
		float distFromStartingFleetLoc = Misc.getDistance(initialFleetLoc, fleet.getLocation());
		
		if (stage == 0) {
			Global.getSector().addPing(fleet, Pings.COMMS);
			//fleet.getMemoryWithoutUpdate().set(MemFlags.FLEET_BUSY, true, 11f);
			fleet.getAI().addAssignmentAtStart(FleetAssignment.FOLLOW, playerFleet, 10f, "approaching your fleet", null);
			
			Global.getSector().getMemory().set("$customsInspectionFactionId", fleet.getFaction().getId(), 11);
			
			nextStage();
		} else
		if (stage == 1 && (elapsed > 6f || distFromStartingFleetLoc > 5000f) && dist > MAX_COMM_BURST_RANGE) {
			endEvent(InspectionOutcome.PLAYER_EVASION_SUCCESS);
		} else
		if (stage == 1 && elapsed > 0.3f && (!fleet.isInCurrentLocation() || playerFleet.isInHyperspaceTransition() || fleet.isInHyperspaceTransition())) {
			endEvent(InspectionOutcome.PLAYER_LEFT_SYSTEM);
		} else
		if (stage == 1 && ((elapsed > 0.3f && dist <= MAX_COMM_BURST_RANGE) || dist < 100)) {
			fleet.getAI().removeFirstAssignmentIfItIs(FleetAssignment.FOLLOW);
			fleet.getAI().addAssignmentAtStart(FleetAssignment.INTERCEPT, playerFleet, 10f, "approaching your fleet",  null);
			playerFleet.setNoEngaging(0f);
			
			if (dist < 100) { // && elapsed > 0.3f) {
				nextStage();
			} else {
				Global.getSoundPlayer().playUISound("ui_channel_comm_local", 1, 1);
				Misc.showRuleDialog(fleet, "CommBurstCustomsInspection");
				nextStage();
			}
		} else
		if (stage == 2 && !showingDialog) {
			// out of the comm burst dialog; prepare for either player evasion or being caught up to
			playerFleet.setNoEngaging(0f);
			//fleet.setNoEngaging(0f);
			fleet.getMemoryWithoutUpdate().set("$doingCustomsInspection", true, 11f);
			
			initialDistance = dist;
			initialPoint = new Vector2f(playerFleet.getLocation());
			elapsedSinceWarning = 0f;
			nextStage();
		} else if (stage == 3) {
//			// switch to intercept after a few seconds
//			// to avoid immediate dialog if the fleet is right on top of the player
//			if (elapsed > 0.3f && fleet.getAI().isCurrentAssignment(FleetAssignment.FOLLOW)) {
//				fleet.getAI().removeFirstAssignmentIfItIs(FleetAssignment.FOLLOW);
//				fleet.getAI().addAssignmentAtStart(FleetAssignment.INTERCEPT, playerFleet, 10f, null);
//			}

			// check for player evading
			elapsedSinceWarning += days;
			float distFromPoint = Misc.getDistance(initialPoint, playerFleet.getLocation()) - playerFleet.getRadius();
			
			
			if (Global.getSector().getMemoryWithoutUpdate().contains("$ciFinished")) {
				nextStage();
			} else if (playerFoughtFleet) {
				endEvent(InspectionOutcome.PLAYER_FOUGHT_OR_RAN_BEFORE_SCAN);
			} else if (Global.getSector().getMemoryWithoutUpdate().contains("$ciInterrupted")) {
				if (interruptedByThirdPartyFight || fleet.getAI().isFleeing()) {
					endEvent(InspectionOutcome.INTERRUPTED_BY_THIRD_PARTY);
				} else {
					endEvent(InspectionOutcome.PLAYER_EVASION_NOTICED);
				}
			} else {
				if (!Global.getSector().getMemoryWithoutUpdate().contains("$ciInProgress")) {
					if (!fleet.isInCurrentLocation() ||
							elapsedSinceWarning > TIME_LEEWAY_DAYS ||
							distFromPoint > DISTANCE_FROM_POINT_LEEWAY ||
							dist > initialDistance + DISTANCE_FROM_FLEET_LEEWAY) {
						endEvent(InspectionOutcome.PLAYER_EVASION_NOTICED);
					} else if (!fleet.isAlive()) {
						endEvent(InspectionOutcome.INTERRUPTED_BY_THIRD_PARTY);
					}
				}
			}
		} else if (stage == 4) {
			fleet.getAI().removeFirstAssignmentIfItIs(FleetAssignment.FOLLOW);
			if (playerFoughtFleet) {
				endEvent(InspectionOutcome.PLAYER_FOUGHT_OR_RAN_AFTER_SCAN);
				nextStage();
			} else { //if (elapsed > 0.1f) {
				endEvent(InspectionOutcome.ENDED_PEACEFULLY);
				nextStage();
			}
		}
	}
	
	@Override
	public void reportPlayerEngagement(EngagementResultAPI result) {
		if (isDone()) return;
		
		CampaignFleetAPI winner = result.getWinnerResult().getFleet();
		CampaignFleetAPI loser = result.getLoserResult().getFleet();
		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		BattleAPI b = result.getBattle();
		if (b.isPlayerInvolved() && b.isInvolved(fleet) && !b.onPlayerSide(fleet)) {
			endEvent(InspectionOutcome.PLAYER_FOUGHT_OR_RAN_AFTER_SCAN);
		}
	}
	
	

	@Override
	public void reportBattleOccurred(CampaignFleetAPI primaryWinner, BattleAPI battle) {
		if (isDone()) return;
		
		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		if (battle.getSideFor(playerFleet) != null && battle.getSideFor(fleet) != null) {
		} else if (battle.getSideFor(playerFleet) != null || battle.getSideFor(fleet) != null) {
			if (!playerFoughtFleet) {
				interruptedByThirdPartyFight = true;
			}
		}
	}
	
	@Override
	public void reportFleetDespawned(CampaignFleetAPI fleet, FleetDespawnReason reason, Object param) {
		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		if (fleet == playerFleet || fleet == this.fleet) {
			if (!playerFoughtFleet) {
				interruptedByThirdPartyFight = true;
			}
		}
	}

	private void nextStage() {
		stage++;
		elapsed = 0;
	}
	
	private void endEvent(InspectionOutcome outcome) {
		fleet.getAI().removeFirstAssignmentIfItIs(FleetAssignment.FOLLOW);
		fleet.getAI().removeFirstAssignmentIfItIs(FleetAssignment.INTERCEPT);
		fleet.getAI().removeFirstAssignmentIfItIs(FleetAssignment.HOLD);
		
		fleet.getMemoryWithoutUpdate().unset("$doingCustomsInspection");
		fleet.getMemoryWithoutUpdate().unset(MemFlags.FLEET_BUSY);
		
		Global.getSector().getMemory().unset("$customsInspectionFactionId");
		
		done = true;
		
		String factionId = fleet.getFaction().getId();
		
		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		switch (outcome) {
		case PLAYER_EVASION_NOTICED:
		case PLAYER_FOUGHT_OR_RAN_AFTER_SCAN:
		case PLAYER_FOUGHT_OR_RAN_BEFORE_SCAN:
			Global.getSector().reportEventStage(this, "player_evaded", playerFleet, MessagePriority.ENSURE_DELIVERY, new BaseOnMessageDeliveryScript() {
				public void beforeDelivery(CommMessageAPI message) {
					Global.getSector().adjustPlayerReputation(
							new RepActionEnvelope(RepActions.CUSTOMS_NOTICED_EVADING, null, message, true), 
							fleet.getFaction().getId());
				}
			});
			if (starSystemId != null) {
				SharedData.getData().getStarSystemCustomsTimeout(factionId).add(starSystemId, 2f);
			}			
			break;
		case PLAYER_LEFT_SYSTEM:
		case INTERRUPTED_BY_THIRD_PARTY:
		case PLAYER_EVASION_SUCCESS:
		case EVENT_TOOK_TOO_LONG:
			if (starSystemId != null) {
				SharedData.getData().getStarSystemCustomsTimeout(factionId).add(starSystemId, 2f);
			}
			break;
		case ENDED_PEACEFULLY:
			if (starSystemId != null) {
				SharedData.getData().getStarSystemCustomsTimeout(factionId).add(starSystemId, 15f);
			}
			break;
		}
	}

	public Map<String, String> getTokenReplacements() {
		Map<String, String> map = super.getTokenReplacements();
		return map;
	}

	@Override
	public String[] getHighlights(String stageId) {
//		List<String> result = new ArrayList<String>();
//		addTokensToList(result, "$neededFood");
//		return result.toArray(new String[0]);
		return null;
	}
	
	@Override
	public Color[] getHighlightColors(String stageId) {
		return super.getHighlightColors(stageId);
	}
	
	@Override
	public CampaignEventTarget getEventTarget() {
		//if (tempTarget != null) return tempTarget;
		return super.getEventTarget();
	}

	public boolean isDone() {
		return done;
	}
	
	@Override
	public String getEventName() {
		return "Customs inspection"; // not used anywhere
	}

	@Override
	public CampaignEventCategory getEventCategory() {
		return CampaignEventCategory.DO_NOT_SHOW_IN_MESSAGE_FILTER;
	}
	
	
}










