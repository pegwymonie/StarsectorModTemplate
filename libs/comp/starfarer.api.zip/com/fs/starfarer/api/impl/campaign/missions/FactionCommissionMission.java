package com.fs.starfarer.api.impl.campaign.missions;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.MissionBoardAPI;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.MissionBoardAPI.MissionAvailabilityAPI;
import com.fs.starfarer.api.campaign.events.CampaignEventManagerAPI;
import com.fs.starfarer.api.campaign.events.CampaignEventPlugin;
import com.fs.starfarer.api.impl.campaign.ids.Events;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.util.Highlights;
import com.fs.starfarer.api.util.Misc;

public class FactionCommissionMission extends BaseCampaignMission {
	private FactionAPI faction;
	//private float baseBounty;
	
	public FactionCommissionMission(String factionId) {
		
		this.faction = Global.getSector().getFaction(factionId);
		
		//baseBounty = Global.getSettings().getFloat("factionCommissionBounty");
		
		CampaignEventManagerAPI eventManager = Global.getSector().getEventManager();
		event = eventManager.primeEvent(null, Events.FACTION_COMMISSION, this);
	}
	
	
	public void advance(float amount) {
		super.advance(amount);
	}
	
	
	public FactionAPI getFaction() {
		return faction;
	}
	
	@Override
	public String getFactionId() {
		return faction.getId();
	}

	public float getBaseBounty() {
		//return baseBounty;
		return Global.getSettings().getFloat("factionCommissionBounty");
	}

	@Override
	public String getPostingStage() {
		return super.getPostingStage();
	}


	public String getName() {
		return Misc.ucFirst(faction.getDisplayName()) + " Commission";
	}

	public void playerAccept(SectorEntityToken entity) {
		super.playerAccept(entity);
		CampaignEventManagerAPI eventManager = Global.getSector().getEventManager();
		
		MissionBoardAPI board = Global.getSector().getMissionBoard();
		for (MissionAvailabilityAPI ma : board.getMissionsCopy()) {
			if (ma.getMission() instanceof FactionCommissionMission) {
				FactionCommissionMission fcm = (FactionCommissionMission) ma.getMission();
				board.removeMission(fcm, true);
			}
		}
		
		eventManager.startEvent(event);
	}
	
	@Override
	public boolean canPlayerAccept() {
		FactionAPI player = Global.getSector().getFaction(Factions.PLAYER);

		RepLevel minStanding = RepLevel.FAVORABLE;
		return player.isAtWorst(faction.getId(), minStanding);
	}

	@Override
	public String getAcceptTooltip() {
		if (canPlayerAccept()) return null;
		
		RepLevel minStanding = RepLevel.FAVORABLE;
		return "Requires: " + faction.getDisplayName() + " - " + minStanding.getDisplayName().toLowerCase() + " or better";
	}
	
	@Override
	public Highlights getAcceptTooltipHighlights() {
		String tooltip = getAcceptTooltip();
		if (tooltip == null) return null;
		
		Highlights h = new Highlights();

		RepLevel minStanding = RepLevel.FAVORABLE;
		h.setText(minStanding.getDisplayName().toLowerCase());
		h.setColors(faction.getRelColor(minStanding));
		return h;
	}

	public CampaignEventPlugin getPrimedEvent() {
		return event;
	}

}






