package com.fs.starfarer.api.impl.campaign.econ;

import com.fs.starfarer.api.impl.campaign.ids.Commodities;

public class LightIndustrialComplex extends BaseMarketConditionPlugin {

	public void apply(String id) {

		applyBaseDemandForSuppliesIfNeeded(id);
		
		float mult = getBaseSizeMult();
		
		market.getDemand(Commodities.ORGANICS).getDemand().modifyFlat(id, mult * ConditionData.LIGHT_INDUSTRY_ORGANICS);
		market.getDemand(Commodities.VOLATILES).getDemand().modifyFlat(id, mult * ConditionData.LIGHT_INDUSTRY_VOLATILES);
		market.getDemand(Commodities.HEAVY_MACHINERY).getDemand().modifyFlat(id, mult * ConditionData.LIGHT_INDUSTRY_MACHINERY);
		
		float productionMult = getProductionMult(market, Commodities.ORGANICS, Commodities.VOLATILES);
		market.getCommodityData(Commodities.DOMESTIC_GOODS).getSupply().modifyFlat(id, mult * ConditionData.LIGHT_INDUSTRY_DOMESTIC_GOODS * productionMult);
		market.getCommodityData(Commodities.LUXURY_GOODS).getSupply().modifyFlat(id, mult * ConditionData.LIGHT_INDUSTRY_LUXURY_GOODS * productionMult);
	}

	public void unapply(String id) {
		
		unapplyBaseDemandForSupplies(id);
		
		market.getDemand(Commodities.ORGANICS).getDemand().unmodify(id);
		market.getDemand(Commodities.VOLATILES).getDemand().unmodify(id);
		market.getDemand(Commodities.HEAVY_MACHINERY).getDemand().unmodify(id);
		
		market.getCommodityData(Commodities.DOMESTIC_GOODS).getSupply().unmodify(id);
		market.getCommodityData(Commodities.LUXURY_GOODS).getSupply().unmodify(id);
	}

}
