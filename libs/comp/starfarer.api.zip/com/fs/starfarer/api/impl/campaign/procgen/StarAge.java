package com.fs.starfarer.api.impl.campaign.procgen;

public enum StarAge {
	YOUNG,
	AVERAGE,
	OLD,
	ANY,
}
