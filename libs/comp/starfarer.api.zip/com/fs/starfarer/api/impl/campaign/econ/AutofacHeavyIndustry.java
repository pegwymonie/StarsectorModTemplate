package com.fs.starfarer.api.impl.campaign.econ;

import com.fs.starfarer.api.impl.campaign.ids.Commodities;

public class AutofacHeavyIndustry extends BaseMarketConditionPlugin {

	public void apply(String id) {
		
//		market.getDemand(Commodities.REGULAR_CREW).getDemand().modifyFlat(id, ConditionData.AUTOFAC_HEAVY_CREW);
//		market.getDemand(Commodities.REGULAR_CREW).getNonConsumingDemand().modifyFlat(id, ConditionData.AUTOFAC_HEAVY_CREW * ConditionData.CREW_MARINES_NON_CONSUMING_FRACTION);
		
		float mult = getBaseSizeMult();
		
		market.getDemand(Commodities.HEAVY_MACHINERY).getDemand().modifyFlat(id, mult * ConditionData.AUTOFAC_HEAVY_MACHINERY_DEMAND);
		//float crewDemandMet = getCrewDemandMet(market);

		
		market.getDemand(Commodities.ORGANICS).getDemand().modifyFlat(id, mult * ConditionData.AUTOFAC_HEAVY_ORGANICS);
		market.getDemand(Commodities.VOLATILES).getDemand().modifyFlat(id, mult * ConditionData.AUTOFAC_HEAVY_VOLATILES);
		market.getDemand(Commodities.METALS).getDemand().modifyFlat(id, mult * ConditionData.AUTOFAC_HEAVY_METALS);
		market.getDemand(Commodities.RARE_METALS).getDemand().modifyFlat(id, mult * ConditionData.AUTOFAC_HEAVY_RARE_METALS);
		
		float productionMult = getProductionMult(market, Commodities.ORGANICS, Commodities.VOLATILES, Commodities.METALS, Commodities.RARE_METALS);
		//float productionMult = getProductionMult(market, Commodities.ORGANICS, Commodities.VOLATILES);
		//productionMult = 1f;
		
		market.getCommodityData(Commodities.HEAVY_MACHINERY).getSupply().modifyFlat(id, mult * ConditionData.AUTOFAC_HEAVY_MACHINERY * productionMult);
		market.getCommodityData(Commodities.SUPPLIES).getSupply().modifyFlat(id, mult * ConditionData.AUTOFAC_HEAVY_SUPPLIES * productionMult);
		market.getCommodityData(Commodities.HAND_WEAPONS).getSupply().modifyFlat(id, mult * ConditionData.AUTOFAC_HEAVY_HAND_WEAPONS * productionMult);
	}

	public void unapply(String id) {
		market.getDemand(Commodities.ORGANICS).getDemand().unmodify(id);
		market.getDemand(Commodities.VOLATILES).getDemand().unmodify(id);
		market.getDemand(Commodities.METALS).getDemand().unmodify(id);
		market.getDemand(Commodities.RARE_METALS).getDemand().unmodify(id);
		market.getDemand(Commodities.HEAVY_MACHINERY).getDemand().unmodify(id);
		
//		market.getDemand(Commodities.REGULAR_CREW).getDemand().unmodify(id);
//		market.getDemand(Commodities.REGULAR_CREW).getNonConsumingDemand().unmodify(id);
		
		market.getCommodityData(Commodities.HEAVY_MACHINERY).getSupply().unmodify(id);
		market.getCommodityData(Commodities.SUPPLIES).getSupply().unmodify(id);
		market.getCommodityData(Commodities.HAND_WEAPONS).getSupply().unmodify(id);
	}

}
