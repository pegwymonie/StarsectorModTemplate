package com.fs.starfarer.api.impl.campaign.econ;

import com.fs.starfarer.api.campaign.econ.CommodityOnMarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;

public class Population extends BaseMarketConditionPlugin {
//	public static final float ConditionData.POPULATION_GREEN_CREW_MULT = 0.001f;
//	public static final float ConditionData.POPULATION_FOOD_MULT = 0.1f;
//	public static final float ConditionData.POPULATION_LUXURY_MULT = 0.001f;
//	public static final float ConditionData.POPULATION_DOMESTIC_MULT = 0.01f;
//	public static final float ConditionData.POPULATION_ORGANS_MULT = 0.001f;
//	public static final float ConditionData.POPULATION_DRUGS_MULT = 0.001f;
//	public static final float ConditionData.POPULATION_WEAPONS_MULT = 0.001f;
//	public static final float ConditionData.POPULATION_SUPPLIES_FOR_CREW_MARINES = 0.1f;
	
	public void apply(String id) {
		float size = market.getSize();
		//float pop = getPopulation(market);
		
		float mult = getBaseSizeMult();
		
		//applyBaseDemandForSuppliesIfNeeded(id);
		
		float supplies = getBaseSizeMult() * ConditionData.POPULATION_SUPPLIES; 
		market.getDemand(Commodities.SUPPLIES).getDemand().modifyFlat(id, supplies);
		
		float fuel = getBaseSizeMult() * ConditionData.POPULATION_FUEL; 
		market.getDemand(Commodities.FUEL).getDemand().modifyFlat(id, fuel);
		
		if (size >= 4) {
			float food = getBaseSizeMult() * ConditionData.POPULATION_FOOD; 
			market.getDemand(Commodities.FOOD).getDemand().modifyFlat(id, food);
		}
		
		if (size >= 4) {
			market.getDemand(Commodities.DOMESTIC_GOODS).getDemand().modifyFlat(id, mult * ConditionData.POPULATION_DOMESTIC_GOODS);
			market.getDemand(Commodities.DRUGS).getDemand().modifyFlat(id, mult * ConditionData.POPULATION_DRUGS);
			market.getDemand(Commodities.HAND_WEAPONS).getDemand().modifyFlat(id, mult * ConditionData.POPULATION_WEAPONS);
			market.getCommodityData(Commodities.CREW).getSupply().modifyFlat(id, mult * ConditionData.POPULATION_GREEN_CREW);
		}
		
		if (size >= 5) {
			market.getDemand(Commodities.LUXURY_GOODS).getDemand().modifyFlat(id, mult * ConditionData.POPULATION_LUXURY_GOODS);
		}
		
		if (size >= 5) {
			market.getDemand(Commodities.ORGANS).getDemand().modifyFlat(id, mult * ConditionData.POPULATION_ORGANS);
		}
		
		//float crewAndMarines = market.getDemand(Commodities.MARINES).getRollingAverageStockpileUtility();
		//crewAndMarines += market.getDemand(Commodities.REGULAR_CREW).getRollingAverageStockpileUtility();
		//market.getDemand(Commodities.SUPPLIES).getDemand().modifyFlat(id, crewAndMarines * ConditionData.POPULATION_SUPPLIES_FOR_CREW_MARINES);

		float lowStabilityBonus = getLowStabilityBonusMult(market);
		float lowStabilityPenalty = getLowStabilityPenaltyMult(market);
		float highStabilityBonus = getHighStabilityBonusMult(market);
		float highStabilityPenalty = getHighStabilityPenaltyMult(market);
		
//		if (market.getId().equals("tartessus")) {
//			System.out.println("highStabilityPenalty: " + highStabilityPenalty);
//		}
		
		for (CommodityOnMarketAPI com : market.getAllCommodities()) {
			if (com.isNonEcon()) continue;
			if (market.isIllegal(com)) { //&& !com.getId().equals(Commodities.ORGANS)) {
				market.getDemand(com.getId()).getDemand().modifyMult("stability_" + id, lowStabilityBonus * highStabilityPenalty);
			}
		}
		
		if (!market.isIllegal(Commodities.DRUGS)) {
			market.getDemand(Commodities.DRUGS).getDemand().modifyMult("stability_" + id, lowStabilityBonus * highStabilityPenalty);
		}
		if (!market.isIllegal(Commodities.HAND_WEAPONS)) {
			market.getDemand(Commodities.HAND_WEAPONS).getDemand().modifyMult("stability_" + id, lowStabilityBonus * highStabilityPenalty);
		}
		if (!market.isIllegal(Commodities.LUXURY_GOODS)) {
			market.getDemand(Commodities.LUXURY_GOODS).getDemand().modifyMult("stability_" + id, highStabilityBonus * lowStabilityPenalty);
		}
		
	}

	public void unapply(String id) {
		
		unapplyBaseDemandForSupplies(id);
		
		market.getDemand(Commodities.FOOD).getDemand().unmodify(id);
		market.getDemand(Commodities.DOMESTIC_GOODS).getDemand().unmodify(id);
		market.getDemand(Commodities.LUXURY_GOODS).getDemand().unmodify(id);
		market.getDemand(Commodities.ORGANS).getDemand().unmodify(id);
		market.getDemand(Commodities.SUPPLIES).getDemand().unmodify(id);
		
		
		market.getCommodityData(Commodities.CREW).getSupply().unmodify(id);
		
		market.getDemand(Commodities.DRUGS).getDemand().unmodify(id);
		market.getDemand(Commodities.HAND_WEAPONS).getDemand().unmodify(id);
		market.getDemand(Commodities.LUXURY_GOODS).getDemand().unmodify("stability_" + id);
//		market.getDemand(Commodities.DRUGS).getDemand().unmodify("stability_" + id);
//		market.getDemand(Commodities.HAND_WEAPONS).getDemand().unmodify("stability_" + id);
		for (CommodityOnMarketAPI com : market.getAllCommodities()) {
			if (com.isNonEcon()) continue;
			if (market.isIllegal(com.getId())) {
				market.getDemand(com.getId()).getDemand().unmodify("stability_" + id);
			}
		}
	}

}
