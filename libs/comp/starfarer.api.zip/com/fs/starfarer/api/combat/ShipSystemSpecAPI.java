package com.fs.starfarer.api.combat;

public interface ShipSystemSpecAPI {

	String getIconSpriteName();

}
