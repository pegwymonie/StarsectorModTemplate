package com.fs.starfarer.api.combat;

public class AdmiralAIConfig {

	public boolean fullRetreatAllowed = true;
	
	
	
	public AdmiralAIConfig() {
	}
	
	
}
