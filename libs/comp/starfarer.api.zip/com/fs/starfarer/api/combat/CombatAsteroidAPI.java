package com.fs.starfarer.api.combat;

import com.fs.starfarer.api.graphics.SpriteAPI;

public interface CombatAsteroidAPI {
	SpriteAPI getSpriteAPI();
}
