package com.fs.starfarer.api.combat;

import java.awt.Color;
import java.util.EnumSet;
import java.util.List;

import com.fs.starfarer.api.characters.MutableCharacterStatsAPI;
import com.fs.starfarer.api.combat.ShieldAPI.ShieldType;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.loading.WeaponSlotAPI;

public interface ShipHullSpecAPI {
	
	public interface ShieldSpecAPI {
		float getPhaseCost();
		float getPhaseUpkeep();
		float getFluxPerDamageAbsorbed();
		ShieldType getType();
		Color getRingColor();
		Color getInnerColor();
		float getUpkeepCost();
		float getArc();
		float getRadius();
		float getCenterX();
		float getCenterY();
	}
	
	
	public static enum ShipTypeHints {
		FREIGHTER,
		TANKER,
		LINER,
		CIVILIAN,
		CARRIER,
		COMBAT,
		UNBOARDABLE,
		STATION,
		SHIP_WITH_MODULES,
		HIDE_IN_CODEX,
	}
	
	
	public ShieldSpecAPI getShieldSpec();
	
	ShieldType getDefenseType();
	String getHullId();
	String getHullName();
	
	EnumSet<ShipTypeHints> getHints();
	
	float getNoCRLossTime();
	float getCRToDeploy();
	float getCRLossPerSecond();
	
	float getBaseValue();
	
	int getOrdnancePoints(MutableCharacterStatsAPI stats);
	HullSize getHullSize();
	float getHitpoints();
	float getArmorRating();
	float getFluxCapacity();
	float getFluxDissipation();
	
	ShieldType getShieldType();
	
	List<WeaponSlotAPI> getAllWeaponSlotsCopy();
	
	String getSpriteName();
	boolean isCompatibleWithBase();
	String getBaseHullId();
	float getBaseShieldFluxPerDamageAbsorbed();
	String getHullNameWithDashClass();
	boolean hasHullName();
	float getBreakProb();
	float getMinPieces();
	float getMaxPieces();

	int getFighterBays();
	float getMinCrew();
	float getMaxCrew();
	float getCargo();
	float getFuel();
	float getFuelPerLY();

	boolean isDHull();
	boolean isDefaultDHull();

	void setDParentHullId(String dParentHullId);
	String getDParentHullId();

	ShipHullSpecAPI getDParentHull();
	ShipHullSpecAPI getBaseHull();

	List<String> getBuiltInWings();

	boolean isBuiltInWing(int index);

	String getDesignation();

	boolean hasDesignation();

	boolean isRestoreToBase();
	void setRestoreToBase(boolean restoreToBase);

}
